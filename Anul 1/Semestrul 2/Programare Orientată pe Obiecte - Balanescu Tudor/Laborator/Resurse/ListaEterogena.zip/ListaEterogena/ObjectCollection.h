#ifndef OBJECTCOLLECTION_H
#define OBJECTCOLLECTION_H
#include "Object.h"
//container de obiecte (eterogen : obiecte de diverse tipuri!!)
//tratate uniform prin intermediul clasei generale (abstracte) Object
class ObjectCollection
{
    public:
        ObjectCollection();
        virtual ~ObjectCollection();
        int Count();
        ObjectCollection& Add(Object*);
        ObjectCollection& Remove(Object*);
        //Object* RemoveLast();
        int Exist(Object*);
        void DisplayInfo();

    private:
        Object** _elements; //vector alocat dinamic ce contine elemente de tip Object*
        int _count;
};

#endif // OBJECTCOLLECTION_H
