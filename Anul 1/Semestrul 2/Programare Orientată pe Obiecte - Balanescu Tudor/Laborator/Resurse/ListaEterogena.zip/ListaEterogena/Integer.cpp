#include "Integer.h"
#include <string>
#include <iostream>
#include <cstdlib>

Integer::Integer()
{
    _value = 0;
}

Integer::Integer(int value)
{
    _value = value;
}

int Integer::Value()
{
    return _value;
}

char* Integer::ToString()
{
    char buffer[100];
    char* result = itoa(_value, buffer, 10);
    return result;
}

bool Integer::Equals(const Object& obj)
{
        const Integer* other = dynamic_cast<const Integer*>(&obj);
        return other != 0 && other -> _value == _value;
}

Integer::~Integer()
{
    //dtor
}
