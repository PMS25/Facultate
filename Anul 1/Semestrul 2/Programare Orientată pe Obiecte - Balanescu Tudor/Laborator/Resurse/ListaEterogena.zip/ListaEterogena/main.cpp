#include <iostream>
#include "Object.h"
#include <string>
#include "ObjectCollection.h"
#include "Integer.h"

using namespace std;

int main()
{
    ObjectCollection list;

    list.Add(new Integer(200));
    list.Add(new Integer(500));
    list.Remove(new Integer(200));
    list.Add(new Integer(500));


    list.DisplayInfo();

    cin.get();

    return 0;
}
