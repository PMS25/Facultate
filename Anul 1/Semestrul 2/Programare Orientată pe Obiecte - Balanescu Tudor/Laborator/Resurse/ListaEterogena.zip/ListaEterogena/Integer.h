#ifndef INTEGER_H
#define INTEGER_H
#include "Object.h"

class Integer : public Object
{
    public:
        Integer();
        Integer(int);
        int Value();
        char* ToString();
        bool Equals(const Object&);

        virtual ~Integer();
    private:
        int _value;
};

#endif // INTEGER_H
