#include "ObjectCollection.h"
#include <iostream>
using namespace std;

ObjectCollection::ObjectCollection()
{
    this->_elements = 0;
    this->_count = 0;
}

ObjectCollection::~ObjectCollection()
{
    if (_elements != 0)
    {
    for(int i = 0; i < _count; i++)
    {
        delete _elements[i];
    }

    delete[] _elements;
    }
}

int ObjectCollection::Count()
{
    return _count;
}

ObjectCollection& ObjectCollection::Add(Object* newElement)
{
    if(Exist(newElement) != -1)
    {
        return *this;
    }

    Object** temp = new Object*[_count + 1];

    for(int i = 0; i < _count; i++)
    {
        temp[i] = _elements[i];
    }

    temp[_count] = newElement;
    _count++;

    delete[] _elements;
    _elements = temp;

    return *this;
}

ObjectCollection& ObjectCollection::Remove(Object* element)
{
    int index = Exist(element);

    if (index == -1)
    {
        return *this;
    }

    Object** temp = new Object*[_count - 1];

    for(int i = 0; i < index; i++)
    {
        temp[i] = _elements[i];
    }

    for(int i = index + 1; i < _count; i++)
    {
        temp[i-1] = _elements[i];
    }

    _count--;

    delete[] _elements;
    _elements = temp;

    return *this;
}

int ObjectCollection::Exist(Object* element)
{
    for(int i = 0; i < _count; i++)
    {
        if(_elements[i]->Equals(*element)) //aici apare polimorfism
        {
            return i;
        }
    }

    return -1;
}

void ObjectCollection::DisplayInfo()
{
    if (_count == 0)
    {
        cout<<"empty list"<<endl;
    }

    for(int i = 0; i < _count; i++)
    {
        cout<<_elements[i]->ToString()<<endl;
    }
}



