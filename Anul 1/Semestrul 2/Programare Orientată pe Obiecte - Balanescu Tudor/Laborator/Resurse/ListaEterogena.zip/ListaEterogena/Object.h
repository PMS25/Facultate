#ifndef OBJECT_H
#define OBJECT_H

//clasa abstracta
class Object
{
    public:
        virtual char* ToString()=0; //metoda virtuala pura
        virtual bool Equals(const Object&)=0;
        virtual ~Object();
    protected:
    private:
};

#endif // OBJECT_H
