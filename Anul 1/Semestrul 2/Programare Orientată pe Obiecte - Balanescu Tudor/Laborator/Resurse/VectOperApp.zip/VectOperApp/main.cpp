#include <iostream>

using namespace std;

//supraincarcarea operatorilor in C++
//fie clasa Vector pentru operatii cu siruri de numere reale
//suma, diferenta, produs scalar, citire, afisare
//un vector de dimensiune n este un tuplu (a1,a2,...,an)

class Vector
{
  private:
        int _size;
        double* _elem;
  public:
        Vector();
        Vector(int, double*);
        Vector(const Vector&);

        //void Display();
        //void Read();

        ~Vector();

        //supraincarcare operatori
        Vector operator+(const Vector&);

        //produs scalar
        double operator*(const Vector&);

        //inmultirea cu un scalar
        Vector operator*(double);

        //suprincarcare operator de atribuire =
        Vector& operator=(const Vector&);

        //supraincarcare << pentru "cout<<v" : afisara la consola
        friend ostream& operator<<(ostream&, const Vector&);

        //suprincarcare >> pentru "cin>>v" : citire de la consola
        friend istream& operator>>(istream&, Vector&);
};

Vector::Vector()
{
    _elem = 0;
    _size = 0;
}

Vector::Vector(int size, double* elem)
{
    _size = size;
    _elem = new double[size];
    for(int i = 0; i < size; i++)
    {
        _elem[i] = elem[i];
    }
}

Vector::Vector(const Vector& v)
{
    _size = v._size;
    _elem = new double[v._size];
    for(int i = 0; i < v._size; i++)
    {
        _elem[i] = v._elem[i];
    }
}

Vector::~Vector()
{
    if (_elem != 0)
    {
        delete[] _elem;
    }
}

//"<<"
//obs: nu este functie membra a clasei!!!
//este functie globala prietena!!
//nu poate fi functie membra deoarece operandul stand (cout)
//nu este de tip clasa Vector; este de tip ostream

ostream& operator<<(ostream& out, const Vector& v)
{
    if (v._elem == 0)
    {
        out<<"[]"<<endl;
        return out;
    }

    out<<"[";
    for(int i = 0; i < v._size - 1; i++)
    {
        out<<v._elem[i]<<", ";
    }
    out<<v._elem[v._size-1]<<"]"<<endl;

    return out; //pentru utilizarea inlantuita (se returneaza prin referinta!!!); cout<<v1<<v2
}

//">>"
istream& operator>>(istream& in, Vector& v)
{
    if (v._size != 0 && v._elem != 0)
    {
        delete[] v._elem;
    }

    cout<<"size: ";
    in>>v._size;

    v._elem = new double[v._size];

    for(int i = 0; i < v._size; i++)
    {
        cout<<"v["<<i<<"]=";
        in>>v._elem[i];
    }

    return in;
}

//+
Vector Vector::operator+(const Vector& v)
{
    //add objects "*this" and "v"
    //check size
    if (_size != v._size)
    {
        return Vector(); //apelam primul constructor pentru a crea
        //vectorul "zero"
    }

    Vector s;
    s._size = _size;
    s._elem = new double[_size];

    for(int i = 0; i < _size; i++)
    {
        s._elem[i] = _elem[i] + v._elem[i];
    }

    return s;
}

double Vector::operator*(const Vector& v)
{
    if (_size != v._size)
    {
        return 0;
    }

    double s = 0;

    for(int i = 0; i < _size; i++)
    {
        s += _elem[i] * v._elem[i];
    }

    return s;
}

Vector Vector::operator*(double s)
{
    if ( _elem == 0)
    {
        return Vector();
    }

    Vector v;
    v._size = _size;
    v._elem = new double[_size]; //alocare dimensiune!!!

    for(int i = 0; i < _size; i++)
    {
        v._elem[i]= _elem[i]*s;
    }

    return v;
}

Vector& Vector::operator=(const Vector& v)
{
    //Schema generala de supraincarcare este urmatoarea
    //Pas1: se verifica auto-atribuirea
    if (this == &v) //avem auto-atribuire (v=v)
    {
        return *this;
    }

    //Pas2: se elibereaza memoria ocupata de obiectul curent *this (deoarece vom face realocare)
    if (_elem != 0)
    {
        delete[] _elem;
    }

    //Pas3: alocarea noului spatiu de memorie!!
    _elem = new double[v._size];

    //Pas4: copierea valorilor din obiectul sursa (v)
    for(int i = 0; i < v._size; i++)
    {
        _elem[i] = v._elem[i];
    }

    _size = v._size;

    return *this; //se returneaza obiectul curent (destinatie), deoarece
    //expresia v1=v2 are ca valoare chiar v1 in care s-a copiat v2!!!!!
    //returnarea se face prin referinta tocmai pentru a putea fi corect
    //utilizat inlantuit; (la returnarea prin valoare se creaza copie!!)
}

int main()
{
    Vector v1,v2;

    //cin>>v1>>v2; //deoarece am supraincarcat operatorul ">>"
    //cout<<v1<<v2<<v1+v2;
    //Intrebare: cum traduce compilatorul expresia de mai sus?
    //Raspuns:
    //operator<<(operator<<(cout, v1), v2); //cout<<v1<<v2


    //Intrebare: cum traduce compilatorul acum expresia v1+v2
    //Raspuns: v1.operator+(v2) //operator+ acum este functie membra (nu mai este prietena friend)

    cin>>v1;
    v2 = v1; //aici se apleaza operator=
    cout<<v1<<v2;

    //cout<<v1<<v1*2.5;

    return 0;
}
