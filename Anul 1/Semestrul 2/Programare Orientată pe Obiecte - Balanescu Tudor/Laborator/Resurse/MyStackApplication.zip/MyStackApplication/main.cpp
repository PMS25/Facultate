#include <iostream>

using namespace std;

//sa se implementeze notiunea de stiva
//memoria va fi alocata dinamic
//cum functioneza??
//vom utiliza un vector _elem alocat dinamic
//(3,4,5) => stiva curenta
//inserarea: realocam spatiu pentru noua stiva (4) si inseram
//noul element la final (3,4,5,v)
//scoatere din stiva: realocam apatiu (2); se elimina 5
//-afisare; read;
//-constructori
//-destructor
//-inserare,eliminare
//-concatenarea a doua stiva

class MyStack
{
  private:
        int _count;
        int* _elem;
  public:
        MyStack();
        MyStack(int,int*);
        MyStack(const MyStack&);
        ~MyStack();
        void Display();
        MyStack& Read(); //returnez *this

        MyStack& Push(int);
        int Pop(); //scoatere din varf (returnez valoarea)

        MyStack Concat(const MyStack&);
};

MyStack& MyStack::Push(int value)
{
    int* temp = new int[_count + 1];
    //_copiez in temp ce exista deja in elem

    for(int i = 0; i < _count; i++)
    {
        temp[i] = _elem[i];
    }

    temp[_count] = value;
    _count++;
    delete[] _elem;
    _elem = temp;

    return *this;
}


int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
