#include <iostream>
#include <string.h>

using namespace std;

//sa se implementeze o structura
//pentru datele unui student
//si operatii: initializare, display, modificare, eliberare resurse
//id, name, faculty, email, address,...

//constr. de copiere:
//- daca nu este declarat explicit, este auto-generat de compilator!!
//- prin urmare se recomanda ca orice sa contina un constructor
//de copiere;

//- se apeleaza automat in situatiile urmatoare:
//(1) Student s1, s2(s1);
//(2) void f(Student s) { ... } //ca param. prin
//(3) Student f(){...} //returnare prin valoare

//destr. se apeleaza automat la terminarea duratei de viata a
//obiectului:
//(1) variabilele temporare (auto) - la parasirea blocului in
//care au fost declarate
//(2) variabile static (static) - la terminarea aplicatiei - sunt
//in viata pe toata durata executiei programului
//(3) variabile dinamice (alocate pe HEAP) - la stergerea cu delete


class Student
{
 private:
  int _id;
  char* _name; //sir de caracatere alocat dinamic
  char* _faculty;
 public:
  Student();
  Student(int, char*, char*);
  //constructorul de copiere
  Student(const Student&);

  void Init(int, char*, char*);
  void Display();
  void Dispose();

  //getter&setter
  char* GetName(); //o metoda get returneaza valoarea unui atribut ascuns
  //o metod set modifica in mod controlat valoarea unui camp ascuns
  void SetName(char*);

  ~Student(); //este unic; se apeleaza la terminarea
  //duratei de viata a obiectului

};

Student::~Student()
{
    cout<<"apel destructor!! ["<<_id<<"]"<<endl;

    Dispose();

}

Student::Student()
{
    Init(1, "noname", "info");
}

Student::Student(int id, char* name, char* faculty)
{
    Init(id, name, faculty);
}

Student::Student(const Student& s)
{
    cout<<"Student::Student(const Student& s)"<<endl;
    Init(s._id + 1, s._name, s._faculty);
}

char* Student::GetName()
{
    return _name;
}

void Student::SetName(char* name)
{
    if (_name != 0)
    {
        delete[] _name;
    }

    _name = new char[strlen(name) + 1];
    strcpy(_name, name);
}

void Student::Init(int id, char* name, char* faculty)
{
    _id = id;

    _name = new char[strlen(name) + 1];
    strcpy(_name, name);

    _faculty = new char[strlen(faculty) + 1];
    strcpy(_faculty, faculty);
}

void Student::Display()
{
    cout<<"Id: "<<_id<<endl;
    cout<<"Name: "<<_name<<endl;
    cout<<"Faculty"<<_faculty<<endl;
}

//eliberare spatiu
void Student::Dispose()
{
    delete[] _name;
    delete[] _faculty;
}

void f(Student s)
{
    static Student s1(5, "static", "info"); //pe zona de static (memoria globala)
    //Student temp = s;
    s.Display();
}

int main()
{
  {
    auto Student s(3, "coco", "info"); //pe stiva

    f(s);
    Student* sp = new Student(8, "rexo-lino-coco", "upit-inf");
    sp->Display();
    delete sp; //apel destructor

    /*
    Student s;//acum s se numeste obiect
    Student s1(8, "rexolino", "info-rexo");
    s1.Display();
    s.Display();


    s.Init(5, "Cocolino", "Mate-Info"); //acum Init se numeste metoda

    s.Display();
    */
  }

    return 0;
}
