#include <iostream>

using namespace std;

//Supraincarcarea operatorilor in C++
//Problema: sa se implementeze o
//clasa Counter

class Counter
{
    private:
        int* _value; //alocare dinamica
    public:
        Counter();
        Counter(int);
        Counter(const Counter&);

        //getter/setter
        int GetValue();
        void SetValue(int);

        ~Counter();

        //supraincarcare <<
        friend ostream& operator<<(ostream&, const Counter&);
        //supraincarcare >>
        friend istream& operator>>(istream&, Counter&);

        //incrementare cu o unitate
        Counter& Increment();
        //cu functie operator ++
        Counter& operator++(); //forma prefixata
        Counter operator++(int); //forma postfixata

        Counter& Decrement();

        Counter& IncrementBy(int);
        Counter& operator+=(int);

        Counter& DecrementBy(int);

        //operatorul de atribuire '='
        Counter& operator=(const Counter&);
};

Counter::Counter()
{
    _value = new int(0);
}

Counter::Counter(int startValue)
{
   _value = new int(startValue);
}

Counter::Counter(const Counter& c)
{
    _value = new int(*c._value);
}

int Counter::GetValue()
{
    return *_value;
}

void Counter::SetValue(int value)
{
    if (value >= 0)
    {
        *_value = value;
    }
}

Counter::~Counter()
{
    delete _value;
}

ostream& operator<<(ostream& out, const Counter& c)
{
    out<<"("<<*c._value<<")"<<endl;
    return out;
}

istream& operator>>(istream& in, Counter& c)
{
    cout<<"value: ";
    in>>*c._value;

    return in; //pentru utilizare inlantuita!!
}

//Observatie importanta: cand o functie
//returneaza obiectul curent, acest lucru se face prin
//REFERINTA, alstfel, se va returna o copie
//a obiectului curent!!!
Counter& Counter::Increment()
{
    ++(*_value);
    return *this; //se returneaza obiectul curent
}

Counter& Counter::operator++()
{
    //++(*_value);
    //return *this;
    return Increment();
}

Counter Counter::operator++(int)
{
    Counter temp(*this); //constructorul de copiere
    ++(*_value);
    return temp; //se returneaza copia obiectului curent
    //inainte de a fi modificat pentru a pastra
    //semnficatia formei postfixata a operatorului ++
}

Counter& Counter::IncrementBy(int value)
{
    *_value += value;

    if (*_value < 0)
    {
        *_value = 0;
    }

    return *this;
}

Counter& Counter::operator+=(int value)
{
    *_value += value;

    if (*_value < 0)
    {
        *_value = 0;
    }

    return *this;
}

Counter& Counter::operator=(const Counter& c)
{
    //schema generala de implementare
    //Pas1: se verifica auto-atribuirea (c=c)
    if (this == &c)
    {
        return *this;
    }

    //Pas2: se sterge memoria ocupata de obiectul curent
    //operandul stang
    //se face acest lucru deoarece la alocari dinamice
    //este posibil ca memoria deja alocata sa nu corespunda
    //cu memoria operandului drept (din care copiem)
    //de aceea se sterge memoria deja alocata
    //si se re-aloca memorie cat este necesar
    //tocmai de aceea am efectuat testul initial de auto-atribuire
    delete _value;

    //Pas3 re-alocare cu dimensiunea obiectului sursa
    _value = new int;

    //Pas4 copierea valorilor
    *_value = *c._value;

    //Pas5 returnarea obiectului curent prin referinta
    //pentru utilizarea corecta in expresii!!!
    return *this;
}

int main()
{
    Counter c1, c2(10);

    //cum ar fi daca as dori sa afisez c1 astfel:

    //cout<<c1<<c2;

    //Observatie: 'cout' este obiect de tip ostream
    //operatorul '<<' a fost deja supraincarcat
    //in clasa ostream
    //semnificatia lui initiala este deplasare
    //pe biti la stanga!!
    //supraincarcarea se face cu o functie operator
    //friend globala (nemembra) deoarece
    //primul operand este de clasa ostream (alta
    //decat clasa noastra Counter

    //Cum interpreteaza compilatorul expresia 'cout<<c1<<c2;'???
    //Evalueaza de la stanga la dreapta
    //operator<<(operator<<(cout, c1), c2);

    //cin>>c1>>c2;
    //cout<<c1<<c2;

    //c2.Increment().Increment();
    //cout<<c2;

    //cout<<c2++<<c2;

    //++(c2+=5) += -25;

    ++(c1=c2);

    cout<<c1<<c2;

    return 0;
}
