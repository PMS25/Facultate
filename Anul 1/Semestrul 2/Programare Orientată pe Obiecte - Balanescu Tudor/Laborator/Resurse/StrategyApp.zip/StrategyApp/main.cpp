#include <iostream>

using namespace std;

//Aplicatii extensibile.
//Sa se implementeze o clasa List ce ofera facilitatea
//ordonarii elementelor folosind algoritmi
//diferiti de sortare.

//Observatie: clasa va fi  implementata astfel incat
//sa fie independenta de un anumit algoritm (strategie)
//de sortare;

//algoritmul va fi putea fi schimbat/imbunatatit
//fara modificarea codului sursa al clasei List!

//Solutia este ABSTRACTIZAREA
//Abstractizam notiunea de algoritm de sortare printr-o clasa
//generala (de baza) 'SortStrategy'

//clasa noastra List va utiliza un pointer la clasa 'SortStrategy'
//prin urmare, va depinde doar de aceasta

//In continuare, prin operatii de mostenire, se vor putea implementa
//diverse strategii de ordonare (clase derivate din 'SortStrategy')

//O clasa ce contine cel putin o metoda virtuala pura
//va deveni clasa abstracta (nu poate fi instantiata)
//o clasa abstracta joaca rol de 'contract' intre clasa client (care o
//foloseste printr-un pointer sau o referinta) si clasele
//concrete ce sunt derivate din aceasta!!

class SortStrategy
{
  public:
        virtual void Sort(double*, int)=0; //metoda virtuala pura
        virtual char* GetSortStrategyName()=0;
};

class BubbleSortStrategy : public SortStrategy
{
  public:
       void Sort(double*, int);
       char* GetSortStrategyName();
};

void BubbleSortStrategy::Sort(double* elem, int count)
       {
           for(int i = 0; i < count - 1; i++)
            for(int j = i+1; j < count; j++)
             if (elem[i] > elem[j])
             {
                 int aux = elem[i];
                 elem[i] = elem[j];
                 elem[j] = aux;
             }
       }

char* BubbleSortStrategy::GetSortStrategyName()
{
    return "BubbleSortStrategy";
}

//clasa List/////////////////////////////////////////////////////////

class List
{
  private:
    SortStrategy* _strategy; //strategia de orodonare
    double* _elem; //elementele de ordonat
    int _count;
  public:
    List();
    List(int, double*, SortStrategy*);

    void Display();
    void Read();
    void Sort();
    void SetSortStrategy(SortStrategy*);

    ~List();
};

List::List()
{
    _strategy = 0;
    _elem = 0;
    _count = 0;
}

List::List(int count, double* elem, SortStrategy* strategy)
{
    _count = count;
    _elem = new double[count];
    for(int i = 0; i < count; i++)
    {
        _elem[i] = elem[i];
    }

    //vom copia pointeri!!!!
    _strategy = strategy;
}

void List::Display()
{
    if (_strategy != 0)
    {
        cout<<"Sort Strategy: "<<_strategy->GetSortStrategyName()<<endl;
    }
    else
    {
        cout<<"Sort strategy is null."<<endl;
    }

    if (_elem != 0)
    {
        cout<<"(";

        for(int i = 0; i < _count - 1; i++)
        {
            cout<<_elem[i]<<",";
        }

        cout<<_elem[_count-1]<<")"<<endl;
    }
    else
    {
        cout<<"()"<<endl;
    }
}

void List::SetSortStrategy(SortStrategy* strategy)
{
    if (strategy != 0)
    {
        _strategy = strategy;
    }
}

void List::Read()
{
    cout<<"count: ";
    cin>>_count;

    if (_elem != 0)
    {
        delete[] _elem;
    }

    _elem = new double[_count];
    for(int i = 0; i < _count; i++)
    {
        cout<<"elem["<<i<<"]=";
        cin>>_elem[i];
    }
}

void List::Sort()
{
    if (_strategy != 0)
    {
        _strategy->Sort(_elem, _count);
    }
    else
    {
        cout<<"sort strategy cannot be null."<<endl;
    }
}

List::~List()
{
    if (_strategy != 0)
    {
        delete _strategy;
    }

    if (_elem != 0)
    {
        delete[] _elem;
    }
}

//implementati alte strategii de ordonare
class InsertionSort: public SortStrategy
{
  public:
        void Sort(double*, int);
        char* GetSortStrategyName();
};

char* InsertionSort::GetSortStrategyName()
{
    return "InsertionSortStrategy";
}

void InsertionSort::Sort(double* elem, int count)
{
    //implementare
}

int main()
{
    List l;
    l.Read();
    l.Display();
    //l.SetSortStrategy(new BubbleSortStrategy);
    l.SetSortStrategy(new InsertionSort);
    l.Sort();
    l.Display();

    return 0;
}
