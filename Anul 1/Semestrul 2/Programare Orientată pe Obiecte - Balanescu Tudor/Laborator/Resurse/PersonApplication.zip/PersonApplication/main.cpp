#include <iostream>
#include <string.h>

using namespace std;

class Person
{
  public:
    Person();
    Person(int,char*);
    Person(const Person&);

    virtual void Display();

    //get&&set
    char* GetName();
    void ChangeName(char*);

    virtual ~Person();
  protected:
    char* _name;
    int _age;
};

Person::Person()
{
    _age = 0;
    _name = "Anonim";
}

Person::Person(int age, char* name)
{
    _age = age;
    _name = new char[strlen(name) + 1];
    strcpy(_name, name);
}

Person::Person(const Person& p)
{
    _age = p._age;
    _name = new char[strlen(p._name) + 1];
    strcpy(_name, p._name);
}

Person::~Person()
{
    cout<<"se distruge person"<<endl;
    if(_name != 0)
    {
        delete[] _name;
    }
}

void Person::Display()
{
    cout<<"age: "<<_age<<endl;
    cout<<"name: "<<_name<<endl;
}


/*
Clase derivate
*/

class Student : public Person
{
    public:
        Student();
        Student(int,char*,int,char*);
        Student(const Student&);

        void Display();

        //metode specifice (set, get)

        ~Student();

    private:
        int _year;
        char* _faculty;

};

Student::Student():Person()
{
    _year = 1;
    _faculty = "info";
}

Student::Student(int age, char* name, int year, char* faculty):Person(age,name)
{
    _year = year;
    _faculty = new char[strlen(faculty)+1];
    strcpy(_faculty, faculty);
}

Student::Student(const Student& s):Person(s)
{
    _year = s._year;
    _faculty = new char[strlen(s._faculty)+1];
    strcpy(_faculty, s._faculty);
}

Student::~Student()
{
    cout<<"se distruge student"<<endl;
    delete[] _faculty;
}

void Student::Display()
{
    Person::Display(); //aici apelez varianta mostenita
    cout<<"year: "<<_year<<endl;
    cout<<"faculty: "<<_faculty<<endl;
}

class Salariat : public Person
{
    public:
        Salariat();
        Salariat(int, char*, double);
        Salariat(const Salariat&);

        void Display();

        //metode specifice (set, get)

        ~Salariat();

    private:
        double _salary;

};

Salariat::Salariat():Person()
{
    _salary = 2000;
}

Salariat::Salariat(int age, char* name, double salary):Person(age,name)
{
    _salary = salary;
}

Salariat::Salariat(const Salariat& s):Person(s)
{
    _salary = s._salary;
}

Salariat::~Salariat()
{
    cout<<"se distruge salariat"<<endl;
}

void Salariat::Display()
{
    Person::Display(); //aici apelez varianta mostenita
    cout<<"salary: "<<_salary<<endl;
}

void Prel(Person* p)
{
    p->Display(); //ce varianta alege??
    //clasa Student (cat si Salariat)
    //are doua variante pentru Display
    //Person::Display() si Student::Display()
    //in momentul cand Display s-a declarat
    //virtuala, ambele variante sunt salvata intr-o
    //tabela speciala numita VTF (Virtual Table Fucntions)

}

int main()
{
    /*Person p1;
    Person* p2 = new Person(34, "Ionescu");

    p1.Display();
    p2->Display();

    Student s(22, "popescu", 2, "informatica2");
    s.Display();

    delete p2;
    */
    Person* p1 = new Student(25, "Vasilescu", 1, "Calculatoare");
    Person* p2 = new Salariat(40, "Pompliu", 2500);
    Prel(p1);
    Prel(p2);

    delete p1;
    delete p2;

    return 0;
}


/*

Sa se implementeze o ierarhie de clase
Polygon
    atribut: numar de laturi
    metode: constr., destr., calcul arie, calcul perimetru
    display
Square, Triangle, Recangle

Utilizati clasa Point
*/
/*
class Point
{
    public:
        Point(int x = 0,int y = 0):_x(x),_y(y) {  }
        int X(){ return _x; }
        int Y(){ return _y; }
    private:
        int _x;
        int _y;
}

class Polygon
{
    public:
        //constr. detr.
        virtual double Area() { return 0; }
        virtual double Perimeter() { return 0; };

        virtual ~Polygon();
    protected:
        char* _id;
        Point _origin;
};


class Rectangle : Polygon
{
    public:
        Rectangle(int,int,int,int,char*);
        //
    private:
        Point _other;
}

Rectangle::Rectangle(int x1, int y1, int x2, int y2, char* id):Polygon(x1,y1,id)
{
        _other = Point(x2, y2);

}
*/
