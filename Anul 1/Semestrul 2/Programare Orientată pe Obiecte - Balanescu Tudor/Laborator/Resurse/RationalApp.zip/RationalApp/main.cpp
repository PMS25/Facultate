#include <iostream>

using namespace std;

//realizati o aplicatie pentru
//lucrul cu numere rational (fractii)
//afisare, citire, suma, diferenta, produs
//simplificare, inversarea

class Rational
{
  private:
    int* _m; //un intreg alocat dinamic (numitorul)
    int* _n;

    int Cmmdc(int, int);

  public:
    Rational();
    Rational(int, int);
    Rational(const Rational&);

    //getter/setter
    int GetM();
    int GetN();
    void SetM(int);
    void SetN(int);

    void Display();
    void Read();

    Rational Sum(const Rational&);
    Rational Dif(const Rational&);
    Rational Mult(const Rational&);
    Rational& Sum(int); //adunarea la fractia curenta a unui int

    Rational& Simplif();//simplifica fractia curenta (returneaza obiectul curent modificat)
    Rational& Reverse(); //inversarea fractiei curente

    ~Rational();
};

//primul constructor va crea fractia '0'

Rational::Rational()
{
    _m = new int(0);
    _n = new int(1);
}

Rational::Rational(const Rational& r)
{
    _m = new int(*r._m);
    _n = new int(*r._n);
}

void Rational::Display()
{
    cout<<*_m<<"/"<<*_n<<endl;
}

void Rational::Read()
{
    cout<<"m: "; cin>>*_m;
    cout<<"n: "; cin>>*_n;
}

Rational& Rational::Simplif()
{
    int d = Cmmdc(*_m, *_n);
    *_m /= d;
    *_n /= d;

    return *this;
}

Rational& Rational::Reverse()
{
    int a = *_m;
    *_m = *_n;
    *_n = a;

    return *this;
}

Rational Rational::Sum(const Rational& r)
{
    //se aduna fractiile *this si r
    Rational s( *_m * (*r._n) + *_n * (*r._m), *_n * (*r._n));
    return s.Simplif();
}

Rational::Rational(int a, int b)
{
    _m = new int(a); //aloc un singur int

    if ( b != 0)
    {
        _n = new int(b);
    }
    else
    {
        _n = new int(1);
    }
}

int Rational::Cmmdc(int a, int b)
{
    int x = a < 0 ? -a : a;
    int y = b < 0 ? -b : b;

    while(x != y)
    {
        if (x > y)
        {
            x -= y;
        }
        else
        {
            y -=x;
        }
    }

    return x;
}

Rational::~Rational()
{
    delete _m;
    delete _n;
}

int main()
{
   Rational r1,r2;
   r1.Read();
   //r2.Read();

   //r1.Sum(r2).Display();

   r1.Reverse().Simplif();
   r1.Display();


   return 0;
}
