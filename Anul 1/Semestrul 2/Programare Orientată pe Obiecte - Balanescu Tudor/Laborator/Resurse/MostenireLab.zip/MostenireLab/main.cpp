#include <iostream>
#include <string.h>

using namespace std;

//Mostenire(clase derivate)/redefinire/functii virtuale/polimorfism
class Person
{
  private:
    int _age;
    char* _name;
  public:
    Person();
    Person(int, char*);
    Person(const Person&);

    virtual void Display();

    ~Person();
};

Person::Person()
{
    _age = 0;
    _name = 0;
}

Person::Person(int age, char* name)
{
    _age = age;
    _name = new char[strlen(name) + 1];
    strcpy(_name, name);
}

Person::Person(const Person& p)
{
    _age = p._age;
    _name = new char[strlen(p._name) + 1];
    strcpy(_name, p._name);
}

Person::~Person()
{
    if (_name != 0)
    {
        delete[] _name;
    }
}

void Person::Display()
{
    cout<<"age: "<<_age<<endl;

    if (_name == 0)
    {
        cout <<"name: ()"<<endl;
    }
    else
    {
        cout<< "name: "<<_name<<endl;
    }
}

//MOSTENIRE: sa se implementeze o clasa Student pe baza
//clasei Person deja existenta.
//Deoarece putem spune ca un stundent este o persoana (particulara)
//vom dervia noua clasa prin mostenire din clasa Person
//Student mostenese tot ce are Person
class Student : public Person
{
    private:
        char* _faculty; //date specifice clasei Student (restul sunt mostenite!!)
    public:
        Student();
        Student(int, char*, char*);
        Student(const Student&);

        void Display();//functia Display declarat intentionat cu aceeasi semnatura ca cea din clasa de baza
        //acest fapt poarta numele de REDEFINIRE!!

        ~Student();
};

Student::Student():Person() //aici se apeleaza constr. default mostenit (de la Person)
{
  _faculty = 0;
}

Student::Student(int age, char* name, char* faculty):Person(age, name)
{
    _faculty = new char[strlen(faculty) + 1];
    strcpy(_faculty, faculty);
}

Student::Student(const Student& s):Person(s)
{
     _faculty = new char[strlen(s._faculty) + 1];
    strcpy(_faculty, s._faculty);
}

//se distrug doar datele din Student (cele motenite vor fi sterse automat)
Student::~Student()
{
  if (_faculty != 0)
  {
      delete[] _faculty;
  }
}

void Student::Display()
{
    Person::Display(); //se apeleaza explicit varianta mostenita
    if (_faculty != 0)
    {
        cout<<"faculty: "<<_faculty<<endl;
    }
    else
    {
        cout<<"faculty: empty"<<endl;
    }
}

//functia este extensibila (are caracter general)
void Prel(Person* p)
{
    p->Display(); //aici apare polimorfism, deoarece, cu
    //mecanismul functiilor virtuale,
    //acest apel poate "imbraca" mai multe forme, functie
    //de obiectul efectiv care prefixeaza apelul (orice clasa derivata
     //din Person
}

int main()
{
    //Person p1(20, "cocolino");
    //p1.Display();
    //Student s(60, "Rexolino", "Mate-Info1");
    //s.Display();

    //Obiectele pot fi create si dinamic!! (cu operatorul new)
    //Se pot astfel pointeri catre clasele din care fac parte
    //Exemplu:

    //Student* p = new Student(60, "Rexolino", "Mate-Info1");
    //expresia new Student... returneaza adresa de memorie
    //a noului obiect de tip Student; aceasta este stocata in
    //pointerul p
    //proprietatile obiectului vor fi accesate cu "->"
    //p->Display(); //(*p).Display();

    //Functii (metode) virtuale
    //Person* p = new Student(23, "Fifi", "MI"); //VALID!!! Student este compatibil cu Person, fiind derivat din aceasta
    //p->Display(); //p este un pointer de tip Person DAR
    //are ca valoare o adresa a unui obiect Student!!!
    //si Person si Student contin Display
    //Intrebare: ce varianta va fi apelata in expresia p->Display()

    //Mecanismul functii virtuale: intr-o relatie de mostenire,
    //daca o metoda este redefinita in derivata (adica obiectele
    //clasei derivate vor contine doua variante pentru aceeasi metoda)
    //cu acesta mecanism, daca se declara un pointer de tip
    //clasa de baza, initializat cu un obiect de tip clasa derivata,
    //intotdeauna se va selecta varianta tipului efectiv
    //al obiectului (clasa derivata!! in acest caz)
    //Fara functii virtuale, se va selecta varianta din tipul
    //declarat al pointerului!!

    //Obs: prin urmare, orice obiect de tip student contine
    //aceste doua variante de Display:
    //Person::Display()
    //Student::Display()

    //Cu mecanismul functiilor virtuale, se genereaza o tabela
    //a functiilor virtuale (VFT: Virtual Function Table)
    //aici sunt trecute toate adresele de memorie ale functiilor
    //virtuale

    Prel(new Student);
    Prel(new Person);
    //Prel(new Salariu);

    return 0;
}
