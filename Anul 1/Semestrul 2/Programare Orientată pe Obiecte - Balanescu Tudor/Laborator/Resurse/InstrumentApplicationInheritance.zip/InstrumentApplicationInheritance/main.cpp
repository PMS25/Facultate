#include <iostream>
#include "Instrument.h"
#include "Guitar.h"

using namespace std;

void Process(Instrument* p)
{
    //,....
    p->DisplayInfo(); //"late binding"
}

void Process(const Instrument& ref)
{
    //,....
    ref.DisplayInfo();
}

int main()
{
    //Instrument i("pian", 300);
    //i.DisplayInfo();

    //Guitar g("chitara", 2500, 12);
    //g.DisplayInfo();

    Instrument* p = new Guitar("chitara", 2500, 12);

    Process(p);
    delete p;

    return 0;
}
