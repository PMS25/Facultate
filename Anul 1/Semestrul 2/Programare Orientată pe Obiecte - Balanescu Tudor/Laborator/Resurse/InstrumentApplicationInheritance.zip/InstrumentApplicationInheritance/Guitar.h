#ifndef GUITAR_H
#define GUITAR_H
#include "Instrument.h"

class Guitar : public Instrument
{
    public:
        Guitar();
        Guitar(char*, double, int);
        Guitar(const Guitar& other);
        ~Guitar();
        void DisplayInfo()const;
        //getters && setters
    protected:
    private:
        int _noOfStrings;
};

#endif // GUITAR_H
