#include "Guitar.h"
#include "Instrument.h"
#include <iostream>
using namespace std;

Guitar::Guitar():Instrument()
{
    _noOfStrings = 6;
}

Guitar::Guitar(char* name, double price, int strings):Instrument(name, price)
{
    _noOfStrings = strings;
}

Guitar::Guitar(const Guitar& other):Instrument(other)
{
    _noOfStrings = other._noOfStrings;
}

Guitar::~Guitar()
{
    cout<<"Guitar::~Guitar"<<endl;
}

void Guitar::DisplayInfo()const
{
    Instrument::DisplayInfo();
    cout<<"Nnumber of strings: "<<_noOfStrings<<endl;
}
