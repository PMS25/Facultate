#ifndef INSTRUMENT_H
#define INSTRUMENT_H

class Instrument
{
    public:
        Instrument();
        Instrument(char*, double);
        ~Instrument();
        Instrument(const Instrument& other);
        virtual void DisplayInfo()const;
    protected:
        double _price;
        char* _name;
    private:
};

#endif // INSTRUMENT_H
