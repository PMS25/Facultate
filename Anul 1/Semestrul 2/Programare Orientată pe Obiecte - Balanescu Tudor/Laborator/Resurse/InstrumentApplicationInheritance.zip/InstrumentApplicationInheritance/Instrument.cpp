#include "Instrument.h"
#include <string.h>
#include <iostream>

Instrument::Instrument()
{
    _price = 0;
    _name = "anonim";
}

Instrument::Instrument(char* name, double price)
{
    _price = price;
    _name = new char[strlen(name) + 1];
    strcpy(_name, name);
}

Instrument::Instrument(const Instrument& other)
{
    _price = other._price;
    _name = new char[strlen(other._name) + 1];
    strcpy(_name, other._name);
}

void Instrument::DisplayInfo()const
{
    std::cout<<"name: "<<_name<<std::endl;
    std::cout<<"price: "<<_price<<std::endl;
}

Instrument::~Instrument()
{
    delete[] _name;
    std::cout<<"Instrument::~Instrument"<<std::endl;
}

