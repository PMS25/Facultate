﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CalculatorApp;

namespace CalculatorUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //verificati ca sunt umplute casetele de text
            //pentru cei doi operanzi

            //se transforma textul in double

            //se creaza un obiect Calculator care efectueaza operatia

            if (string.IsNullOrEmpty(textBox_op1.Text))
            {
                MessageBox.Show("primul operand nu poate fi empty.");
                return;
            }

            if (string.IsNullOrEmpty(textBox_op2.Text))
            {
                MessageBox.Show("al doilea operand nu poate fi empty.");
                return;
            }

            double op1 = 0;
            if (!double.TryParse(textBox_op1.Text, out op1))
            {
                MessageBox.Show(string.Format("{0} nu este numar.", textBox_op1.Text));
                return;
            }

            double op2 = 0;
            if (!double.TryParse(textBox_op2.Text, out op2))
            {
                MessageBox.Show(string.Format("{0} nu este numar.", textBox_op2.Text));
                return;
            }


            Calculator c = new Calculator(op1, op2);
            textBox_result.Text = c.Sum().ToString();
        }
    }
}
