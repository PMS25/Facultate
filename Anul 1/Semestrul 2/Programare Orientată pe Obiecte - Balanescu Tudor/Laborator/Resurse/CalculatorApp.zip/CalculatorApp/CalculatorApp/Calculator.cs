﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorApp
{
    public class Calculator
    {
        private double _a;
        private double _b;

        //constructori
        public Calculator(double a, double b)
        {
            _a = a;
            _b = b;
        }

        //proprietati
        public double A
        {
            get { return _a; }
            set { _a = value; }
        }

        //metode de calcul

        public double Sum()
        {
            return _a + _b;
        }

        //-, *, /, sqrt
    }
}
