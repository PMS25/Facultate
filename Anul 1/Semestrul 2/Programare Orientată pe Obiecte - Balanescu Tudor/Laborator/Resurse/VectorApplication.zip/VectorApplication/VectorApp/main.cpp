#include <iostream>

using namespace std;

//(v1,v2,...vn) sir de n elemente numere reale

//suma, produs cartezian, afisare la consola, citire
class Vector
{
    private:
        int _size; //dimensiunea
        double* _elem; //elementele
    public:
        //constructorii
        //sunt apelati automat la definirea obiectului!
        //pot fi supraincarcati (mai multi intr-o clasa)
        //au acelasi nume ca si clasa
        //nu returneaza nici un tip
        Vector(); //default
        Vector(int, double*); //de initializare
        Vector(int);
        Vector(const Vector&); //de copiere

        //destructor
        ~Vector();

        //metode de tip set
        void SetElement(int, double);
        double GetElement(int);

        void Display();
        void Read();

        //RECOMANDARE: obiectele se transmit prin referinta constanta ca parametrii atunci
        //cand nu se doreste modificarea acestora in functie!!
        //este mai eficient!! daca le transmitem prin valoarea, se va crea o copie!!
        Vector Add(const Vector&);
        double ProdScalar(const Vector&);
};

Vector::Vector()
{
    _size = 0;
    _elem = 0;
}

Vector::Vector(int size, double* elem)
{
    _size = size;
    _elem = new double[size];
    for(int i = 0; i < size; i++)
    {
        _elem[i] = elem[i];
    }
}

Vector::Vector(int size)
{
    _size = size;
    _elem = new double[size];
    for(int i = 0; i < size; i++)
    {
        _elem[i] = 0;
    }
}

Vector::Vector(const Vector& v)
{
    _size = v._size;
    _elem = new double[v._size];
    for(int i = 0; i < v._size; i++)
    {
        _elem[i] = v._elem[i];
    }
}

Vector::~Vector()
{
    if (_elem != 0)
    {
        delete[] _elem;
    }
}

void Vector::SetElement(int position, double newElement)
{
   if (_elem != 0 && _size > 0 && position >=0 && position < _size)
   {
       _elem[position] = newElement;
   }
}

double Vector::GetElement(int position)
{
    if (position >=0 && position < _size && _elem != 0)
    {
        return _elem[position];
    }

    //in mod normal se arunca o exceptie
    //throw exception("incorrect value for position");
    return 0;
}

void Vector::Display()
{
    if (_size == 0)
    {
        cout<<"[]"<<endl;
    }
    else
    {
        cout<<"[";
        for(int i = 0; i < _size - 1; i++)
        {
            cout<<_elem[i]<<", ";
        }
        cout<<_elem[_size-1]<<"]"<<endl;
    }
}

void Vector::Read()
{
    int newSize;

    cout<<"Size: ";
    cin>> newSize;

    if (newSize != _size || _elem == 0)
    {
        if (_elem != 0)
        {
            delete[] _elem;
        }

        _elem = new double[newSize];
    }

    _size = newSize;

    for(int i = 0; i <= _size - 1; i++)
    {
        cout<<"elem["<<i<<"]=";
        cin>>_elem[i];
    }
}

Vector Vector::Add(const Vector& v)
{
    //notiunea de obiect curent
    //orice obiect contine un pointer care memoreaza adresa sa de inceput
    //pointerul se numeste this;
    //prin urmare *this este chiar obiectul
    //*this este obiectul care face apel la o metoda a sa
    //this->_size
    if (this->_size != v._size)
    {
        cout<<"dimensiuni diferite; nu se poate efectua suma."<<endl;
        return *this; //returnam obiectul curent; nu se poate face suma
    }

    //adunam *this cu v; rezultatul il salvam in s
    Vector s(v._size);

    for(int i = 0; i < s._size; i++)
    {
        s._elem[i] = this->_elem[i] + v._elem[i];
    }

    return s;
}

int main()
{

    Vector v1;
    Vector v2;

    v1.Read();
    v2.Read();

    v1.Display();
    v2.Display();

    v1.Add(v2).Display();

    return 0;
}
