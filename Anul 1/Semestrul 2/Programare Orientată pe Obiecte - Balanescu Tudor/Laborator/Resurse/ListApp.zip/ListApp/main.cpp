#include <iostream>

using namespace std;

//sa se implementeze o aplicatie
//pentru o lista de numere intregi
//l1: 2,3,51,2
//l2: 5, 4, 6

//operatii: afisare, citire consola
//concatenarea a doua liste!
//concatenarea unui element la o lista (la final)
//eliminarea unui element din lista (final)

//obs: memoria va fi alocata dinamic pentru elemente
//re-alocare in caz de inserare, eliminare!

class MyList
{
    private:
        int _count; //numarul de elemente
        int* _elem; //elementele (alocare dinamica pe HEAP)
    public:
        //constructori
        MyList(); //default
        MyList(int); //de initializare
        MyList(int, int*); //de initializare
        MyList(const MyList&); //de copiere

        void Display(); //fara nici un parametru
        void Read();
        MyList& Insert(int);
        MyList Concat(const MyList&); //se obtine un nou obiect prin alipirea obiectului
        //care face apelul (*this) cu obiectul transmis ca parametru!!
        void Init(int, int*);
        void Dispose();
};

//empty list
MyList::MyList()
{
    this->_count = 0;
    this-> _elem = 0;
}


MyList::MyList(int count)
{
    _count = count;
    _elem = new int[count];

    for(int i = 0; i < count; i++)
    {
        _elem[i] = 0;
    }
}

MyList::MyList(int count, int* elem)
{
    _count = count;
    _elem = new int[count];

    for(int i = 0; i < count; i++)
    {
        _elem[i] = elem[i];
    }
}

//constructor de copiere, semantica prin valoare. Adica???
//nu este implementat prin copiere de pointeri
//_elem = l._elem
//exista si semantica prin referinta: se copiaza adrese de memorie
MyList::MyList(const MyList& l)
{
    _count = l._count;
    _elem = new int[l._count];

    for(int i = 0; i < l._count; i++)
    {
        _elem[i] = l._elem[i];
    }
}



//1: stiati ca o structura poate sa contina modificatori de
//acces? public, private

//2: datele se ascund!!!!!! cu private (incapsulare)

//3: stiati ca o structura poate sa contina si functii????

void MyList::Display()
{
    //lista l se va afisa la consola
    if (_count == 0)
    {
        cout<<"()"<<endl;
        return;
    }

    cout<<"(";

    for(int i = 0; i < _count - 1; i++)
    {
        cout<<_elem[i]<<", ";
    }

    cout<<_elem[_count - 1]<<")"<<endl;
}

void MyList::Read()
{
    if (_elem != 0) //avem deja elemente alocate!!!
    {
        delete[] _elem;
    }

    cout<<"count: ";
    cin>>_count;

    _elem = new int[_count];

    for(int i = 0; i < _count; i++)
    {
        cout<<"["<<i<<"]: ";
        cin>>_elem[i];
    }
}

//initializarea unei liste cu param.
void MyList::Init(int count, int* elem)
{
    _count = count;
    _elem = new int[count];

    for(int i = 0; i < count; i++)
    {
        _elem[i] = elem[i];
    }
}

//elibereaza spatiul ocupat de o lista
void MyList::Dispose()
{
    if (_elem != 0)
    {
        delete[] _elem;
    }
}

//(3,2,6) + 89 => (3,2,6,89)
MyList& MyList::Insert(int value)
{
    int* temp = new int[_count + 1];

    for(int i = 0; i < _count; i++)
    {
        temp[i] = _elem[i];
    }

    temp[_count]=value;
    _count++;
    delete[] _elem;
    _elem = temp;

    return *this; //in ce se transforma l??? raspuns corect:
}

MyList MyList::Concat(const MyList& l)
{
    MyList result;
    result._count = _count + l._count;
    result._elem = new int[_count + l._count];

    for(int i = 0; i < (*this)._count; i++)
    {
        result._elem[i] = _elem[i];
    }

    for(int i = 0; i < l._count; i++)
    {
        result._elem[_count + i] = l._elem[i];
    }

    return result;
}
//obs despre constructori:
//(1) au acelasi nume ca si clasa
//(2) nu au tip returnat (nici macar void)
//(3) pot fi supraincarcati (overloading): mai multi cu lista de param. diferita
//(4) sunt apelati automat la definirea obiectului (cand se aloca spatiu pentru variabila)!!!
//(5) daca o clasa nu contie constr. de copiere, se va genera automat unul!!!
//cel auto-generat copiaza element cu element datele
//DE ACEEA, se recomanda ca orice clasa C++ sa contina
//o definitie explicita a unui constr. de copiere
//(6) constr. de copiere se apeleaza automa in urmatoarele situatii
//(6.1) MyList l1, l2(l1);
//(6.2) Cand o functie are parametru transmis prin valoare
//void f(MyList l) {//aici se creaza o copie a lui l}
//(6.3) Cand o functie intoarce rezultatul prin valoare
//MyList g(){/// valoarea returnata este o copie!!!}

int main()
{
    MyList l, l1, l2; //aici se apeleaza automat primul constructor
    int v[5] = {3, 7, 2, 45, 67};
    MyList l3(5, v); //aici se apeleaza automat contr. 3
    MyList l4=l3; //sau l4(l3) aici cel de copiere
    //l4=l; //operatorul de atribuire!!!
    //Read(l);
    MyList* p; //aici  nu se apeleaza nici un constr;
    MyList& r=l; //aici nu se apeleaza nici un constr;

    //l.Init(5, v);
    //l.Display();

    //Display(Insert(Insert(l, 123), 125));

    //l.Insert(123).Insert(125).Display();

    l1.Read();
    l2.Read();
    l1.Concat(l2).Display();

    l.Dispose();
    l1.Dispose();
    l2.Dispose();

    return 0;
}
