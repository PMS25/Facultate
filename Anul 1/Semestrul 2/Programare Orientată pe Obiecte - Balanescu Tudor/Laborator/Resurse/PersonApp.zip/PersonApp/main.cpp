#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;
//(1) mostenire
//(2) constructorii in cadrul mostenirii
//(3) destructorul
//(4) redefinirea metodelor (overiding)
//(5) metode virtuale (functii virtuale)
//(6) polimorfism

class Person
{
        private:
            int _age;
            char* _name;
        public:
            Person();
            Person(int,char*);
            Person(const Person&);

            //metode get si set
            int GetAge();
            void SetAge(int);

            //metode afisare la consola
            virtual void Display();

            ~Person();

};

Person::Person()
{
    _age = 0;
    _name = 0;
}

Person::Person(int age, char* name)
{
    this->_age = age;
    this->_name = new char[strlen(name)+1];
    strcpy(this->_name, name);
}

Person::Person(const Person& pers)
{
    this->_age = pers._age;
    this->_name = new char[strlen(pers._name)+1];
    strcpy(this->_name, pers._name);
}

int Person::GetAge()
{
    return _age;
}

void Person::SetAge(int age)
{
    this->_age = age;
}

void Person::Display()
{
    cout<<"Age: "<<_age<<endl;
    cout<<"Name: "<<_name<<endl;
}

Person::~Person()
{
    if (_name != 0)
    {
        delete[] _name;
    }
}

//(1) In C++ se pot construi noi clase pornind de la
//o clasa deja existenta prin "mostenire"

//noua clasa mosteneste (are in componenta) toate
//elementele clasei parinte (clasa de baza)

class Student : public Person
{
    //elemente specifice (date specifice)
    private:
        char* _faculty;
    public:
        Student();
        Student(int, char*, char*);
        Student(const Student&);

        //metode specifice
        char* GetFaculty();
        void SetFaculty(char*);

        //override (suprasrierea/redefinirea metodei Display)
        void Display(); //aceeasi semnatura ca in Person

        ~Student();

};

Student::Student():Person() //se apeleaza varianta mostenita (de la Person)
{
    _faculty = 0;
}

Student::Student(int age, char* name, char* faculty):Person(age, name)
{
    _faculty = new char[strlen(faculty)];
    strcpy(_faculty, faculty);
}

Student::Student(const Student& s):Person(s)
{
    _faculty = new char[strlen(s._faculty)];
    strcpy(_faculty, s._faculty);
}

char* Student::GetFaculty()
{
    return _faculty;
}

void Student::SetFaculty(char* faculty)
{
    if (_faculty != 0)
    {
        delete[] _faculty;
    }

    _faculty = new char[strlen(faculty) + 1];
    strcpy(_faculty, faculty);
}

void Student::Display()
{
    Person::Display(); //reutilizare versiune mostenita!
    cout<<"Faculty: "<<_faculty<<endl;
}


//pentru destructori ordinea de apelare
//este: clasa derivata => clasa de baza (Student ==> Person)
Student::~Student()
{
    if(_faculty != 0)
    {
        delete[] _faculty;
    }
}

void Prel(Person* p)
{
    p->Display();
}

int main()
{
    Person p(20, "Cocolino");
    p.Display();

    Student s(60, "Restantier", "Mate-Info");
    //s are in componenta doua versiuni pentru Display:
    //Person::Display si Student::Display

    Person& ref=s;

    Person* pers = &s;

    Prel(pers);
    Prel(new Student(35, "KOKO", "LINO"));

    //ref.Display();

    return 0;
}

//mecanismul functiilor virtuale:
//cand avem mostenire si se redefineste o metoda,
//DACA obiectele sunt manevrate prin pointeri/referinte
//catre clasa de baza si initializate cu obiecte
//de tip diverse clase derivate, se va selecta
//versiunea tipului efectiv al obiectului!!!


