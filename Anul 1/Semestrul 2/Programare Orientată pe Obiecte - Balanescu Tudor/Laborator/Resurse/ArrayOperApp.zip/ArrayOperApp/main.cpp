#include <iostream>

using namespace std;

//supraincarcarea operatorilor
//vector de numere intregi
class Array
{
  public:
    Array();
    Array(int,int*);
    Array(const Array&);
    ~Array();

    //a1 a2 de tip Array, a1+a2 (a1.operator+(a2))=> concatenarea elementelor
    //a1 + 5;  7 + a1
    //a1 - 5;  5 - a1
    //cout<<a1<<a2; cin>>a1>>a2
    //a1=a2
    //if(a1 == a2) ...
    //a1[3] => elementul de la indicele 3

    Array operator+(const Array&)const;
    Array operator+(int)const;
    friend Array operator+(int, const Array&);
    //cout<<a1; cout este obiect de tip ostream
    friend ostream& operator<<(ostream&, const Array&);
    friend istream& operator>>(istream&, Array&);
    int operator[](int);

    //operatorul =
    //a1=(a2=a3) ==> a1.operator=(a2.operator=(a3))
    //totdeauna cu functie membra (nu friend!!)
    Array& operator=(const Array&);

  private:
        int* _elem;
        int _count;
};

Array::Array()
{
    _count = 0;
    _elem = 0;
}

Array::Array(int count, int* elem)
{
    _count = count;
    _elem = new int[count];

    for(int i = 0; i < count; i++)
    {
        _elem[i] = elem[i];
    }
}

Array::Array(const Array& a)
{
    _count = a._count;
    _elem = new int[a._count];

    for(int i = 0; i < a._count; i++)
    {
        _elem[i] = a._elem[i];
    }
}

Array::~Array()
{
    if (_elem != 0)
    {
        delete[] _elem;
    }
}

//operatorii << si >>
ostream& operator<<(ostream& out, const Array& a)
{
    if (a._count == 0)
    {
        out<<"()"<<endl;
        return out;
    }

    out<<"(";
    for(int i = 0; i < a._count - 1; i++)
    {
        out<<a._elem[i]<<", ";
    }
    out<<a._elem[a._count -1]<<")"<<endl;

    return out;
}

istream& operator>>(istream& in, Array& a)
{
    cout<<"count: "; in>>a._count;
    if (a._elem != 0)
    {
        delete[] a._elem;
    }

    a._elem = new int[a._count];
    for(int i = 0; i < a._count; i++)
    {
        cout<<"a["<<i<<"]: ";
        in>>a._elem[i];
    }

    return in;
}

Array Array::operator+(const Array& a)const
{
    //*this + a
    Array result;
    result._elem = new int[_count + a._count];

    for(int i = 0; i < _count; i++)
    {
        result._elem[i] = _elem[i];
    }

    for(int i = 0; i < a._count; i++)
    {
        result._elem[i + _count] = a._elem[i];
    }

    result._count = _count + a._count;

    return result;
}

Array Array::operator+(int value)const
{
    int* elem = new int[1];
    elem[0] = value;
    return *this + Array(1,elem);
}

Array operator+(int value, const Array& a)
{
    int* elem = new int[1];
    elem[0] = value;
    return Array(1,elem) + a;
}

int Array::operator[](int position)
{
    if (position >= 0 && position < _count && _count > 0)
    {
        return _elem[position];
    }

    cout<<"index out of bound!"<<endl;
    return -1;
}

Array& Array::operator=(const Array& a)
{
    //pas1: verificare a=a
    if (this == &a)
    {
        return *this;
    }

    //pas2: eliberez memoria ocupata de obiectul curent
    this->~Array();

    //realocare
    _elem = new int[a._count];
    //copiez elementele
    for(int i = 0; i < a._count; i++)
    {
        _elem[i]=a._elem[i];
    }
    _count = a._count;

    return *this;
}

int main()
{

    Array a1,a2;

    //cin>>a1>>a2;
    //cout<<a1<<a2<<a1+a2<<a1+7;

    cin>>a1;
    cout<<a1[2];


    return 0;
}
