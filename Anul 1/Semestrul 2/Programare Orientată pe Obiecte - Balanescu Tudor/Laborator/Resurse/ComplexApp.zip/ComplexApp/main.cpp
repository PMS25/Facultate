#include <iostream>
#include <math.h>

using namespace std;

//Sa se realizeze o aplicatie
//pentru operatii cu numere complexe
//a+b*i
//afisare, citire, suma, diferenta, produs
//calcul modul

class Complex
{
  private:
        double* _re;
        double* _im;
  public:
        Complex();
        Complex(double, double);
        Complex(const Complex&);

        void Display();
        void Read();

        Complex Add(const Complex&); //c1.Add(c2)
        Complex Dif(const Complex&);
        Complex Mult(const Complex&);

        double Modul();

        double GetRe();
        double GetIm();

        void SetRe(double);
        void SetIm(double);

        ~Complex();
};

Complex::Complex():
    _re(new double(0)),
    _im(new double(0))
{
    //_re = new double(0);
    //_im = new double(0);
}

Complex::Complex(double a, double b)
{
    _re = new double(a);
    _im = new double(b);
}

Complex::Complex(const Complex& c)
{
   _re = new double(*c._re);
   _im = new double(*c._im);
}

void Complex::Read()
{
    cout<<"re: "; cin>>*_re;
    cout<<"im: "; cin>>*_im;
}

Complex Complex::Add(const Complex& c)
{
    //se aduna valorile *this si c (ambele
    //au in structura lor _re si _im care sunt pointeri
    return Complex( *_re+*c._re, *_im + *c._im);
}

double Complex::Modul()
{
    return sqrt((*_re) * (*_re) + (*_im)*(*_im));
}

void Complex::Display()
{
    cout<<*_re;

    if (*_im > 0)
    {
        cout<<"+";
    }

    cout<<*_im<<"*i"<<endl;
}

Complex::~Complex()
{
    delete _re;
    delete _im;
}


int main()
{
    Complex c1,c2;
    //c.Display();
    c1.Read();
    c2.Read();

    c1.Add(c2).Display();

    return 0;
}
