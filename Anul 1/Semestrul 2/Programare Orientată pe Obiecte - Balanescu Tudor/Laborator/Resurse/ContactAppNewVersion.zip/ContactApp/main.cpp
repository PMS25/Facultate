#include <iostream>
#include <string.h>

using namespace std;
//Aplicatie: sa se realizeze o aplicatie
//in C++ pentru administrate de contacte.

//Un Contact: id, name, adress, email, phone
//operatii: initializare, afisare la consola, eliberare resurse
//modificare proprietati

//un contact reprezinta o data structurata

//Constructori:

//(i) au acelasi nume ca si clasa
//(ii) nu au tip returnat (nici macar void)
//(iii) pot fii supraincarcati (overloading) - lista de param. diferita
//(iv) sunt apelati automat!! la definirea obiectului!!!

//Obs: faceti diferenta intre declararea obiectului si definirea obiectului!!!!!!!!!
//La declararea doar specific tipul si numele
//Ex: Contact* p; //declarare
//Ex: Contact& r = c; //declarare

//Definire: declara + initializare
//Contact c; //definire
//Contact* p = new Contact; //definire (alocare dinamica)


class Contact
{
private:
  int _id;
  char* _name;
  char* _address;
  char* _email;
  char* _phone;
  int IsValidEmail(char*);

public:
  Contact();//constructor default
  Contact(int, char*, char*, char*, char*);//constr. de init.
  Contact(const Contact&);//constr. de copiere!!

  void Init(int, char*, char*, char*, char*);
  //metode getter/setter (orice obiect pentru toate datele sale ascunse
                          //trebuie saa ofere metode get si set
  void SetEmail(char*);
  char* GetEmail();

  void Display();
  Contact g();

  ~Contact(); //destructor (eliberarea memoriei)
};

Contact Contact::g()
{
    Display();
    return *this; //obiectul curent
}

//DESTRUCTOR
//Teorie: este unic intr-o clasa
//se recomanda ca orice clasa C++ sa contina un destructor
//(in special cand lucram cu memorie alocata dinamic
   //in constructori)
//se apeleaza automat la terminarea perioadei de viata
//a obiectului in cadrul aplicatiei
//Intrebare: cand expira durata de viata a unui obiect??
//A: 3 situatii diferite (cate una pentru fiecare tip
                          //de memorie
//Orice aplicatie C++ lucreaza cu 3 zone de memorie
//(1) stiva (stack) - aici sunt alocate variabile automatice - locale
//(2) static (memoria gloabala - toata durata aplicatiei)
//(3) HEAP (memoria alocata dinamic)

//(1) stack - este zona de memorie utilizata pentru
//variabilele declarate local, in functii sau blocuri
//de instructiuni incadrate intre "{}"
//sunt asa numitele variabile "auto"
//(2) static - memoria este alocata la momentul compilarii
//si este ultima data eliberata (adica este valabila
//pe toate durata exectiei
//(3) HEAP - spatiu alocat cu new; sunt in viata pana cand
//se apeleaza operatorul delete
Contact::~Contact()
{
    cout<<"se distruge contactul "<<_name<<"cu id: "<<_id<<endl; //scop didactic!!
    delete[] _name;
    delete[] _email;
    delete[] _address;
    delete[] _phone;
}

//CONSTR. DE COPIERE
//are sintaxa generala K(const K&) unde K este numele clasei
//este auto-generat daca nu se declara explicit!
//varianta generata de compilator copiaza membru cu membru
//campurile obiectelor
//Recomandare: orice clasa C++ va contine un constructor
//de copiere explicit!!
//Se apeleaza automat! In ce situatii:
//(1) Contact c1, c2(c1), c3=c1;
//(2) void f(Contact c){ Contact temp=c...}
//(3) la returnare prin valoare: Contact g() {...}

Contact::Contact(const Contact& c)
{
    cout<<"se creaza prin copiere contactul "<<c._name<<endl;

    Init(c._id + 1, c._name, c._address, c._email, c._phone);
}

Contact::Contact(int id, char* name, char* address, char* email, char* phone)
{
    Init(id, name, address, email, phone);
}

Contact::Contact()
{
    Init(1, "noname", "", "", "");
}

char* Contact::GetEmail()
{
    return _email;
}

void Contact::SetEmail(char* email)
{
    if (IsValidEmail(email))
    {
        //se schimba adresa de email!!
        if (_email != 0)
        {
            delete[] _email;
        }

        _email = new char[strlen(email) + 1];
        strcpy(_email, email);
    }
    else
    {
        cout<<"invalid email!"<<endl;
    }
}

int Contact::IsValidEmail(char* email)
{
    //ToDo!!
    return 1;
}

void Contact::Init(int id, char* name, char* address, char* email, char* phone)
{
    (*this)._id = id; //*this este obiectul curent!!!
    //obiect curent = obiectul care prefixeaza (cu .) apelul unei metode
    //c._name = name; //asa, se copiaza adresa de memorie! de evitat!

    //semantica prin valoare
    _name = new char[strlen(name) + 1];
    strcpy(_name, name);

    _address = new char[strlen(address) + 1];
    strcpy(_address, address);

    _email = new char[strlen(email) + 1];
    strcpy(_email, email);

    _phone = new char[strlen(phone) + 1];
    strcpy(_phone, phone);
}

void Contact::Display()
{
    cout<<"Id: "<<_id<<endl;
    cout<<"Name: "<<_name<<endl;
    cout<<"Email: "<<_email<<endl;
    cout<<"Address "<<_address<<endl;
    cout<<"Phone "<<_phone<<endl;
}

void f()
{
    Contact c(1, "Bobolino", "coco@upit.ro", "pitesti", "112");
    c.Display();
    static Contact c1(1, "Rexolino", "coco@upit.ro", "pitesti", "112");
    Contact* p = new Contact(1, "Budala", "coco@upit.ro", "pitesti", "112");
    p->Display();
    delete p; //aici se apeleaza automat destr.!!!
}

Contact g()
{
    Contact c;

    c.Display();

    return c;
}

int main()
{
   Contact c(1, "Cocolino", "coco@upit.ro", "pitesti", "112"); //alocare pe stack
   //Contact ccc = g();
   c.g();
   //f();

   //{
   // Contact c(1, "Cocolino", "coco@upit.ro", "pitesti", "112"); //alocare pe stack
    //.....
   //}
    //aici a se scoate din varful stivei!!
    //cout<<"syz"<<endl;
    //Contact c(1, "Cocolino", "coco@upit.ro", "pitesti", "112"); //aici se apeleaza automat constr. default
    //c.Display();

    //c.Init(1, "Cocolino", "coco@upit.ro", "pitesti", "112");
    //c.Display();

    return 0;
}
