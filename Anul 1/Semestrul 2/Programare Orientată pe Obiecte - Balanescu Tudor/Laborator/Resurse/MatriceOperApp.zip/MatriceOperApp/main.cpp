#include <iostream>

using namespace std;
//operatii cu matrice

class Matrix
{
  public:
    //constructori
    //destructor
    //cout<<m
    //cin>>m
    //m1+m2, m1*m2, ++m, m++ (se aduna matricea unitate la m - daca m este matrice patratica)
    // !m : transpunerea obiectului curent !!m

  private:
        int _m; //numarul de linii
        int _n; //numarul de coloane
        int* _elements; //reprezentare liniara, ca vector
};
/*
De exemplu, matricea

2, 3, 5, 6
4, 5, 7, 3

se va memora in vectorul liniar
2, 3, 5, 6, 4, 5, 7, 3

*/

/*
Matrix::Matrix(...)
{
    //...
    _elements = new int[_m*_n];
    //....
}
*/

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
