#include <iostream>

using namespace std;

//Supraincarcarea operatorilo in C++
//Problema: sa se implementeze intr-o clasa C++
//operatii cu numere rationale (a/b, b != 0)

class Rational
{
  private:
        int* a; //numarator (alocare dinamica in constr)
        int* b; //numitor (alocare dinamica in constr.)
        int Cmmdc(int, int);
  public:
        Rational();
        Rational(int, int);
        Rational(const Rational&);

        void Display(); //afisare la consola
        void Read();

        //getter/setter
        int GetA();
        int GetB();
        void SetA(int);
        void SetB(int);

        Rational& Simplifica(); //returneaza obiectul curent (*this) - fractia simplificata

        //suma a doua fractii
        Rational Sum(const Rational&);
        Rational operator+(const Rational&); //supraincarcarea operatorului +

        //f1*f2, f1-f2, f1/f2

        //supraincarcarea operatorului de atribuire (=)
        Rational& operator=(const Rational&);

        friend ostream& operator<<(ostream&, const Rational&);
        friend istream& operator>>(istream&, Rational&);

        ~Rational();
};

Rational& Rational::operator=(const Rational& r)
{
    //schema de supraincarcare trebuie sa fie intotdeauna urmatoarea
    //1. se verifica autoatribuirea (f=f)
    if (this == &r)
    {
        return *this;
    }

    //2. se elibereaza resursele ocupate de obiectul curent!!
    this->~Rational(); //apelez explicit destr.

    //3. realocam spatiu de memorie;
    a = new int;
    b = new int;

    //4. copiem noile valori
    *a = *r.a;
    *b = *r.b;

    //5. returnez obiectul curent (modificat), prin referinta!!! (sa nu fie creata copie a sa!!!)
    return *this;
}

ostream& operator<<(ostream& out, const Rational& r)
{
    out<<*r.a<<"/"<<*r.b<<endl;
    return out; //pentru folosirea inlantuita a operatorului (cout<<f<<g)
}

istream& operator>>(istream& in, Rational& r)
{
    cout<<"a: ";
    in>>*r.a;
    cout<<"b: ";
    in>>*r.b;
    return in;
}

Rational::Rational()
{
    //fractia "0"
    a = new int(0);
    b = new int(1);
}

Rational::Rational(int a, int b)
{
    this -> a = new int(a);
    this -> b = new int(b);
}

Rational::Rational(const Rational& r)
{
    a = new int(*r.a);
    b = new int(*r.b);
}

int Rational::GetA()
{
    return *a;
}

int Rational::GetB()
{
    return *b;
}

void Rational::SetA(int a)
{
    *(this -> a) = a;
}

void Rational::SetB(int b)
{
    *(this -> b) = b;
}

void Rational::Display()
{
    cout<<*a<<"/"<<*b<<endl;
}

void Rational::Read()
{
    cout<<"a: "; cin>>*a;
    cout<<"b: "; cin>>*b;
}

int Rational::Cmmdc(int x, int y)
{
    int xx = x < 0 ? -x : x;
    int yy = y < 0 ? -y : y;

    while (xx != yy)
    {
        if (xx > yy)
        {
            xx -= yy;
        }
        else
        {
            yy -=xx;
        }
    }

    return xx;
}

Rational& Rational::Simplifica()
{
    int d = Cmmdc(*a, *b);
    *a /= d;
    *b /= d;
    return *this; //returnez obiectul curent simplificat (prin referinta, ca sa nu returneze o copie a sa!!!!)
}

Rational Rational::Sum(const Rational& r)
{
    Rational s( (*a) * (*r.b) + (*b) * (*r.a)  ,(*b) * (*r.b));
    return s.Simplifica(); //return suma simplificata
}

Rational Rational::operator+(const Rational& r)
{
    Rational s( (*a) * (*r.b) + (*b) * (*r.a)  ,(*b) * (*r.b));
    return s.Simplifica(); //return suma simplificata
}

Rational::~Rational()
{
    delete a;
    delete b;
}

int main()
{
    Rational f1,f2;

    //f1.Read();
    //f2.Read();

    //f1.Display();
    //f2.Display();
    //f1.Sum(f2).Display();//calculez suma si afizes rezultatul

    //(f1+f2).Display();//operatorul + supraincarcat!!!

    //cum ar fi sa afisam un Rational 'r' cu cout<<r ????
    //Solutie: suprincarcam operatorul <<
    //Stiati ca 'cout' este obiect de tip ostream?????
    //Stiati ca 'cin' este obiect de tip istream????
    //operatorul << este deja supraincarcat in clasa ostream
    //operatorul >> este deja supraincarcat in clasa istream

    //oferim si noi o noua semnificatie pentru cele 2;
    //afisare la consola + citire de la consola;
    //se poate face acest lucru DOAR cu functii operator friend (globale)
    //deoarece primul obiect (operand) in acest caz
    //nu mai este de acelasi tip cu al clasei (Raional)
    cin>>f1>>f2;
    cout<<f1<<f2<<f1+f2;


    return 0;
}
