#include <iostream>

using namespace std;

//operatii cu numere complexe, supraincarcarea
//operatorilor

//expresii diferite cu operatori
//Daca c1 si c2 sunt de tip Complex sa aiba sens
//c1+c2 => Complex (suma lor)
//c1+3
//5.2+c1
//== if(c1==c2)
//operatorul '='
//cout<<c1<<c2
//cin>>c1>>c2

class Complex
{
    public:
        Complex()
        {
            _re = new double(0);
            _im = new double(0);

        }

        Complex(double r, double i)
        {
            _re = new double(r);
            _im = new double(i);

        }

        Complex(const Complex& c)
        {
           _re = new double(*c._re);
            _im = new double(*c._im);
        }

        ~Complex()
        {
            delete _re;
            delete _im;
        }

        //c1+c2
        Complex operator+(const Complex&)const; //c1.operator+(c2) <==> c1+c2
        Complex operator+(double)const;
        //5.2 + c - functii GLOBALE de tip friend
        friend Complex operator+(double, const Complex&);
        //cout<<c<<
        //ce este 'cout'? Obiect de tip ostream
        friend ostream& operator<<(ostream&, const Complex&);
        //cin>>c
        friend istream& operator>>(istream&, Complex&);

        Complex& operator=(const Complex&);

        //forma prefixata
        Complex& operator++();
        //postfixata c++
        Complex operator++(int);
    private:
        double* _re;
        double* _im;
};

Complex Complex::operator+(const Complex& c)const
{
    return Complex(*_re + *c._re, *_im + *c._im);
}

Complex Complex::operator+(double d)const
{
    return *this + Complex(d,0);
}

Complex operator+(double d, const Complex& c)
{
    return c + d;
}

ostream& operator<<(ostream& out, const Complex& c)
{
    out<<"("<<*c._re<<","<<*c._im<<")"<<endl;

    return out;
}

istream& operator>>(istream& in, Complex& c)
{
    cout<<"re: "; in>>*c._re;
    cout<<"im: "; in>>*c._im;

    return in;
}

//Supraincarcarea operatorlui =
//Obs: Daca nu este supraincarcat, se va genera automat
//o supraincarcare!! (copiere membru cu membru a obiectelor)

//(1) Totdeauna cu functie membra
//(2) Se va pastra semnificatia obisnuita, ordinea de evaluare, posibilitatea de a fo utilizat inlantuit
// c1=(c2=c3)
//(3) Se verifica auto=atribuirea c=c
//schema generala este urmatoarea (pentru o clasa K)

/*
K& operator=(const K& source)
{
    //pas1: se verifica auto-atribuirea
    if(this == &source)
    {
        return *this;
    }

    //pas2: se elibereaza spatiul ocupat de obiectul curent
    //pas3: se aloca spatiu nou
    //pas4: se copiaza valorile din source
    return *this;
}
*/

Complex& Complex::operator=(const Complex& c)
{
    if (this == &c)
    {
        return *this;
    }

    this->~Complex();

    _re = new double(*c._re);
    _im = new double(*c._im);

    return *this;
}

//forma prefixata!!! '++'
Complex& Complex::operator++()
{
     //se modifica obiectul curent!
     ++(*_re);
     return *this;
}

Complex Complex::operator++(int)
{
    Complex temp(*this); //salvez o copie a ob. curent
    (*_re)++;
    return temp;
}

int main()
{
    Complex c1(2,3),c2;

/*
    cin>>c1>>c2;

    cout<<c1<<c2<<c1+c2<<c1+5<<7+c2;

    cout<<endl<<endl;

    operator<<(operator<<(operator<<(operator<<(operator<<(cout,c1), c2), c1.operator+(c2)), c1.operator+(5)), operator+(7,c2));
*/
    //c2 = c1; //

    cout<<c1++<<c1;

    return 0;
}
