#include <iostream>

using namespace std;

//sa se implementeze o clasa DateTime
class DateTime
{
  public:
    //constructori
    DateTime();//1900-01-01:00:00:00
    DateTime(int,int,int);//yyyy-mm-dd:00:00:00
    DateTime(int,int,int,int,int,int);
    DateTime(char*);//yyyy-mm-dd:hh:MM:ss "2015-02-03:12:00:05"
    DateTime(const DateTime&);
    ~DateTime();

    char* ToString();//reprezentare ca sir de caractere
    //a obiectului curent
    DateTime& AddYear(int);//adauga la data curent un numar de ani (poate fi negativ!)
    DateTime& AddMonth(int);
    DateTime& AddDay(int);
    DateTime& AddHour(int);

    int GetYear();
    int GetMonth();
    int GetDay();
    int GetHour();
    int GetMinute();
    int GetSecond();

    void Display();
    void Read();

  private:
    int* _year;  //o valoare de tip int alocata dinamic; new int(2000)
    int* _month;
    int* _day;
    int* _hour;
    int* _minute;
    int* _second;
};

void DateTime::Display()
{
    cout<<ToString()<<endl;
}

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
