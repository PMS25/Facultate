#include <iostream>
#include <string.h>

using namespace std;
///Aplicatie: Sa se implementeze o clasa utilizator (User)
//va contine atributele _username si _password de tip char*

class User
{
  private:
    char* _username;
    char* _password;
  public:
    //constructori
    User();
    User(char*, char*);
    User(const User&);

    //metode get si set (getter/setter) pentru cele doua atribute

    void DisplayInfo(); //afisare la consola

    void SetPassword(char*);//schimba parola
    void SetUsername(char*);//schimba username-ul

    int CheckPassword();
     //verifica daca parola respecta anumite
    //conditii: cel putin 8 caractere; contine cel putin o cifra; contine cel
    //putin unul din caracterele {@,#,&}
    //metoda returneaza 0 daca parola nu e valida; 1 daca parola
    //este valida;
    //Obs: metoda va fi utilizata in constructori si in metoda
    //'SetPassword'

    ~User(); //destructorul
};


int User::CheckPassword()
{
    //aici verificam daca _password respecta conditii impuse
    if (_password == 0)
    {
        return 0;
    }

    int size = strlen(_password);

    if (size < 8)
    {
        cout<<"size must be greater than 8."<<endl;
        return 0;
    }

    int digit = 0;
    int ch = 0;

    for(int i = 0; i <= size; i++)
    {
        if (isdigit(_password[i]))
        {
            digit = 1;
        }

        if (_password[i]== '@' || _password[i] == '#' || _password[i] == '&')
        {
            ch = 1;
        }

        if (digit == 1 && ch == 1)
        {
            break;
        }
    }

    if (digit == 1 && ch == 1)
    {
        return 1;
    }
    else
    {
        if (digit == 0)
        {
            cout << "invalid password; no digit;"<<endl;
        }

        if (ch == 0)
        {
            cout << "invalid password; no char from {@,#,&}"<<endl;
        }

        return 0;
    }
}

User::User(char* u, char* p)
{
    if (u != 0)
    {
        _username = new char[strlen(u) + 1];
        strcpy(_username, u);
    }
    else
    {
        _username = 0;
    }

    if (p != 0)
    {
        _password = new char[strlen(p) + 1];
        strcpy(_password, p);
    }
    else
    {
        _password = 0;
    }

    if (CheckPassword() == 0)
    {
        cout << "invalid password"<<endl;
        delete[] _password;
        _password = 0;
    }
}

User::~User()
{
    if (_username != 0)
    {
        delete[] _username;
    }

    if (_password != 0)
    {
        delete[] _password;
    }
}

void User::DisplayInfo()
{
    cout<<"Username: "<<_username<<endl;
    cout<<"Password: "<<_password<<endl;
}

int main()
{
    User u("popescu", "9i&@no");
    u.DisplayInfo();


    return 0;
}
