﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentApp;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args) //args reprezinta un array de string (eventuali parametrii din command line)
        {
            Student s;
            //in C# obiectele sunt create dinamic (cu new) pe heap
            s = new Student(); //aici!!
            s.Id = 5;
            s.Name = "Popescu";
            s.Faculty = "Info";

            s.AddGrade(new CourseGrade() 
            { 
                CourseName = "POO",
                Grade = 7.5
            });

            s.AddGrade(new CourseGrade()
            {
                CourseName = "Baze de Date",
                Grade = 5
            });

            s.AddGrade(new CourseGrade()
            {
                CourseName = "Grafuri",
                Grade = 5
            });


            StudentList sl = new StudentList();                        
            sl.Add(s);
            sl.Add(s);
            sl.Add(s);
            sl.AddGrade(5, "Bazele Informaticii", 8.5);

            sl.SaveOnDisk("Students.txt");

            Console.WriteLine(sl);

            Console.ReadKey();
        }
    }
}
