﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp
{
    //fullname StudentApp.Student
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Faculty { get; set; }
        public List<CourseGrade> Grades { get; private set; } //note examene

        public double Avg 
        {
            get 
            {
                if (Grades.Count == 0)
                {
                    return 0;
                }

                if (Grades.Any(x => x.Grade <= 4.5))
                {
                    return 0;
                }

                double s = 0;
                foreach(var value in Grades)
                {
                    s += value.Grade;
                }

                return s / Grades.Count;
            }
        }

        public Student() //constructor default
        {
            Grades = new List<CourseGrade>(); //lista vida
        } 

        public void AddGrade(CourseGrade grade)
        {
            Grades.Add(grade);
        }

        public void RemoveGrade(string courseName)
        {
            //CourseGrade cg = Grades.FirstOrDefault(x => x.CourseName == courseName);
            CourseGrade cg = null;

            foreach(CourseGrade v in Grades)
            {
                if (v.CourseName == courseName)
                {
                    cg = v;
                    break;
                }
            }

            if (cg != null)
            {
                Grades.Remove(cg);
            }
        }

        //reprezentarea ca string a obiectului curent
        //orice clasa in C# este implicit derivata dintr-o clasa parinte 'object'
        public override string ToString()
        {
            return string.Format("{0}; {1}; {2}; [{3}]; [{4}]", Id, Name, Faculty, string.Join(",", Grades), Avg);
        }

    }
}
