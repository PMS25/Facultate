﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApp
{
    //o lista de studenti
    public class StudentList
    {
        public List<Student> Students { get; private set; }

        public StudentList()
        {
            Students = new List<Student>();
        }

        public void Add(Student s)
        {
            Students.Add(s);
        }

        public void AddGrade(int id, string course, double grade)
        {
            Student s = Students.FirstOrDefault(x => x.Id == id);

            if (s != null)
            {
                s.AddGrade(new CourseGrade()
                {
                    CourseName = course,
                    Grade = grade
                });
            }
        }

        public override string ToString()
        {
            var result = "";
            foreach(var student in Students)
            {
                result = result + student.ToString() + Environment.NewLine;
            }

            return result;
        }

        public void SaveOnDisk(string fileName)
        {
            File.WriteAllText(fileName, ToString());
        }
    }
}
