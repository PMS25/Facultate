namespace Banking
{
using System;
using System.IO;

/// <summary>
///    The purpose of this class is to
///    1. record the changes made to account balances
///    2. write a copy of those changes to a text file
///    
///    This is achieved using an event raised by the 
///    BankAccount class
/// </summary>
public class Audit
{
	private string fileName;
	private StreamWriter auditFile;

	// Constructor
    public Audit(string fileToUse)
    {
        this.fileName = fileToUse;
		this.auditFile = File.AppendText(fileToUse);
    }

	// Destructor (Finalizer)
	~Audit()
	{
		this.auditFile.Close();
	}

	public void Dispose()
	{
		this.Finalize();
		GC.SuppressFinalize(this);
	}

	public void RecordTransaction(Object sender, AuditEventArgs eventData)
	{
		BankTransaction tempTrans = eventData.getTransaction();
		if (tempTrans == null) {
			return;
		}

		this.auditFile.WriteLine("Amount: {0}\tDate: {1}", tempTrans.Amount, tempTrans.When);
	}
}
}
