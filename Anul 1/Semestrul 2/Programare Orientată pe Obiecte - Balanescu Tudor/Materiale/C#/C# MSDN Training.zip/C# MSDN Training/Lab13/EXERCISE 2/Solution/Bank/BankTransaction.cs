using System;
using System.IO;

namespace Banking
{

/// <summary>
///    This class holds information about a transaction (deposit/withdraw)
///    performed on an account
/// </summary>

public class BankTransaction
{
	readonly DateTime tranDate = DateTime.Now;
	readonly decimal tranAmount;

	// Destructor (Finalizer)
	~BankTransaction()
	{
		StreamWriter swFile = File.AppendText("C:\\temp\\Transactions.dat");
		swFile.WriteLine("Date: {0}\tAmount: {1}", this.tranDate, this.tranAmount);
		swFile.Close();
	}

	public void Dispose()
	{
		this.Finalize();
		GC.SuppressFinalize(this);
	}

    public BankTransaction(decimal theAmount)
    {
		this.tranAmount = theAmount;
    }

	public decimal Amount
	{
		get { return tranAmount; }
	}

	public DateTime When
	{
		get { return tranDate; }
	}
}
}