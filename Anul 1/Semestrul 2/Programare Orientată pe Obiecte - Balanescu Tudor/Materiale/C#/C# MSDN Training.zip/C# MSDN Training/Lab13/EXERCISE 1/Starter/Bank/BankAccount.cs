using System;
using System.Collections;

namespace Banking 
{

// Delegate for the AuditingTransaction event
public delegate void AuditEventHandler(Object sender, AuditEventArgs data);

public class BankAccount 
{
	// Event used to indicate that the transaction should be audited
	private event AuditEventHandler AuditingTransaction = null;

	private long accNo;
    private decimal accBal;
    private AccountType accType;
	private Queue tranQueue = new Queue();

	// Audit trail
	private Audit accountAudit;

	// Method for subscribing to the Auditing event
	public void AuditTrail(string auditFileName)
	{
		this.accountAudit = new Audit(auditFileName);
		AuditEventHandler doAuditing = new AuditEventHandler(this.accountAudit.RecordTransaction);
		this.AddOnAuditingTransaction(doAuditing);
	}

	private static long nextNumber = 123;

	// Methods to allow subscribing to/unsubscribing from the AuditingTransaction event
	public void AddOnAuditingTransaction(AuditEventHandler handler)
	{
		this.AuditingTransaction += handler;
	}

	public void RemoveOnAuditingTransaction(AuditEventHandler handler)
	{
		this.AuditingTransaction -= handler;
	}

	// Method to raise the event and alert all subscribers
	protected virtual void OnAuditingTransaction(BankTransaction bankTrans)
	{
		if (this.AuditingTransaction != null) {
			AuditEventArgs auditTrans = new AuditEventArgs(bankTrans);
			this.AuditingTransaction(this, auditTrans);
		}
	}

	// Constructors

	internal BankAccount()
	{
        this.accNo = NextNumber();
        this.accBal = 0;
        this.accType = AccountType.Checking;
	}

	internal BankAccount(AccountType accType)
	{
        this.accNo = NextNumber();
        this.accBal = 0;
        this.accType = accType;
	}
	
	internal BankAccount(decimal balance)
    {
        this.accNo = NextNumber();
        this.accBal = balance;
        this.accType = AccountType.Checking;
    }

	internal BankAccount(AccountType accType, decimal balance)
    {
        this.accNo = NextNumber();
        this.accBal = balance;
        this.accType = accType;
    }

	// Finalizer and Dispose methods
	
	~BankAccount()
	{
		foreach (BankTransaction tran in tranQueue) {
			tran.Dispose();
		}

		this.accountAudit.Dispose();
	}

	internal void Dispose()
	{
		this.Finalize();
		GC.SuppressFinalize(this);
	}

	// Operators

	public static bool operator==(BankAccount acc1, BankAccount acc2)
	{
		if ((acc1.accNo == acc2.accNo) && (acc1.accType == acc2.accType) && (acc1.accBal == acc2.accBal)) {
			return true;
		} else {
			return false;
		}
	}

	public static bool operator!=(BankAccount acc1, BankAccount acc2)
	{
		return !(acc1 == acc2);
	}

    // Other Methods

	public override bool Equals(Object acc1)
	{
		return this == acc1;
	}

	public override string ToString()
	{
		string retVal =  "Number: " + this.accNo + "\tType: ";
		retVal += (this.accType == AccountType.Checking) ? "Checking" : "Deposit";
		retVal += "\tBalance: " + this.accBal;

		return retVal;
	}
	
	public bool Withdraw(decimal amount)
    {
        bool sufficientFunds = accBal >= amount;
        if (sufficientFunds) {
            accBal -= amount;
    		BankTransaction theTran = new BankTransaction(-amount);  // Negative amount, this a withdrawl
	    	tranQueue.Enqueue(theTran);
	    	this.OnAuditingTransaction(theTran);
        }
        return sufficientFunds;
    }
    
    public decimal Deposit(decimal amount)
    {
        accBal += amount;
		BankTransaction theTran = new BankTransaction(amount);
		tranQueue.Enqueue(theTran);
		this.OnAuditingTransaction(theTran);
        return accBal;
    }
    
    public long Number()
    {
        return accNo;
    }
    
    public decimal Balance()
    {
        return accBal;
    }
    
    public string Type()
    {
        return accType.Format();
    }

	public Queue Transactions()
	{
		return tranQueue;
	}

    private static long NextNumber()
    {
        return nextNumber++;
    }
}
}