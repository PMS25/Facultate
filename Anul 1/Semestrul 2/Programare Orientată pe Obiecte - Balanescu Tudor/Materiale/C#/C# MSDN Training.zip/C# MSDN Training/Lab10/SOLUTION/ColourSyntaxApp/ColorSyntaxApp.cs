namespace ColourSyntax
{
	using System;
    using System.IO;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;
    using System.Data;
	using CSharp;

    public class ColorSyntaxApp : System.WinForms.Form
    {
        private System.ComponentModel.Container components;
		private System.WinForms.Label label1;
		private System.WinForms.TextBox textBox1;
		private System.WinForms.RichTextBox richTextBox1;
		private System.WinForms.OpenFileDialog openFileDialog1;
		private System.WinForms.Button button1;

        public ColorSyntaxApp()
        {
            InitializeComponent();
        }

        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.richTextBox1 = new System.WinForms.RichTextBox ();
			this.button1 = new System.WinForms.Button ();
			this.label1 = new System.WinForms.Label ();
			this.openFileDialog1 = new System.WinForms.OpenFileDialog ();
			this.textBox1 = new System.WinForms.TextBox ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			richTextBox1.Size = new System.Drawing.Size (560, 392);
			richTextBox1.TabIndex = 1;
			richTextBox1.Font = new System.Drawing.Font ("Courier New", 10);
			richTextBox1.Location = new System.Drawing.Point (16, 56);
			button1.Location = new System.Drawing.Point (8, 16);
			button1.Size = new System.Drawing.Size (75, 23);
			button1.TabIndex = 0;
			button1.Text = "Open File";
			button1.Click += new System.EventHandler (this.OpenFile);
			label1.Location = new System.Drawing.Point (136, 8);
			label1.Text = "Current File";
			label1.Size = new System.Drawing.Size (64, 16);
			label1.TabIndex = 3;
			//@openFileDialog1.SetLocation (new System.Drawing.Point (7, 7));
			openFileDialog1.Filter = "*.cs";
			openFileDialog1.Title = "Open C Sharp File";
			openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler (this.openFileDialog1_FileOk);
			textBox1.Location = new System.Drawing.Point (136, 24);
			textBox1.TabIndex = 2;
			textBox1.Size = new System.Drawing.Size (184, 20);
			this.Text = "Form1";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (592, 461);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.textBox1);
			this.Controls.Add (this.richTextBox1);
			this.Controls.Add (this.button1);
		}

		protected void OpenFile (object sender, System.EventArgs e)
		{
			openFileDialog1.ShowDialog();			
		}

		protected void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			string fileName = openFileDialog1.FileName;
			this.textBox1.Text = new File(fileName).Name;
			StreamReader reader = new StreamReader(fileName);
			try {
				SourceFile source = new SourceFile(fileName);           
				ITokenVisitor visitor = new ColorTokenVisitor(this.richTextBox1);
				source.Accept(visitor);
			}
			catch (Exception caught) {
				reader.Close();
			}
		}

        public static void Main(string[] args) 
        {
            Application.Run(new ColorSyntaxApp());
        }
    }
}