
namespace CSharp
{
    public abstract class NullTokenVisitor : ITokenVisitor
    {
        
    }
}
