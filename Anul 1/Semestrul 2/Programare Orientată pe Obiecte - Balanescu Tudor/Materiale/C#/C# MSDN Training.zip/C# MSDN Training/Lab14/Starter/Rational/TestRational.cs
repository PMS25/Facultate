namespace Rational
{
using System;

// Test harness
public class TestRational
{
	public static void Main()
	{
		
	}
}
}
