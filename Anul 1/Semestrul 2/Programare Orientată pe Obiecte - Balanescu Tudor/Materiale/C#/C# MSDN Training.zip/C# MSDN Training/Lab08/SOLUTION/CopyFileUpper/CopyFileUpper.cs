    using System;
	using System.IO;

    /// <summary>
    ///    Class to create an upper case copy of a file
    /// </summary>
    public class CopyFileUpper
    {
		public static void Main()
		{
			string sFrom;
			string sTo;
			StreamReader srFrom;
			StreamWriter swTo;

			// Prompt for the input filename
			Console.Write("Copy From: ");
			sFrom = Console.ReadLine();

			// Prompt for the output filename
			Console.Write("Copy To: ");
			sTo = Console.ReadLine();

			try 
			{
				srFrom = new StreamReader(sFrom);
				swTo = new StreamWriter(sTo);

				while (srFrom.Peek() != -1)
				{
					string sBuffer = srFrom.ReadLine();
					sBuffer = sBuffer.ToUpper();
					swTo.WriteLine(sBuffer);
				}
		
				srFrom.Close();
				swTo.Close();
			} 
			catch (FileNotFoundException)
			{
				Console.WriteLine("Input file not found");
			}
			catch (Exception e)
			{
				Console.WriteLine("Unexpected exception");
				Console.WriteLine(e.ToString());
			}
		}       
    }
