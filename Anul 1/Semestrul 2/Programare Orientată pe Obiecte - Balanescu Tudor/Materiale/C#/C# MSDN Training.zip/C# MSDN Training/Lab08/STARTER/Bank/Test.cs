using System;

/// <summary>
///    Test harness.
/// </summary>

public class Test
{
	public static void Main()
	{
		// insert testing code here
	
	}
}
