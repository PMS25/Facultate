
namespace Banking
{
    
public enum AccountType 
{ 
    Checking, 
    Deposit 
}

}

