
using System;
using System.Collections;

public class BankAccount 
{
	private long accNo;
    private decimal accBal;
    private AccountType accType;
	private Queue tranQueue = new Queue();

	private static long nextNumber = 123;

	// Constructors

	internal BankAccount()
	{
        this.accNo = NextNumber();
        this.accBal = 0;
        this.accType = AccountType.Checking;
	}

	internal BankAccount(AccountType accType)
	{
        this.accNo = NextNumber();
        this.accBal = 0;
        this.accType = accType;
	}
	
	internal BankAccount(decimal balance)
    {
        this.accNo = NextNumber();
        this.accBal = balance;
        this.accType = AccountType.Checking;
    }

	internal BankAccount(AccountType accType, decimal balance)
    {
        this.accNo = NextNumber();
        this.accBal = balance;
        this.accType = accType;
    }

	// Finalizer and Dispose methods
	
	~BankAccount()
	{
		foreach (BankTransaction tran in tranQueue) {
			tran.Dispose();
		}
	}

	internal void Dispose()
	{
		this.Finalize();
		GC.SuppressFinalize(this);
	}

    // Other Methods
	
	public bool Withdraw(decimal amount)
    {
        bool sufficientFunds = accBal >= amount;
        if (sufficientFunds) {
            accBal -= amount;
		    BankTransaction theTran = new BankTransaction(-amount);  // Negative amount, this a withdrawl
		    tranQueue.Enqueue(theTran);
		}
        return sufficientFunds;
    }
    
    public decimal Deposit(decimal amount)
    {
        accBal += amount;
		BankTransaction theTran = new BankTransaction(amount);
		tranQueue.Enqueue(theTran);
        return accBal;
    }
    
    public long Number()
    {
        return accNo;
    }
    
    public decimal Balance()
    {
        return accBal;
    }
    
    public string Type()
    {
        return accType.Format();
    }

	public Queue Transactions()
	{
		return tranQueue;
	}

    private static long NextNumber()
    {
        return nextNumber++;
    }
}