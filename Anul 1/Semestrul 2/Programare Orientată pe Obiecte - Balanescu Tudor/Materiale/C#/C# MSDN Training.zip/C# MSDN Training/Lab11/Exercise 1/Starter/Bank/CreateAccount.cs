
using System;
using System.Collections;

// Test harness
class CreateAccount
{
    static void Main() 
    {
		// Insert test code here
	}

	// Useful methods for the test harness
	static void Write(BankAccount acc)
    {
        Console.WriteLine("Account number is {0}",  acc.Number());
        Console.WriteLine("Account balance is {0}", acc.Balance());
        Console.WriteLine("Account type is {0}", acc.Type());

		// Print out the transactions (if any)
		Console.WriteLine("Transactions");
		Queue tranQueue = acc.Transactions();
		foreach (BankTransaction tran in tranQueue) {
			Console.WriteLine("Date: {0}\tAmount: {1}", tran.When(), tran.Amount());
		}
    }
    
    static void TestDeposit(BankAccount acc)
    {
        Console.Write("Enter amount to deposit: ");
        decimal amount = decimal.Parse(Console.ReadLine());
        acc.Deposit(amount);        
    }
    
    static void TestWithdraw(BankAccount acc)
    {
        Console.Write("Enter amount to withdraw: ");
        decimal amount = decimal.Parse(Console.ReadLine());
        acc.Withdraw(amount);   
    }
}
