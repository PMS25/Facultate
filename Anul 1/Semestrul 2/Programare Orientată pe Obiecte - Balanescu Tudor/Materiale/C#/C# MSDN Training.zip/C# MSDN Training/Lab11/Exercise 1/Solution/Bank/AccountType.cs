
public enum AccountType 
{ 
    Checking, 
    Deposit 
}
