
public class Bank
{
    // add methods here
}
