namespace Greetings
{
using System;

/// <summary>
///    This program prompts the user for their name and then greets them by name
/// </summary>
public class Greeter
{
    
    public static int Main(string[] args)
    {
        //
        // TODO: Add code to start application here
        //
		string myName;

		Console.WriteLine("Please enter your name");
		myName = Console.ReadLine();
		Console.WriteLine("Hello {0}", myName);
        return 0;
    }
}
}
