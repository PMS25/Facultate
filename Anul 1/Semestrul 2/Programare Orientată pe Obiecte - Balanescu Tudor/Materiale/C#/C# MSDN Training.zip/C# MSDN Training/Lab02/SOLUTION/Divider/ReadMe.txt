========================================================================
    C# CONSOLE APPLICATION : Divider Project Overview
========================================================================

AppWizard has created this Divider console application for you.  

This file contains a summary of what you will find in each of the files that
make up your Divider application.


Divider.csproj
    This is the main project file for C# projects generated using an Application Wizard. 
    It contains information about the version of Visual Studio that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

File1.cs
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
