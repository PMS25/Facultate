
using System;

class WhatDay
{
    static void Main() 
    {
        //
        // Add code here
        //
    }

	/******************************************************************/
    /******* You can use the code provided below to avoid typing ***** 
 
        if (dayNum <= 31) { // January
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }

        if (dayNum <= 28) { // February
            goto End;
        } else {
            dayNum -= 28;
            monthNum++;
        }

        if (dayNum <= 31) { // March
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }

        if (dayNum <= 30) { // April
            goto End;
        } else {
            dayNum -= 30;
            monthNum++;
        }

        if (dayNum <= 31) { // May
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }


        if (dayNum <= 30) { // June
            goto End;
        } else {
            dayNum -= 30;
            monthNum++;
        }

        if (dayNum <= 31) { // July
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }

        if (dayNum <= 31) { // August
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }

        if (dayNum <= 30) { // September
            goto End;
        } else {
            dayNum -= 30;
            monthNum++;
        }

        if (dayNum <= 31) { // October
            goto End;
        } else {
            dayNum -= 31;
            monthNum++;
        }
		
		//////////////////////////////////////////////////////////////
		// TODO: Implement if statements for November and December ///
		//////////////////////////////////////////////////////////////

       
        End:
        string monthName;


        switch (monthNum) {
        case O :
            monthName = "January"; break;
        case 1 :
            monthName = "February"; break;
        case 2 :
            monthName = "March"; break;
        case 3 :
            monthName = "April"; break;
        case 4 :
            monthName = "May"; break;
        case 5 :
            monthName = "June"; break;
        case 6 :
            monthName = "July"; break;
        case 7 :
            monthName = "August"; break;
        case 8 :
            monthName = "September"; break;
        case 9 :
            monthName = "October"; break;

        //////////////////////////////////////////////////////////////////
		// TODO: Implement the case 10 and case 11 for November         //
		//       and December                                           //
		//////////////////////////////////////////////////////////////////

        default:
            monthName = "not done yet"; break;
        }

***************************************************************************/


    
    // Don't modify anything below here
    static System.Collections.ICollection DaysInMonths 
        = new int[12]{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
}
