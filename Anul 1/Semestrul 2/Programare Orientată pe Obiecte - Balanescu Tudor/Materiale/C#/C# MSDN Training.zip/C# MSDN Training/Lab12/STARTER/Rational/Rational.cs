namespace Rational
{
using System;

/// <summary>
///    Rational defines a class for holding and manipulating rational numbers
/// </summary>
public class Rational
{
    private int dividend;
	private int divisor;

	// Define constructors

	// Define operators

	// Override methods
}
}
