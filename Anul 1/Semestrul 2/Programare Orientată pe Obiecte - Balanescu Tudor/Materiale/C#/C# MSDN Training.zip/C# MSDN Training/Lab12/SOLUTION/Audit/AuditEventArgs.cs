namespace Banking
{
using System;

/// <summary>
///    This class will be used as a parameter to the Auditing event.
///    It will contain an embedded BankTransaction object.
/// </summary>
public class AuditEventArgs : System.EventArgs
{
	private readonly BankTransaction transData = null;

    public AuditEventArgs(BankTransaction transaction)
    {
        this.transData = transaction;
    }

	public BankTransaction getTransaction()
	{
		return this.transData;
	}
}
}
