namespace Rational
{
using System;

// Test harness
public class TestRational
{
	public static void Main()
	{
		// Create two Rationals - r1 and r2

		// Print them out

		// Is r1 > r2?

		// Is r1 <= r2?

		// Is r1 != r2?

		// Add r2 to r1

		// Add 5 to r2

		// Subtract r1 from r2

		// Subtract 2 from r2

		// Increment r1

		// Decrement r2

		// If you have time ...
		// Test the cast operators

		// Test the multiplicative operators

	}
}
}
