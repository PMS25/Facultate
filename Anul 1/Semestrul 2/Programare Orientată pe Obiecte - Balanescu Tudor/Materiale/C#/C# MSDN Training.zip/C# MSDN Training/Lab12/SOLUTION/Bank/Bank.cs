using System;
using System.Collections;

namespace Banking 
{

/// <summary>
///    Bank acts as a factory for accounts
/// </summary>

public class Bank
{
	private static Hashtable accountStore = new Hashtable();

    private Bank()
    {
        // Constructor is private - Bank is a singleton
    }

	// Factory methods

	public static long CreateAccount()
	{
		BankAccount newAcc = new BankAccount();
		long accNo = newAcc.Number();
		accountStore[accNo] = newAcc;
		return accNo;
	}

	public static long CreateAccount(AccountType accType, decimal balance)
	{
		BankAccount newAcc = new BankAccount(accType, balance);
		long accNo = newAcc.Number();
		accountStore[accNo] = newAcc;
		return accNo;
	}

	public static long CreateAccount(AccountType accType)
	{
		BankAccount newAcc = new BankAccount(accType);
		long accNo = newAcc.Number();
		accountStore[accNo] = newAcc;
		return accNo;
	}

	public static long CreateAccount(decimal balance)
	{
		BankAccount newAcc = new BankAccount(balance);
		long accNo = newAcc.Number();
		accountStore[accNo] = newAcc;
		return accNo;
	}

	public static BankAccount GetAccount(long accNo)
	{
		BankAccount theAcc = (BankAccount)accountStore[accNo];
		return theAcc;
	}

	public static bool CloseAccount(long accNo)
	{
		BankAccount theAcc = (BankAccount)accountStore[accNo];
		if (theAcc != null) {
			accountStore.Remove(accNo);
			theAcc.Dispose();
			return true;
		} else {
			return false;
		}
	}
}
}