﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericApp
{
    public class Book : IComparable
    {
        public string Code { get; set; }
        public string Title { get; set; }
        public int Year { get; set; }
        public string Author { get; set; }

        public int CompareTo(object obj)
        {
            var o = obj as Book;

            return Code.CompareTo(o.Code);

        }

        public override string ToString()
        {
            return $"[{Code}; {Title}; {Year}; {Author}]";
        }
    }
}
