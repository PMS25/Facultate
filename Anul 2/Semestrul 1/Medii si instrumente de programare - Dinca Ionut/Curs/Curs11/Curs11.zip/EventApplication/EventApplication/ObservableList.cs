﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventApplication
{
    //1. declararea delegatului
    //public delegate void Notify<R>(R elem);

    public class CustomEventArgs<T> : EventArgs
    {
        public T elem { get; set; }
        public DateTime Date { get; set; }
    }

    public class ObservableList<T>
    {
        public List<T> Elements { get; private set; }
        //2. declararea evenimentelor
        public event EventHandler<CustomEventArgs<T>> Added;
        public event EventHandler<CustomEventArgs<T>> Removed;

        public ObservableList()
        {
            Elements = new List<T>();
        }

        public void Add(T newElement)
        {
            Elements.Add(newElement);
            OnAdded(this, new CustomEventArgs<T> { elem = newElement, Date = DateTime.Now });
        }

        public void Remove(T element)
        {
            if (Elements.Contains(element))
            {
                Elements.Remove(element);
            }

            OnRemoved(this, new CustomEventArgs<T> { elem = element, Date = DateTime.Now });
        }

        protected virtual void OnAdded(object sender, CustomEventArgs<T> args)
        {
            Added?.Invoke(sender, args);
            

            //if(Added != null)
            //{
            //    Added.Invoke();
            //}
        }

        protected virtual void OnRemoved(object sender, CustomEventArgs<T> args)
        {
            Removed?.Invoke(sender, args);
        }
    }
}
