﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            ObservableList<int> list = new ObservableList<int>();
            
            list.Added += new EventHandler<CustomEventArgs<int>>(AddAction);
            list.Removed += RemoveAction;
            
            list.Add(12);
            list.Add(23);
            list.Add(26);
            list.Add(28);
            
            list.Remove(12);

            Console.ReadKey();
        }

        static void AddAction(object sender, CustomEventArgs<int> args)
        {
            ObservableList<int> senderValue = null;

            if (sender is ObservableList<int>)
            {
                senderValue = sender as ObservableList<int>;
            }

            Console.WriteLine($"lista are {senderValue.Elements.Count} elemente");
            Console.WriteLine($"s-a adaugat obiectul {args.elem} la data {args.Date}!");
        }

        static void RemoveAction(object sender, CustomEventArgs<int> args)
        {
            ObservableList<int> senderValue = null;

            if (sender is ObservableList<int>)
            {
                senderValue = sender as ObservableList<int>;
            }

            Console.WriteLine($"lista are {senderValue.Elements.Count} elemente");
            Console.WriteLine($"s-a eliminat obiectul {args.elem} la data {args.Date}!");
        }
    }
}
