﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Curs8App
{
    class Program
    {
        static void Main(string[] args)
        {
            //string s = "adasfasr3443f afa 45 ";
            //var nr = s.GetDigitsCount();

            //Console.WriteLine("Numarul de cifre: ", nr);

            //List<int> list = new List<int>() { 5 };

            //Console.WriteLine(list.IsNullOrEmpty());

            //List<string> l = new List<string>() { "aasda", "as", "asda", "as", "asdasdas", "as" };
            
            //Console.WriteLine(l.GetOccurrences<string>("as"));

            //exemplu: sa se selecteze dintr-o lista de siruri de caractere doar sirurile care incep cu litera mare, folosin LINQ

            List<string> list = new List<string>() { "Aasda", "as", "asda", "as", "Asdasdas", "as" };

            var values = list.Where(x => char.IsUpper(x[0])).ToList();



            Console.ReadKey();
        }
    }
}
