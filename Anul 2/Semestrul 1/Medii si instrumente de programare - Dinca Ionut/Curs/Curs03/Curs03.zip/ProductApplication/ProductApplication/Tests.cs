﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductApplication
{
    [TestFixture]
    class Tests
    {
        [Test]
        public void T()
        {
            Product p = new Product(1, "car", 3000);
            Console.WriteLine(p);
            p.DisplayInfo();
            List<Product> list = new List<Product>()
            {
                new Product(1, "car", 3000),
                new Product(2, "tv", 2000)
            };

            Assert.IsTrue(list.Contains(p));
        }
    }
}
