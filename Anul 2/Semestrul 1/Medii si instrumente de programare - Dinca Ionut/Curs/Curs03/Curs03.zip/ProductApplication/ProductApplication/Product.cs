﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductApplication
{
    public class Product: IComparable
    {
        private int _id;
        private string _name;
        private double _price;


        //getters & setters
        //public string GetName()
        //{
        //    return _name;
        //}

        //public void SetName(string name)
        //{
        //    _name = name;
        //}

        //proprietate de tip read/write
        public string Name
        {
            //getter
            get
            {
                return _name;
            }
            //setter
            private set 
            {
                _name = value;
            }
        }

        //poate fi read-only: lipseste sectiunea set!!



        //constructori
        public Product()
        {
            _id = 1;
            Name = "default";
            _price = 100;
        }

        public Product(int id, string name, double price)
        {
            _id = id;
            _name = name;
            _price = price; 
        }


        //metoda specifica
        public void DisplayInfo()
        {
            Console.WriteLine();
        }

        //reprezentare ca sir de caractere
        public override string ToString()
        {
            return $"{_id};{_name};{_price}";
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (!(obj is Product))
            {
                return false;
            }

            Product product = obj as Product; //(conversie cu operatorul as)

            return _id == product._id && _name == product._name;
        }

        public int CompareTo(object obj)
        {
            if(this.Equals(obj))
            {
                return 0;
            }

            if (_id < (obj as Product)._id)
            {
                return -1;
            }

            return 1;
        }


        //asocierea unui unic numar intreg (cod hash) pentru obiectul curent
        //uzual, este o combinatie intre campurile cu valori unice ale
        //obiectului
        public override int GetHashCode()
        {
            return 3 * _id;
        }
    }
}
