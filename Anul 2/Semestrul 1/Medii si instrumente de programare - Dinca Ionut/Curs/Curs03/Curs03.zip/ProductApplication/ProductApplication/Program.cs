﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product(1, "car", 3000);
            Console.WriteLine(p);


            List<Product> list = new List<Product>()
            {
                new Product(1, "car", 3000),
                new Product(2, "tv", 2000)
            };

            if (list.Contains(p))
            {
                Console.WriteLine("{0} exista in lista!", p);
            }
            else
            {
                Console.WriteLine("{0} nu exista in lista!", p);
            }

            list.Remove(p); //si aici, atentie, se utilizeaza "Equals" !!!!


            Dictionary<Product, string> d = new Dictionary<Product, string>();
            d.Add(p, p.Name);

            Console.WriteLine(d[p]);

            Console.ReadKey();

            //p.Name = "Ionescu";
        }
    }
}
