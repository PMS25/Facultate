﻿using EstateManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstateManagement.Repository.SqlRepository
{
    internal class EstateRepository : IRepository<Estate>
    {
        //cod de conectare la baza de date, executarea instructiunilor respective (SELECT, UPDATE, INSERT, DELETE)

        public Estate Create(Estate value)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<Estate> GetAll()
        {
            throw new NotImplementedException();
        }

        public Estate GetById(int id)
        {
            //SELECT * FROM Estate WHERE EstateId = {id}....
            throw new NotImplementedException(); 
        }

        public Estate Update(Estate value)
        {
            throw new NotImplementedException();
        }
    }
}
