﻿using EstateManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstateManagement.Repository.SqlRepository
{
    internal class PictureRepository : IRepository<Picture>
    {
        public Picture Create(Picture value)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<Picture> GetAll()
        {
            throw new NotImplementedException();
        }

        public Picture GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Picture Update(Picture value)
        {
            throw new NotImplementedException();
        }
    }
}
