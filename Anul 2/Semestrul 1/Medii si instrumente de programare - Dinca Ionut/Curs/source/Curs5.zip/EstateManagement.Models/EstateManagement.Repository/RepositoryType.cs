﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstateManagement.Repository
{
    public enum RepositoryType
    {
        Sql = 1,
        Json = 2
    }
}
