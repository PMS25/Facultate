﻿using EstateManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstateManagement.Repository.SqlRepository
{
    internal class OwnerRepository : IRepository<Owner>
    {
        public Owner Create(Owner value)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<Owner> GetAll()
        {
            throw new NotImplementedException();
        }

        public Owner GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Owner Update(Owner value)
        {
            throw new NotImplementedException();
        }
    }
}
