﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstateManagement.Models
{
    public enum EstateType
    {
        App = 1,
        House = 2,
        Ground = 3,
        Office = 4
    }
}
