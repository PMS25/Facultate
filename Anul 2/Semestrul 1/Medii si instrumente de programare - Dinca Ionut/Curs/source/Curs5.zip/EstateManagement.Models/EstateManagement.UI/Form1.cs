﻿using EstateManagement.Models;
using EstateManagement.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EstateManagement.UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //de exemplu, daca doresc ca creez un estate
            var estateRepository = RepositoryFactory.CreateEstateRepository();

            //incarc un Estate din interfata (toate datele, initial fara poze!, ulterior, voi putea adauga poze!!)
            Estate estate = new Estate(); //obtinut din interfata
            
            estateRepository.Create(estate); //!!
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //adaugarea unei noi poze in sistem, la un estate existent
            //avem nevoie de estateId
            var pictureRepository = RepositoryFactory.CreatePictureRepository();
            Picture picture = new Picture();
            pictureRepository.Create(picture);

            //salvarea fisierul pe disk, intr-un folder cu numele dat de id-ul estate-ului (estateId)
            //de exemplu, daca un estate are id-ul 5, toate pozele lui se vor salva in Picture/5/...
        }
    }
}
