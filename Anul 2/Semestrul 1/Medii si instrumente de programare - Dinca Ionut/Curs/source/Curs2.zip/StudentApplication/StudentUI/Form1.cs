﻿using StudentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        //cod generat automat (dar se poate interveni manual cu instructiuni 
        //specifice)
        private void button1_Click(object sender, EventArgs e)
        {
            //cod executat la click mouse pe "Save"

            //preiau informatiile din casete de text
            if(string.IsNullOrEmpty(tb_Id.Text)) //verificam daca e goala
            {
                MessageBox.Show("campul Id este gol!");
                return;
            }

          

            if (string.IsNullOrEmpty(tb_Name.Text)) //verificam daca e goala
            {
                MessageBox.Show("campul Name este gol!");
                return;
            }

            if (string.IsNullOrEmpty(tb_Faculty.Text)) //verificam daca e goala
            {
                MessageBox.Show("campul Faculty este gol!");
                return;
            }

            if (string.IsNullOrEmpty(tb_Email.Text)) //verificam daca e goala
            {
                MessageBox.Show("campul Email este gol!");
                return;
            }


            if (string.IsNullOrEmpty(tb_Age.Text)) //verificam daca e goala
            {
                MessageBox.Show("campul Age este gol!");
                return;
            }

            //asiguram faptul ca Age este numar!
            int age = 0;
            if(!int.TryParse(tb_Age.Text, out age))
            {
                MessageBox.Show($"Valoarea {tb_Age.Text} nu este un numar intreg!");
                return;
            }

            Student s = new Student(tb_Id.Text, tb_Faculty.Text, tb_Email.Text, tb_Name.Text, age);
            s.WriteToFile();

            var pathToFile = ConfigurationManager.AppSettings["PathToFile"];
            var fileName = ConfigurationManager.AppSettings["FileName"];

            MessageBox.Show($"Studentul [{s}] a fost salvat in fisierul [{Path.Combine(pathToFile, fileName)}]");

            richTextBox1.Clear(); //curatam caseta!
            richTextBox1.Text = File.ReadAllText(Path.Combine(pathToFile, fileName));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var pathToFile = ConfigurationManager.AppSettings["PathToFile"];
            var fileName = ConfigurationManager.AppSettings["FileName"];

            richTextBox1.Clear(); //curatam caseta!
            richTextBox1.Text = File.ReadAllText(Path.Combine(pathToFile, fileName));
        }
    }
}
