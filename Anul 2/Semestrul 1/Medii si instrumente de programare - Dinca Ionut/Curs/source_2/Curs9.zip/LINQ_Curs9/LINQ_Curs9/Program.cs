﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Curs9
{

    public static class MyExtensionsOperators
    {
        public static List<T> MyWhere<T>(this List<T> source, Func<T, bool> predicate)
        {
            var result = new List<T>();

            foreach(var elem in source)
            {
                if(predicate(elem))
                {
                    result.Add(elem);
                }
            }

            return result;
        }

        public static List<TResult> MySelect<T,TResult>(this List<T> source, Func<T, TResult> selector)
        {
            var result = new List<TResult>();

            foreach (var elem in source)
            {
                    result.Add(selector(elem));
            }

            return result;
        }
    }

    
    
    class Program
    {
        
        class Car
        {
            public string Model { get; set; }
            public int Year { get; set; }
            public string Color { get; set; }
        }

        class ColorModel
        {
            public string Model { get; set; }
            public string Color { get; set; }
        }

        class Predicates
        {
            public static bool P1(Car c)
            {
                return c.Color == "red" && c.Year > 2000;
            }
        }

        


        static void Main(string[] args)
        {
            //operatorul WHERE
            // List<int> values = new List<int>() { 3, 2, 5, 6, 7, 8, 35, 7 };

            //  var values1 = values.Where(x => x % 2 == 0).ToList();

            List<Car> cars = new List<Car>()
            {
                new Car() { Model = "bmw", Year = 2000, Color = "red" },
                new Car() { Model = "toyota", Year = 2018, Color = "black" },
                new Car() { Model = "mercedes", Year = 2016, Color = "red" },
                new Car() { Model = "dacia", Year = 2013, Color = "black" },
                new Car() { Model = "bmw", Year = 2012, Color = "blue" },
                new Car() { Model = "bmw", Year = 2010, Color = "green" }
            };

            //Func<Car, bool> f = Predicates.P1;

           // var c1 = cars.MyWhere(x => x.Model == "bmw");

            //selecteaza anii de fabricatie pentru masinile de culoare rosie
            var cars1 = cars
                            .Where(x => x.Color == "red")
                            .Select(x => new ColorModel() { Color = x.Color, Model = x.Model }).ToList();

            // var years = cars.Select(x => x.Year).OrderByDescending(x => x).ToList();
            var cars2 = cars.OrderByDescending(x => x.Year).ToList();

            var distinctColors = cars.Select(x => x.Color).Distinct().ToList();

            var maxYear = cars.Max(x => x.Year);


            Console.ReadKey();
        }
    }
}
