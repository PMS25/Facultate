﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //declararea si definirea obiectelor de tipuri generice se face substituind tipul generic cu
            //un tip concret
            MyGenericStack<Book> books = new MyGenericStack<Book>(); //acum, compilatorul C# peste tot pe unde vede
            //T va inlocui cu Book

            books
                .Add(new Book()
            {
                Code = "1212",
                Title = "Cei trei muschetari",
                Author = "Alexandre Dumas",
                Year = 1844
            })
                .Add(new Book()
            {
                Code = "1250",
                Title = "Dupa douazeci de ani",
                Author = "Alexandre Dumas",
                Year = 1864
            });

            books.DisplayInfo();

            var b = books.Remove(); //elimin ultima carte
            
            books.DisplayInfo();

            Console.WriteLine(b);
            books.Remove();
            books.DisplayInfo(); //stiva goala

            //Scoaterea dintr-o stiva goala (tratarea exceptiilor in C#)

            try
            {
                books.Remove();
            }
            catch(Exception ex)
            {
                Console.WriteLine($"You cannot remove elements from empty stack! error: {ex.Message}");
            }
            
            Console.ReadKey();
        }
    }
}
