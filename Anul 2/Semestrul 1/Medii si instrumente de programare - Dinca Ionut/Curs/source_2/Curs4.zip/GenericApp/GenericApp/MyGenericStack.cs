﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericApp
{
    //stiva generica de obiecte (poate stoca obiecte de "orice tip")
    public class MyGenericStack<T> where T:IComparable
    {
        private T[] _elements; //suportul pentru elementele stivei de tip generic T

        public int Size { get; private set; }

        public MyGenericStack()
        {
            _elements = new T[0]; //initializarea unui "array" de tip T cu 0 componente
        }

        public MyGenericStack<T> Add(T newElem)
        {
            T[] _temp = new T[Size + 1]; //aloc un nou array in care "sa incapa" si newElem
            for(int i = 0; i < _elements.Length; i++)
            {
                _temp[i] = _elements[i];
            }

            _temp[Size] = newElem; //inseram newElem pe ultima pozitie
            _elements = _temp; //schimbam referinta catre noul "array" temp
            Size++;

            return this; //this este referinta catre obiectul curent
        }

        //scoatem elementul din varful stivei
        public T Remove()
        {
            if(Size == 0)
            {
                //varianta 1: generam o exceptie!
                throw new Exception("Stack is empty!"); //se genereaza o exceptie daca se utilizeaza metoda Remove
                //pe o stiva goala

                //varianta 2
                //return default(T); operatorul "default" se utilieaza pentru un tip generic T si returneaza valoare
                //default a tipului respectiv; de exemplu, 0 pentru int, null pentru "Product" si orice tip referinta, false pentru bool
            }

            T[] _temp = new T[Size - 1]; //aloc un nou array in care "sa incapa" si newElem
            
            for (int i = 0; i < _elements.Length-1; i++)
            {
                _temp[i] = _elements[i];
            }

            T result = _elements[Size - 1];
            _elements = _temp; //schimbam referinta catre noul "array" temp
            Size--;

            return result;
        }

        //afisare stiva la consola
        public void DisplayInfo()
        {
            if(Size == 0)
            {
                Console.WriteLine("[]");
                return;
            }

            //Console.WriteLine("[");
            //for(int i = 0; i < Size - 1; i++)
            //{
            //    Console.Write(_elements[i] + ", ");
            //}

            //Console.WriteLine(_elements[Size - 1] + "]");
            

            Console.WriteLine($"[{string.Join(",", _elements)}]");
        }

        public void Sort()
        {
            //acum putem ordona elementele din _elements folosind metoda din interfata (compareTo)
            //bubble sort
            //ramane ca tema!!!
                


        }
    }
}
