﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentModel
{
    //o clasa C# care modeleaza notiunea de Student din lumea reala
    public class Student
    {
        //adaugam proprietatile unui student
        public string Id { get; set; }
        public string Faculty { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        public Student(string id, string faculty, string email, string name, int age)
        {
            Id = id;
            Faculty = faculty;
            Email = email;
            Name = name;
            Age = age;
        }

        public void ReadInfo()
        {
            Console.WriteLine("Id:");
            Id = Console.ReadLine();

            Console.WriteLine("Faculty:");
            Faculty = Console.ReadLine();

            Console.WriteLine("Name:");
            Name = Console.ReadLine();

            Console.WriteLine("Email:");
            Email = Console.ReadLine();

            Console.WriteLine("Age:");
            Age = int.Parse(Console.ReadLine());
        }

        public void DisplayInfo()
        {
            Console.WriteLine(ToString());
        }

        public void WriteToFile()
        {
            File.AppendAllText("Students.txt", ToString() + "\n");
        }

        //reprezentare ca string (sir de caractere)
        //a obiectului curent

        public override string ToString()
        {
            return $"{Id},{Faculty},{Email},{Name},{Age}";
        }
    }
}
