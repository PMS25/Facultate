﻿using StudentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using StudentModel; //using pentru namespace-ul care contine clasa Student
//altfel, fara using, trebuie sa scriem numele full al clasei!!

namespace StudentApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stud = new Student("2A", "Info", "Coco@upit.ro", "Cocolino", 45);

            Console.WriteLine(stud.ToString());

            stud.ReadInfo();
            stud.WriteToFile();
            stud.DisplayInfo();




            Console.ReadKey();
        }
    }
}
