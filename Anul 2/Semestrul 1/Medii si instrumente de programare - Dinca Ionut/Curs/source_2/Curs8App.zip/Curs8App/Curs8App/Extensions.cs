﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Curs8App
{
    public static class Extensions
    {
        public static int GetDigitsCount(this string textValue)
        {
            if(string.IsNullOrEmpty(textValue))
            {
                return 0;
            }

            int count = 0;

            foreach(var c in textValue)
            {
                if(char.IsDigit(c))
                {
                    count++;
                }
            }

            return count;
        }

        public static bool IsNullOrEmpty<T>(this List<T> list)
        {
            if(list == null)
            {
                return true;
            }

            if(list.Count == 0)
            {
                return true;
            }

            return false;
        }

        public static int GetOccurrences<T>(this List<T> list, T value)
        {
            int result = 0;

            foreach(var v in list)
            {
                if (v.Equals(value))
                {
                    result++;
                }
            }

            return result;
        }
    }
}
