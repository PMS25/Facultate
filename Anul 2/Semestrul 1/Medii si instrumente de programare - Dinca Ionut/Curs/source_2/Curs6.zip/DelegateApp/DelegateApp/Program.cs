﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateApp
{
    class Methods
    {
        public static int Add(int a, int b)
        {
            Console.WriteLine("Add(int a, int b)");
            return a + b;
        }

        public static int Mult(int a, int b)
        {
            Console.WriteLine("Mult(int a, int b)");
            return a * b;
        }
    }

    public delegate int Operation(int a, int b);
    public delegate int Operation1();
    
    class InstanceMethods
    {
        public int A { get; set; }
        public int B { get; set; }
       
        public int Add()
        {
            return A + B;
        }

        public int Mult()
        {
            return A * B;
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Operation op; //op este un obiect de tip delegat!!
            op = new Operation(Methods.Mult);
            op += Methods.Add;

            //apelarea delegatului se face ca si cum am apela metoda incapsulata!
            Console.WriteLine(op(3, 4));
            
            //InstanceMethods obj = new InstanceMethods()
            //{
            //    A = 10,
            //    B = 20
            //};

            //Operation1 op1 = new Operation1(obj.Add);

            //Console.WriteLine(op1());

            Console.ReadKey();
        }
    }
}
