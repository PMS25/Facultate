﻿using Contact.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contact.UI
{
    public partial class Form1 : Form
    {
        ContactList CList = new ContactList();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //aici se scrie codul pentru adaugarea unui contact in lista

            //aici se va utiliza obiectul CList pentru toate operatiile cu contacte


        }

        //eveniment de tip "form load"
        private void Form1_Load(object sender, EventArgs e)
        {
            //aici se poate apela functia "LoadFromDisk" astfel incat
            //daca sunt deja salvate contacte pe disk, acestea sa fie incarcate
            //in "CList"
        }
    }
}
