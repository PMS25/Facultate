﻿using Contact.Models;
using System;
using System.Windows.Forms;

namespace Contact.UI
{
    public partial class Form1 : Form
    {
        ContactList CList = new ContactList();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Aici se scrie codul pentru adaugarea unui contact in lista
            // Aici se va utiliza obiectul CList pentru toate operatiile cu contacte
        }

        // Eveniment de tip "form load"
        private void Form1_Load(object sender, EventArgs e)
        {
            // Aici se poate apela functia "LoadFromDisk" astfel incat
            // daca sunt deja salvate contacte pe disk, acestea sa fie incarcate in "CList"
        }
    }
}
