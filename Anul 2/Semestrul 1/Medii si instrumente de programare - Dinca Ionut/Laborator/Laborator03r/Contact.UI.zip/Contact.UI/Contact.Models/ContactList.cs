﻿namespace Contact.Models
{
    public class ContactList
    {
    }
}
