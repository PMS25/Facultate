﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laborator1_IntroCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            //int an = 1;
            //int grupa = 2;
            
            //Console.WriteLine("Hello, informatica anul {0}, grupa {1}", an, grupa);


            //int p = 1;
            //foreach(var s in args)
            //{
            //    Console.WriteLine("Parametrul {0} este {1}", p++, s);
            //}


            //cum citim date de la conosola?
            Console.WriteLine("Introduceti numele studentului");
            string studentName = Console.ReadLine();

            //cum se scrie intr-un fisier?
            File.AppendAllText("Students.txt", studentName + "\n");


            //cum se convertese un string la int (numar)?
            string strValue = "275";
            int value = int.Parse(strValue); //aici!




            Console.ReadKey();
        }
    }
}
