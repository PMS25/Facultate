﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CarApplication
{
    public class Car
    {
        public string Id { get; set; }
        public int Year { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public List<Owner> Owners { get; set; }
        public Car()
        {
            Owners = new List<Owner>();
        }

        public void SaveOnDisk()
        {
           string jsonStringValue = JsonConvert.SerializeObject(this);
            File.WriteAllText($"{Id}.txt", jsonStringValue);
        }

        public static Car LoadCarFromDisk(string id)
        {
            var value = File.ReadAllText($"{id}.txt");
            return JsonConvert.DeserializeObject<Car>(value);
        }
    }
}
