﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BasketModels
{
    //salveaza / citeste obiecte de diverse tipuri (Product, Order, Basket) de pe disk
    public class DataManagement
    {
        public static void Save(Product product)
        {
            if (product == null || string.IsNullOrEmpty(product.BarCode))
            {
                return;
            }
            
            //salvez in format JSon fisierul pe disk,
            //cu numele identic cu product.BarCode

            //serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(product);

            File.WriteAllText($"Product_{product.BarCode}.json", jsonString);
        }

        public static void Save(Order order)
        {
            if (order == null || order.Id == 0)
            {
                return;
            }

            //salvez in format JSon fisierul pe disk,
            //cu numele identic cu order.Id

            //serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(order);

            File.WriteAllText($"Order_{order.Id}.json", jsonString);
        }

        public static void Save(Basket basket)
        {
            if (basket == null)
            {
                return;
            }

            //salvez in format JSon fisierul pe disk,

            //serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(basket);

            File.AppendAllText($"Basket.json", jsonString);
        }

        public static Product GetProduct(string barCode)
        {
            if (string.IsNullOrEmpty(barCode))
            {
                return null;
            }

            //verificam daca exista pe disk fisierul cu acest barcode!
            var fileName = $"Product_{barCode}.json";

            if (!new FileInfo(fileName).Exists)
            {
                return null;
            }

            var jsonValue = File.ReadAllText(fileName);

            return JsonConvert.DeserializeObject<Product>(jsonValue);
        }

        public static Order GetOrder(int orderId)
        {

            //verificam daca exista pe disk fisierul cu acest orderId!
            var fileName = $"Order_{orderId}.json";

            if (!new FileInfo(fileName).Exists)
            {
                return null;
            }

            var jsonValue = File.ReadAllText(fileName);

            return JsonConvert.DeserializeObject<Order>(jsonValue);
        }

        public static Basket GetBasket()
        {
            //verificam daca exista pe disk fisierul cu acest orderId!
            var fileName = $"Basket.json";

            if (!new FileInfo(fileName).Exists)
            {
                return null;
            }

            var jsonValue = File.ReadAllText(fileName);

            return JsonConvert.DeserializeObject<Basket>(jsonValue);
        }

    }
}
