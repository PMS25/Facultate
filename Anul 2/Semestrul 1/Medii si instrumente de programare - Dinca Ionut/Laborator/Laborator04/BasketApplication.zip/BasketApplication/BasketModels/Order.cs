﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasketModels
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string ProductBarcode { get; set; }
        public int Count { get; set; }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (!(obj is Order))
            {
                return false;
            }

            return Id == (obj as Order).Id;
        }
    }
}
