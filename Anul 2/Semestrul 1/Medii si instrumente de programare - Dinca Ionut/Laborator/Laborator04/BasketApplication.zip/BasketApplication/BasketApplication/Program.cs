﻿using BasketModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasketApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Basket basket = new Basket();
            Product p1 = new Product()
            {
                BarCode = "1001a",
                CreateDate = DateTime.Now,
                ExpirationDate = DateTime.Now.AddYears(3),
                Category = "electronics",
                Name = "iphone",
                Price = 2000
            };

            Product p2 = new Product()
            {
                BarCode = "1002b",
                CreateDate = DateTime.Now,
                ExpirationDate = DateTime.Now.AddYears(10),
                Category = "electronics",
                Name = "tv",
                Price = 2500
            };

            DataManagement.Save(p1);
            DataManagement.Save(p2);

            Order o1 = new Order()
            {
                Id = 1,
                ProductBarcode = "1001a",
                Date = DateTime.Now,
                Count = 3
            };

            Order o2 = new Order()
            {
                Id = 2,
                ProductBarcode = "1002b",
                Date = DateTime.Now,
                Count = 5
            };

            DataManagement.Save(o1);
            DataManagement.Save(o2);

            basket.AddOrder(o1);
            basket.AddOrder(o2);

            Console.WriteLine("Totals: {0}", basket.GetTotal());

            DataManagement.Save(basket);

            Console.ReadKey();
        }
    }
}
