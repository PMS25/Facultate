﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Car c = new Car()
            {
                Id = "asasfa",
                Model = "Toyota",
                Year = 2000,
                Color = "Black",
                Owners = new List<Owner>()
                {
                    new Owner()
                    {
                        Id = 1,
                        Name = "Popescu",
                        Address = "Pitesti"
                    },
                    new Owner()
                    {
                        Id = 2,
                        Name = "Ionescu",
                        Address = "Bucuresti"
                    },
                }
            };

            //cum stocam informatiile structurat?
            //pe disk, in baza de date??
            //o solutie des utilizata in aplicatii este 
            //sub forma de structura "json"
            //c.SaveOnDisk();

            var other = Car.LoadCarFromDisk("asasfa");

        }
    }
}
