﻿using System.Collections.Generic;

namespace Logger
{
    public interface ILogger
    {
        // Metoda comuna claselor "logger"
        void Log(List<LogModel> logs);
    }
}
