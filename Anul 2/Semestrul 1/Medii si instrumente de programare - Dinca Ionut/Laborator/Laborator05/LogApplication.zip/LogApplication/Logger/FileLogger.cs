﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace Logger
{
    public class FileLogger : ILogger
    {
        public void Log(List<LogModel> logs)
        {
            if (logs != null)
            {
                var fileName = ConfigurationManager.AppSettings["LogFile"];

                foreach (var log in logs)
                {
                    log.ApplicationName = ConfigurationManager.AppSettings["ApplicationName"];
                    log.Date = DateTime.Now;
                    File.AppendAllText(fileName, $"{log}\n");
                }
            }
        }
    }
}
