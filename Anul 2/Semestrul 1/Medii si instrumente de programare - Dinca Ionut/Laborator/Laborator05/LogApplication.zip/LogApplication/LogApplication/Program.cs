﻿using Logger;
using System;
using System.Collections.Generic;

namespace LogApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            ILogger logger = new ConsoleLogger();

            logger.Log(new List<LogModel>()
            {
                new LogModel()
                {
                    Message = "action1",
                    Type = LogType.Info
                },

                new LogModel()
                {
                    Message = "action2",
                    Type = LogType.Error
                }
            });

            Console.ReadKey();
        }
    }
}
