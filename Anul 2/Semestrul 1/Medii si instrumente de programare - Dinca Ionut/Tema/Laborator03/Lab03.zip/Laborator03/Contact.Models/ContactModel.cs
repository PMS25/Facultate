﻿namespace Contact.Models
{
    public class ContactModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }

        public ContactModel() { }

        public ContactModel(string[] args)
        {
            Id = int.Parse(args[0]);
            Name = args[1];
            Email = args[2];
            Phone = args[3];
            Address = args[4];
            Country = args[5];
        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is ContactModel))
                return false;

            ContactModel c = obj as ContactModel;
            return Id == c.Id && Name == c.Name && Email == c.Email && Phone == c.Phone;
        }

        public override string ToString()
        {
            return $"{Id}: {Name}, {Email}, {Phone}, {Address}, {Country}";
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
