﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace Contact.Models
{
    public class ContactList
    {
        public List<ContactModel> Contacts { get; set; }

        public ContactList()
        {
            Contacts = new List<ContactModel>();
        }

        public void Add(ContactModel contact)
        {
            Contacts.Add(contact);
        }

        public void Remove(ContactModel contact)
        {
            Contacts.Remove(contact);
        }

        public void UpdateByIndex(int index, ContactModel contact)
        {
            if (!Contacts[index].Equals(contact))
                Contacts[index] = contact;
        }

        public bool SearchByName(string name)
        {
            foreach (var contact in Contacts)
                if (contact.Name == name)
                    return true;
            return false;
        }

        public bool SearchByEmail(string email)
        {
            foreach (var contact in Contacts)
                if (contact.Email == email)
                    return true;
            return false;
        }

        public List<ContactModel> FilterByName(string name)
        {
            List<ContactModel> sorted = new List<ContactModel>();
            if (SearchByName(name) == true)
                foreach (var contact in Contacts)
                    if (contact.Name == name)
                        sorted.Add(contact);
            return sorted;
        }

        public List<ContactModel> FilterByEmail(string email)
        {
            List<ContactModel> sorted = new List<ContactModel>();
            if (SearchByEmail(email) == true)
                foreach (var contact in Contacts)
                    if (contact.Email == email)
                        sorted.Add(contact);
            return sorted;
        }

        // Salvati toate contactele intr-un fisier pe disk!
        public void SaveOnDisk()
        {
            var filePath = ConfigurationManager.AppSettings["DiskPath"];
            File.WriteAllText(filePath, "");
            foreach (ContactModel contact in Contacts)
                File.AppendAllText(filePath, $"{contact}\n");
        }

        // Colectia "Contacts" va fi incarcata cu contactele salvate pe disk prin metoda anterioara
        public void LoadFromDisk()
        {
            var filePath = ConfigurationManager.AppSettings["DiskPath"];
            CleanContacts();
            List<string> lines;
            try
            {
                lines = File.ReadLines(filePath).ToList();
            }
            catch (Exception)
            {
                File.WriteAllText(filePath, "");
                lines = File.ReadLines(filePath).ToList();
            }
            foreach (var contact in lines)
            {
                var fields = contact.Split(new char[] { ':', ',' }).Select(o => o.Trim()).ToArray();
                ContactModel model = new ContactModel(fields);
                Contacts.Add(model);
            }
        }

        public void CleanContacts()
        {
            Contacts.Clear();
        }

        public int GetIndex(ContactModel contact)
        {
            for (int i = 0; i < Contacts.Count; i++)
                if (Contacts[i].Equals(contact))
                    return i;
            return -1;
        }
    }
}
