﻿using Contact.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Contact.UI
{
    public partial class Form1 : Form
    {

        ContactList contactList;
        private int initialIndex;

        public Form1()
        {
            InitializeComponent();
            cb_Sort.Items.Add("Name");
            cb_Sort.Items.Add("Email");
            cb_Sort.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            contactList = new ContactList();
            contactList.LoadFromDisk();
            LoadSourceInDataGrid(contactList.Contacts);
        }

        private void bSave_Click(object sender, EventArgs e)
        {
            contactList.SaveOnDisk();
        }

        private void LoadSourceInDataGrid(List<ContactModel> dataSource)
        {
            BindingSource source = new BindingSource();
            source.DataSource = dataSource;
            dataGridView.AutoGenerateColumns = true;
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridView.DataSource = source;
        }

        private void bLoad_Click(object sender, EventArgs e)
        {
            contactList.LoadFromDisk();
            LoadSourceInDataGrid(contactList.Contacts);
        }

        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            var index = e.RowIndex;
            if (initialIndex == -1)
                return;
            ContactModel model = (ContactModel)dataGridView.Rows[index].DataBoundItem;
            contactList.UpdateByIndex(initialIndex, model);
        }

        private void bSort_Click(object sender, EventArgs e)
        {
            string text = tbSort.Text;
            if (cb_Sort.SelectedItem.ToString() == "Name")
                LoadSourceInDataGrid(contactList.FilterByName(text));
            else if (cb_Sort.SelectedItem.ToString() == "Email")
                LoadSourceInDataGrid(contactList.FilterByEmail(text));
        }

        private void bRefresh_Click(object sender, EventArgs e)
        {
            LoadSourceInDataGrid(contactList.Contacts);
        }

        private void dataGridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            var index = e.RowIndex;
            initialIndex = contactList.GetIndex((ContactModel)dataGridView.Rows[index].DataBoundItem);
        }

        private void bClean_Click(object sender, EventArgs e)
        {
            contactList.CleanContacts();
            LoadSourceInDataGrid(contactList.Contacts);
        }
    }
}
