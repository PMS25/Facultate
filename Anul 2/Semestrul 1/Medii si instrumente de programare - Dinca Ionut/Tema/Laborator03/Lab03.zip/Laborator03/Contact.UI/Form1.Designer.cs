﻿namespace Contact.UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bLoad = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.bSave = new System.Windows.Forms.Button();
            this.tbSort = new System.Windows.Forms.TextBox();
            this.label_sort = new System.Windows.Forms.Label();
            this.cb_Sort = new System.Windows.Forms.ComboBox();
            this.bSort = new System.Windows.Forms.Button();
            this.bRefresh = new System.Windows.Forms.Button();
            this.bClean = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // bLoad
            // 
            this.bLoad.Location = new System.Drawing.Point(180, 396);
            this.bLoad.Name = "bLoad";
            this.bLoad.Size = new System.Drawing.Size(103, 23);
            this.bLoad.TabIndex = 0;
            this.bLoad.Text = "Load from Disk";
            this.bLoad.UseVisualStyleBackColor = true;
            this.bLoad.Click += new System.EventHandler(this.bLoad_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 12);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(676, 316);
            this.dataGridView.TabIndex = 1;
            this.dataGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            // 
            // bSave
            // 
            this.bSave.Location = new System.Drawing.Point(289, 396);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(98, 23);
            this.bSave.TabIndex = 2;
            this.bSave.Text = "Save on Disk";
            this.bSave.UseVisualStyleBackColor = true;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // tbSort
            // 
            this.tbSort.Location = new System.Drawing.Point(180, 348);
            this.tbSort.Name = "tbSort";
            this.tbSort.Size = new System.Drawing.Size(167, 20);
            this.tbSort.TabIndex = 3;
            // 
            // label_sort
            // 
            this.label_sort.AutoSize = true;
            this.label_sort.Location = new System.Drawing.Point(101, 351);
            this.label_sort.Name = "label_sort";
            this.label_sort.Size = new System.Drawing.Size(73, 13);
            this.label_sort.TabIndex = 4;
            this.label_sort.Text = "Filtreaza dupa";
            // 
            // cb_Sort
            // 
            this.cb_Sort.FormattingEnabled = true;
            this.cb_Sort.Location = new System.Drawing.Point(361, 347);
            this.cb_Sort.Name = "cb_Sort";
            this.cb_Sort.Size = new System.Drawing.Size(61, 21);
            this.cb_Sort.TabIndex = 5;
            // 
            // bSort
            // 
            this.bSort.Location = new System.Drawing.Point(438, 346);
            this.bSort.Name = "bSort";
            this.bSort.Size = new System.Drawing.Size(75, 23);
            this.bSort.TabIndex = 6;
            this.bSort.Text = "Sort";
            this.bSort.UseVisualStyleBackColor = true;
            this.bSort.Click += new System.EventHandler(this.bSort_Click);
            // 
            // bRefresh
            // 
            this.bRefresh.Location = new System.Drawing.Point(530, 347);
            this.bRefresh.Name = "bRefresh";
            this.bRefresh.Size = new System.Drawing.Size(75, 23);
            this.bRefresh.TabIndex = 7;
            this.bRefresh.Text = "Refresh";
            this.bRefresh.UseVisualStyleBackColor = true;
            this.bRefresh.Click += new System.EventHandler(this.bRefresh_Click);
            // 
            // bClean
            // 
            this.bClean.Location = new System.Drawing.Point(393, 396);
            this.bClean.Name = "bClean";
            this.bClean.Size = new System.Drawing.Size(75, 23);
            this.bClean.TabIndex = 8;
            this.bClean.Text = "Clean";
            this.bClean.UseVisualStyleBackColor = true;
            this.bClean.Click += new System.EventHandler(this.bClean_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 450);
            this.Controls.Add(this.bClean);
            this.Controls.Add(this.bRefresh);
            this.Controls.Add(this.bSort);
            this.Controls.Add(this.cb_Sort);
            this.Controls.Add(this.label_sort);
            this.Controls.Add(this.tbSort);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.bLoad);
            this.Name = "Form1";
            this.Text = "Contacts Manager";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bLoad;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.TextBox tbSort;
        private System.Windows.Forms.Label label_sort;
        private System.Windows.Forms.ComboBox cb_Sort;
        private System.Windows.Forms.Button bSort;
        private System.Windows.Forms.Button bRefresh;
        private System.Windows.Forms.Button bClean;
    }
}

