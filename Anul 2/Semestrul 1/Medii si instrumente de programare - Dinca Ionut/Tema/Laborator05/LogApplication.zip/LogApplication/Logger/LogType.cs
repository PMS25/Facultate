﻿namespace Logger
{
    public enum LogType
    {
        Info = 1,
        Warn = 2,
        Debug = 3,
        Error = 4
    }
}
