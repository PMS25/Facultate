﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace Logger
{
    public class ConsoleLogger : ILogger
    {
        // Metoda din interfata
        public void Log(List<LogModel> logs)
        {
            if (logs != null)
            {
                foreach (var log in logs)
                {
                    log.ApplicationName = ConfigurationManager.AppSettings["ApplicationName"];
                    log.Date = DateTime.Now;
                    Console.WriteLine(log);
                }
            }
        }
    }
}
