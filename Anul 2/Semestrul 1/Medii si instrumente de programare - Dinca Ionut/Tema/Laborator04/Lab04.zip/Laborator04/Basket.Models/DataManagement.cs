﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basket.Models
{
    public class DataManagement
    {
        public static void Save(Product product)
        {
            if (product == null || string.IsNullOrEmpty(product.BarCode))
                return;

            // Salvez in format JSon fisierul pe disk, cu numele identic cu product.BarCode
            // Serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(product);
            File.WriteAllText($"Product_{product.BarCode}.json", jsonString);
        }

        public static void Save(Order order)
        {
            if (order == null || order.Id == 0)
                return;

            // Salvez in format JSon fisierul pe disk, cu numele identic cu order.Id
            // Serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(order);
            File.WriteAllText($"Order_{order.Id}.json", jsonString);
        }

        public static void Save(Basket basket)
        {
            if (basket == null)
                return;

            // Salvez in format JSon fisierul pe disk,
            // Serializez ca json obiectul si salvez pe disk
            var jsonString = JsonConvert.SerializeObject(basket);
            File.AppendAllText($"Basket.json", jsonString);
        }

        public static Product GetProduct(string barCode)
        {
            if (string.IsNullOrEmpty(barCode))
                return null;

            // Verificam daca exista pe disk fisierul cu acest barcode!
            var fileName = $"Product_{barCode}.json";
            if (!new FileInfo(fileName).Exists)
                return null;

            var jsonValue = File.ReadAllText(fileName);
            return JsonConvert.DeserializeObject<Product>(jsonValue);
        }

        public static Order GetOrder(int orderId)
        {
            // Verificam daca exista pe disk fisierul cu acest orderId!
            var fileName = $"Order_{orderId}.json";
            if (!new FileInfo(fileName).Exists)
                return null;

            var jsonValue = File.ReadAllText(fileName);
            return JsonConvert.DeserializeObject<Order>(jsonValue);
        }

        public static Basket GetBasket()
        {
            // Verificam daca exista pe disk fisierul cu acest orderId!
            var fileName = $"Basket.json";
            if (!new FileInfo(fileName).Exists)
                return null;

            var jsonValue = File.ReadAllText(fileName);
            return JsonConvert.DeserializeObject<Basket>(jsonValue);
        }


        public static List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();

            string currentPath = Directory.GetCurrentDirectory();
            DirectoryInfo d = new DirectoryInfo(currentPath);
            FileInfo[] files = d.GetFiles("*.json");

            foreach (FileInfo file in files)
                if (file.Name.StartsWith("Product_"))
                {
                    var jsonValue = File.ReadAllText(file.Name);
                    Product product = JsonConvert.DeserializeObject<Product>(jsonValue);
                    products.Add(product);
                }

            return products;
        }

        public static void Delete(Product product)
        {
            if (product == null || string.IsNullOrEmpty(product.BarCode))
                return;

            string filePath = $"Product_{product.BarCode}.json";
            if (File.Exists(filePath))
                File.Delete(filePath);
        }

        public static void Delete(Basket Basket)
        {
            var fileName = $"Basket.json";
            if (new FileInfo(fileName).Exists)
                File.Delete(fileName);
        }

        public static void Update(Product product)
        {
            Delete(product);
            Save(product);
        }
    }
}
