﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basket.Models
{
    public class Basket
    {
        public List<Order> Orders { get; private set; }

        public Basket()
        {
            Orders = new List<Order>();
        }

        public void AddOrder(Order order)
        {
            Orders.Add(order);
        }

        public void Remove(Order order)
        {
            Orders.Remove(order);
        }

        public double GetTotal()
        {
            double result = 0;
            foreach (Order order in Orders)
            {
                var product = DataManagement.GetProduct(order.ProductBarcode);
                if (product != null)
                    result += product.Price * order.Count;
            }
            return result;
        }
    }
}
