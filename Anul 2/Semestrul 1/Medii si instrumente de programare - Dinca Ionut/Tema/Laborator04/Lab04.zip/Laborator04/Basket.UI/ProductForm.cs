﻿using Basket.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basket.UI
{
    public partial class ProductForm : Form
    {
        private List<Product> products;
        private int indexSelect;

        public ProductForm()
        {
            InitializeComponent();
        }

        private void LoadComboBox()
        {
            comboBox_Products.Items.Clear();
            comboBox_Products.ResetText();
            products = DataManagement.GetAllProducts();
            foreach (Product p in products)
            {
                string product = $"{p.BarCode}: {p.Name} - {p.Price}";
                comboBox_Products.Items.Add(product);
            }
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            LoadComboBox();
        }

        private void textBox_Price_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            Product product = GetProductFromInput();
            DataManagement.Save(product);
            LoadComboBox();
        }

        private void comboBox_Products_SelectedIndexChanged(object sender, EventArgs e)
        {
            indexSelect = comboBox_Products.SelectedIndex;
            LoadProductToInput();
        }


        private void LoadProductToInput()
        {
            textBox_BarCode.Text = products[indexSelect].BarCode;
            textBox_Name.Text = products[indexSelect].Name;
            textBox_Price.Text = products[indexSelect].Price.ToString();
            textBox_Category.Text = products[indexSelect].Category;
            dateTimePicker_CreateDate.Value = products[indexSelect].CreateDate;
            dateTimePicker_ExpirationDate.Value = products[indexSelect].ExpirationDate;
        }

        private Product GetProductFromInput()
        {
            Product product = new Product();
            product.BarCode = textBox_BarCode.Text;
            product.Name = textBox_Name.Text;
            product.Price = double.Parse(textBox_Price.Text);
            product.Category = textBox_Category.Text;
            product.CreateDate = dateTimePicker_CreateDate.Value;
            product.ExpirationDate = dateTimePicker_ExpirationDate.Value;
            return product;
        }

        private void CleanProduct()
        {
            textBox_BarCode.Text = String.Empty;
            textBox_Name.Text = String.Empty;
            textBox_Price.Text = String.Empty;
            textBox_Category.Text = String.Empty;
            dateTimePicker_CreateDate.Value = DateTime.Now;
            dateTimePicker_ExpirationDate.Value = DateTime.Now;
        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            if(indexSelect == comboBox_Products.SelectedIndex)
            {
                Product product = GetProductFromInput();
                DataManagement.Update(product);
                LoadComboBox();
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (indexSelect == comboBox_Products.SelectedIndex)
            {
                Product product = products[indexSelect];
                DataManagement.Delete(product);
                CleanProduct();
                LoadComboBox();
            }
        }
    }
}
