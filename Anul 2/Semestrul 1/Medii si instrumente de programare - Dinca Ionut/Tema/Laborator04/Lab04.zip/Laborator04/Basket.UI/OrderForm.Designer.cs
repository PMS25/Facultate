﻿namespace Basket.UI
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker_ExpirationDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_CreateDate = new System.Windows.Forms.DateTimePicker();
            this.label_text_ExpirationDate = new System.Windows.Forms.Label();
            this.textBox_Price = new System.Windows.Forms.TextBox();
            this.textBox_Category = new System.Windows.Forms.TextBox();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.textBox_BarCode = new System.Windows.Forms.TextBox();
            this.label_text_CreateDate = new System.Windows.Forms.Label();
            this.label_text_Price = new System.Windows.Forms.Label();
            this.label_text_Category = new System.Windows.Forms.Label();
            this.label_text_Name = new System.Windows.Forms.Label();
            this.label_text_BarCode = new System.Windows.Forms.Label();
            this.label_text_AddOrder = new System.Windows.Forms.Label();
            this.comboBox_Products = new System.Windows.Forms.ComboBox();
            this.label_text_Cantity = new System.Windows.Forms.Label();
            this.textBox_Cantity = new System.Windows.Forms.TextBox();
            this.button_Add = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.label_text_Order = new System.Windows.Forms.Label();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.label_text_Total = new System.Windows.Forms.Label();
            this.textBox_Total = new System.Windows.Forms.TextBox();
            this.button_Finish = new System.Windows.Forms.Button();
            this.button_Delete_All = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker_ExpirationDate
            // 
            this.dateTimePicker_ExpirationDate.CustomFormat = "dd/MM/yyyy - HH:mm";
            this.dateTimePicker_ExpirationDate.Enabled = false;
            this.dateTimePicker_ExpirationDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_ExpirationDate.Location = new System.Drawing.Point(102, 198);
            this.dateTimePicker_ExpirationDate.Name = "dateTimePicker_ExpirationDate";
            this.dateTimePicker_ExpirationDate.ShowUpDown = true;
            this.dateTimePicker_ExpirationDate.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker_ExpirationDate.TabIndex = 30;
            // 
            // dateTimePicker_CreateDate
            // 
            this.dateTimePicker_CreateDate.CustomFormat = "dd/MM/yyyy - HH:mm";
            this.dateTimePicker_CreateDate.Enabled = false;
            this.dateTimePicker_CreateDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_CreateDate.Location = new System.Drawing.Point(102, 172);
            this.dateTimePicker_CreateDate.Name = "dateTimePicker_CreateDate";
            this.dateTimePicker_CreateDate.ShowUpDown = true;
            this.dateTimePicker_CreateDate.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker_CreateDate.TabIndex = 29;
            // 
            // label_text_ExpirationDate
            // 
            this.label_text_ExpirationDate.AutoSize = true;
            this.label_text_ExpirationDate.Location = new System.Drawing.Point(12, 204);
            this.label_text_ExpirationDate.Name = "label_text_ExpirationDate";
            this.label_text_ExpirationDate.Size = new System.Drawing.Size(76, 13);
            this.label_text_ExpirationDate.TabIndex = 28;
            this.label_text_ExpirationDate.Text = "ExpirationDate";
            // 
            // textBox_Price
            // 
            this.textBox_Price.Location = new System.Drawing.Point(102, 146);
            this.textBox_Price.Name = "textBox_Price";
            this.textBox_Price.ReadOnly = true;
            this.textBox_Price.Size = new System.Drawing.Size(231, 20);
            this.textBox_Price.TabIndex = 27;
            // 
            // textBox_Category
            // 
            this.textBox_Category.Location = new System.Drawing.Point(102, 120);
            this.textBox_Category.Name = "textBox_Category";
            this.textBox_Category.ReadOnly = true;
            this.textBox_Category.Size = new System.Drawing.Size(231, 20);
            this.textBox_Category.TabIndex = 26;
            // 
            // textBox_Name
            // 
            this.textBox_Name.Location = new System.Drawing.Point(102, 94);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.ReadOnly = true;
            this.textBox_Name.Size = new System.Drawing.Size(231, 20);
            this.textBox_Name.TabIndex = 25;
            // 
            // textBox_BarCode
            // 
            this.textBox_BarCode.Location = new System.Drawing.Point(102, 68);
            this.textBox_BarCode.Name = "textBox_BarCode";
            this.textBox_BarCode.ReadOnly = true;
            this.textBox_BarCode.Size = new System.Drawing.Size(231, 20);
            this.textBox_BarCode.TabIndex = 24;
            // 
            // label_text_CreateDate
            // 
            this.label_text_CreateDate.AutoSize = true;
            this.label_text_CreateDate.Location = new System.Drawing.Point(12, 178);
            this.label_text_CreateDate.Name = "label_text_CreateDate";
            this.label_text_CreateDate.Size = new System.Drawing.Size(61, 13);
            this.label_text_CreateDate.TabIndex = 23;
            this.label_text_CreateDate.Text = "CreateDate";
            // 
            // label_text_Price
            // 
            this.label_text_Price.AutoSize = true;
            this.label_text_Price.Location = new System.Drawing.Point(12, 149);
            this.label_text_Price.Name = "label_text_Price";
            this.label_text_Price.Size = new System.Drawing.Size(31, 13);
            this.label_text_Price.TabIndex = 22;
            this.label_text_Price.Text = "Price";
            // 
            // label_text_Category
            // 
            this.label_text_Category.AutoSize = true;
            this.label_text_Category.Location = new System.Drawing.Point(12, 123);
            this.label_text_Category.Name = "label_text_Category";
            this.label_text_Category.Size = new System.Drawing.Size(49, 13);
            this.label_text_Category.TabIndex = 21;
            this.label_text_Category.Text = "Category";
            // 
            // label_text_Name
            // 
            this.label_text_Name.AutoSize = true;
            this.label_text_Name.Location = new System.Drawing.Point(12, 97);
            this.label_text_Name.Name = "label_text_Name";
            this.label_text_Name.Size = new System.Drawing.Size(35, 13);
            this.label_text_Name.TabIndex = 20;
            this.label_text_Name.Text = "Name";
            // 
            // label_text_BarCode
            // 
            this.label_text_BarCode.AutoSize = true;
            this.label_text_BarCode.Location = new System.Drawing.Point(12, 71);
            this.label_text_BarCode.Name = "label_text_BarCode";
            this.label_text_BarCode.Size = new System.Drawing.Size(48, 13);
            this.label_text_BarCode.TabIndex = 19;
            this.label_text_BarCode.Text = "BarCode";
            // 
            // label_text_AddOrder
            // 
            this.label_text_AddOrder.AutoSize = true;
            this.label_text_AddOrder.Location = new System.Drawing.Point(139, 9);
            this.label_text_AddOrder.Name = "label_text_AddOrder";
            this.label_text_AddOrder.Size = new System.Drawing.Size(72, 13);
            this.label_text_AddOrder.TabIndex = 31;
            this.label_text_AddOrder.Text = "Adauga Ordin";
            // 
            // comboBox_Products
            // 
            this.comboBox_Products.FormattingEnabled = true;
            this.comboBox_Products.Location = new System.Drawing.Point(15, 34);
            this.comboBox_Products.Name = "comboBox_Products";
            this.comboBox_Products.Size = new System.Drawing.Size(318, 21);
            this.comboBox_Products.TabIndex = 32;
            this.comboBox_Products.SelectedIndexChanged += new System.EventHandler(this.comboBox_Products_SelectedIndexChanged);
            // 
            // label_text_Cantity
            // 
            this.label_text_Cantity.AutoSize = true;
            this.label_text_Cantity.Location = new System.Drawing.Point(12, 234);
            this.label_text_Cantity.Name = "label_text_Cantity";
            this.label_text_Cantity.Size = new System.Drawing.Size(49, 13);
            this.label_text_Cantity.TabIndex = 33;
            this.label_text_Cantity.Text = "Cantitate";
            // 
            // textBox_Cantity
            // 
            this.textBox_Cantity.Location = new System.Drawing.Point(102, 231);
            this.textBox_Cantity.Name = "textBox_Cantity";
            this.textBox_Cantity.Size = new System.Drawing.Size(231, 20);
            this.textBox_Cantity.TabIndex = 34;
            this.textBox_Cantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Cantity_KeyPress);
            // 
            // button_Add
            // 
            this.button_Add.Location = new System.Drawing.Point(102, 270);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(109, 23);
            this.button_Add.TabIndex = 35;
            this.button_Add.Text = "Adauga";
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(361, 34);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.Size = new System.Drawing.Size(388, 283);
            this.dataGridView.TabIndex = 36;
            // 
            // label_text_Order
            // 
            this.label_text_Order.AutoSize = true;
            this.label_text_Order.Location = new System.Drawing.Point(541, 9);
            this.label_text_Order.Name = "label_text_Order";
            this.label_text_Order.Size = new System.Drawing.Size(47, 13);
            this.label_text_Order.TabIndex = 37;
            this.label_text_Order.Text = "Comenzi";
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(361, 369);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(120, 23);
            this.button_Edit.TabIndex = 38;
            this.button_Edit.Text = "Editeaza";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(487, 369);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(133, 23);
            this.button_Delete.TabIndex = 39;
            this.button_Delete.Text = "Sterge";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // label_text_Total
            // 
            this.label_text_Total.AutoSize = true;
            this.label_text_Total.Location = new System.Drawing.Point(358, 335);
            this.label_text_Total.Name = "label_text_Total";
            this.label_text_Total.Size = new System.Drawing.Size(31, 13);
            this.label_text_Total.TabIndex = 40;
            this.label_text_Total.Text = "Total";
            // 
            // textBox_Total
            // 
            this.textBox_Total.Location = new System.Drawing.Point(395, 332);
            this.textBox_Total.Name = "textBox_Total";
            this.textBox_Total.ReadOnly = true;
            this.textBox_Total.Size = new System.Drawing.Size(354, 20);
            this.textBox_Total.TabIndex = 41;
            // 
            // button_Finish
            // 
            this.button_Finish.Location = new System.Drawing.Point(15, 369);
            this.button_Finish.Name = "button_Finish";
            this.button_Finish.Size = new System.Drawing.Size(318, 23);
            this.button_Finish.TabIndex = 42;
            this.button_Finish.Text = "Finish";
            this.button_Finish.UseVisualStyleBackColor = true;
            this.button_Finish.Click += new System.EventHandler(this.button_Finish_Click);
            // 
            // button_Delete_All
            // 
            this.button_Delete_All.Location = new System.Drawing.Point(626, 369);
            this.button_Delete_All.Name = "button_Delete_All";
            this.button_Delete_All.Size = new System.Drawing.Size(123, 23);
            this.button_Delete_All.TabIndex = 43;
            this.button_Delete_All.Text = "Sterge Tot";
            this.button_Delete_All.UseVisualStyleBackColor = true;
            this.button_Delete_All.Click += new System.EventHandler(this.button_Delete_All_Click);
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 415);
            this.Controls.Add(this.button_Delete_All);
            this.Controls.Add(this.button_Finish);
            this.Controls.Add(this.textBox_Total);
            this.Controls.Add(this.label_text_Total);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Edit);
            this.Controls.Add(this.label_text_Order);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.button_Add);
            this.Controls.Add(this.textBox_Cantity);
            this.Controls.Add(this.label_text_Cantity);
            this.Controls.Add(this.comboBox_Products);
            this.Controls.Add(this.label_text_AddOrder);
            this.Controls.Add(this.dateTimePicker_ExpirationDate);
            this.Controls.Add(this.dateTimePicker_CreateDate);
            this.Controls.Add(this.label_text_ExpirationDate);
            this.Controls.Add(this.textBox_Price);
            this.Controls.Add(this.textBox_Category);
            this.Controls.Add(this.textBox_Name);
            this.Controls.Add(this.textBox_BarCode);
            this.Controls.Add(this.label_text_CreateDate);
            this.Controls.Add(this.label_text_Price);
            this.Controls.Add(this.label_text_Category);
            this.Controls.Add(this.label_text_Name);
            this.Controls.Add(this.label_text_BarCode);
            this.Name = "OrderForm";
            this.Text = "OrderForm";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker_ExpirationDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_CreateDate;
        private System.Windows.Forms.Label label_text_ExpirationDate;
        private System.Windows.Forms.TextBox textBox_Price;
        private System.Windows.Forms.TextBox textBox_Category;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.TextBox textBox_BarCode;
        private System.Windows.Forms.Label label_text_CreateDate;
        private System.Windows.Forms.Label label_text_Price;
        private System.Windows.Forms.Label label_text_Category;
        private System.Windows.Forms.Label label_text_Name;
        private System.Windows.Forms.Label label_text_BarCode;
        private System.Windows.Forms.Label label_text_AddOrder;
        private System.Windows.Forms.ComboBox comboBox_Products;
        private System.Windows.Forms.Label label_text_Cantity;
        private System.Windows.Forms.TextBox textBox_Cantity;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label label_text_Order;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Label label_text_Total;
        private System.Windows.Forms.TextBox textBox_Total;
        private System.Windows.Forms.Button button_Finish;
        private System.Windows.Forms.Button button_Delete_All;
    }
}