﻿namespace Basket.UI
{
    partial class BasketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_text_Basket = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.textBox_Total = new System.Windows.Forms.TextBox();
            this.label_text_Total = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label_text_Basket
            // 
            this.label_text_Basket.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_text_Basket.AutoSize = true;
            this.label_text_Basket.Location = new System.Drawing.Point(315, 9);
            this.label_text_Basket.Name = "label_text_Basket";
            this.label_text_Basket.Size = new System.Drawing.Size(98, 13);
            this.label_text_Basket.TabIndex = 0;
            this.label_text_Basket.Text = "Cos de cumparaturi";
            // 
            // dataGridView
            // 
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 35);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(704, 303);
            this.dataGridView.TabIndex = 1;
            // 
            // textBox_Total
            // 
            this.textBox_Total.Location = new System.Drawing.Point(318, 359);
            this.textBox_Total.Name = "textBox_Total";
            this.textBox_Total.ReadOnly = true;
            this.textBox_Total.Size = new System.Drawing.Size(156, 20);
            this.textBox_Total.TabIndex = 43;
            // 
            // label_text_Total
            // 
            this.label_text_Total.AutoSize = true;
            this.label_text_Total.Location = new System.Drawing.Point(281, 362);
            this.label_text_Total.Name = "label_text_Total";
            this.label_text_Total.Size = new System.Drawing.Size(31, 13);
            this.label_text_Total.TabIndex = 42;
            this.label_text_Total.Text = "Total";
            // 
            // BasketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 392);
            this.Controls.Add(this.textBox_Total);
            this.Controls.Add(this.label_text_Total);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.label_text_Basket);
            this.Name = "BasketForm";
            this.Text = "Backet";
            this.Load += new System.EventHandler(this.BasketForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_text_Basket;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox textBox_Total;
        private System.Windows.Forms.Label label_text_Total;
    }
}