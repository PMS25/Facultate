﻿namespace Basket.UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_AddProducts = new System.Windows.Forms.Button();
            this.button_AddOrders = new System.Windows.Forms.Button();
            this.button_ShowBasket = new System.Windows.Forms.Button();
            this.label_text_start = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_AddProducts
            // 
            this.button_AddProducts.Location = new System.Drawing.Point(12, 67);
            this.button_AddProducts.Name = "button_AddProducts";
            this.button_AddProducts.Size = new System.Drawing.Size(155, 23);
            this.button_AddProducts.TabIndex = 0;
            this.button_AddProducts.Text = "Adauga Produse";
            this.button_AddProducts.UseVisualStyleBackColor = true;
            this.button_AddProducts.Click += new System.EventHandler(this.button_AddProducts_Click);
            // 
            // button_AddOrders
            // 
            this.button_AddOrders.Location = new System.Drawing.Point(173, 67);
            this.button_AddOrders.Name = "button_AddOrders";
            this.button_AddOrders.Size = new System.Drawing.Size(165, 23);
            this.button_AddOrders.TabIndex = 1;
            this.button_AddOrders.Text = "Adauga Comenzi";
            this.button_AddOrders.UseVisualStyleBackColor = true;
            this.button_AddOrders.Click += new System.EventHandler(this.button_AddOrders_Click);
            // 
            // button_ShowBasket
            // 
            this.button_ShowBasket.Location = new System.Drawing.Point(344, 67);
            this.button_ShowBasket.Name = "button_ShowBasket";
            this.button_ShowBasket.Size = new System.Drawing.Size(160, 23);
            this.button_ShowBasket.TabIndex = 2;
            this.button_ShowBasket.Text = "Afisare Cos";
            this.button_ShowBasket.UseVisualStyleBackColor = true;
            this.button_ShowBasket.Click += new System.EventHandler(this.button_ShowBasket_Click);
            // 
            // label_text_start
            // 
            this.label_text_start.AutoSize = true;
            this.label_text_start.Location = new System.Drawing.Point(219, 9);
            this.label_text_start.Name = "label_text_start";
            this.label_text_start.Size = new System.Drawing.Size(76, 13);
            this.label_text_start.TabIndex = 3;
            this.label_text_start.Text = "Meniu de Start";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 135);
            this.Controls.Add(this.label_text_start);
            this.Controls.Add(this.button_ShowBasket);
            this.Controls.Add(this.button_AddOrders);
            this.Controls.Add(this.button_AddProducts);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_AddProducts;
        private System.Windows.Forms.Button button_AddOrders;
        private System.Windows.Forms.Button button_ShowBasket;
        private System.Windows.Forms.Label label_text_start;
    }
}

