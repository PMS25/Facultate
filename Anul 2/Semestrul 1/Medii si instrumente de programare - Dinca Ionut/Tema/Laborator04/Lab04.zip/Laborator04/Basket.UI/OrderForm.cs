﻿using Basket.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basket.UI
{
    public partial class OrderForm : Form
    {
        private List<Product> products;
        private List<Order> orders;
        private int indexSelect;

        public OrderForm()
        {
            InitializeComponent();
        }
        private void LoadComboBox()
        {
            comboBox_Products.Items.Clear();
            comboBox_Products.ResetText();
            products = DataManagement.GetAllProducts();
            foreach (Product p in products)
            {
                string product = $"{p.BarCode}: {p.Name} - {p.Price}";
                comboBox_Products.Items.Add(product);
            }
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            orders = new List<Order>();
            LoadComboBox();

            dataGridView.Columns.Add("BarCode", "BarCode");
            dataGridView.Columns.Add("Product", "Denumire Produs");
            dataGridView.Columns.Add("Cantity", "Cantitate");
            dataGridView.Columns.Add("Price", "Pret");
        }

        

        private void LoadProductToInput()
        {
            textBox_BarCode.Text = products[indexSelect].BarCode;
            textBox_Name.Text = products[indexSelect].Name;
            textBox_Price.Text = products[indexSelect].Price.ToString();
            textBox_Category.Text = products[indexSelect].Category;
            dateTimePicker_CreateDate.Value = products[indexSelect].CreateDate;
            dateTimePicker_ExpirationDate.Value = products[indexSelect].ExpirationDate;
        }

        private void comboBox_Products_SelectedIndexChanged(object sender, EventArgs e)
        {
            indexSelect = comboBox_Products.SelectedIndex;
            LoadProductToInput();
        }

        private void textBox_Cantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            if(indexSelect == comboBox_Products.SelectedIndex)
            {
                Order order = new Order();
                order.Id = new Random().Next(1, int.MaxValue);
                order.ProductBarcode = products[indexSelect].BarCode;
                order.Count = int.Parse(textBox_Cantity.Text);
                order.Date = DateTime.Now;

                if(GetOrderByBarCode(order.ProductBarcode) == null)
                    orders.Add(order);
            }
            UpdateGridView();
        }


        private Order GetOrderByBarCode(string barCode)
        {
            foreach (Order o in orders)
                if (o.ProductBarcode == barCode)
                    return o;
            return null;
        }

        private Product GetProductByBarCode(string barCode)
        {
            foreach (Product p in products)
                if (p.BarCode == barCode)
                    return p;
            return null;
        }

        private void UpdateGridView()
        {
            dataGridView.Rows.Clear();
            double s = 0;
            foreach(Order o in orders)
            {
                Product p = GetProductByBarCode(o.ProductBarcode);
                var c1 = o.ProductBarcode;
                var c2 = p.Name;
                var c3 = o.Count;
                var c4 = p.Price * o.Count;
                s += c4;

                dataGridView.Rows.Add(new object[] { c1, c2, c3, c4 });
            }
            textBox_Total.Text = s.ToString();
        }


        private void DeleteOrder()
        {
            int index = dataGridView.CurrentCell.RowIndex;
            string BarCode = dataGridView.Rows[index].Cells[0].Value.ToString();
            orders.Remove(GetOrderByBarCode(BarCode));
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            DeleteOrder();
            UpdateGridView();
        }

        private void button_Delete_All_Click(object sender, EventArgs e)
        {
            orders.Clear();
            UpdateGridView();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            int index = dataGridView.CurrentCell.RowIndex;
            string BarCode = dataGridView.Rows[index].Cells[0].Value.ToString();
            for (int i = 0; i < products.Count; i++)
                if (products[i].BarCode == BarCode)
                    indexSelect = i;
            comboBox_Products.SelectedIndex = indexSelect;
            LoadProductToInput();
            textBox_Cantity.Text = dataGridView.Rows[index].Cells[2].Value.ToString();
            DeleteOrder();
            UpdateGridView();
        }

        private void button_Finish_Click(object sender, EventArgs e)
        {
            DataManagement.Delete(new Basket.Models.Basket());
            Basket.Models.Basket basket = new Basket.Models.Basket();
            foreach (Order o in orders)
                basket.AddOrder(o);

            DataManagement.Save(basket);
        }
    }
}
