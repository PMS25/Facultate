﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basket.UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_AddProducts_Click(object sender, EventArgs e)
        {
            ProductForm f = new ProductForm();
            f.Show();
        }

        private void button_AddOrders_Click(object sender, EventArgs e)
        {
            OrderForm f = new OrderForm();
            f.Show();
        }

        private void button_ShowBasket_Click(object sender, EventArgs e)
        {
            BasketForm f = new BasketForm();
            f.Show();
        }
    }
}
