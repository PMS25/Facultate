﻿using Basket.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basket.UI
{
    public partial class BasketForm : Form
    {
        private Basket.Models.Basket basket;
        private List<Product> products;

        public BasketForm()
        {
            InitializeComponent();
        }

        private void LoadGridView()
        {
            dataGridView.Rows.Clear();
            double s = 0;
            foreach(Order o in basket.Orders)
            {
                Product p = GetProductByBarCode(o.ProductBarcode);
                var c1 = o.ProductBarcode;
                var c2 = p.Name;
                var c3 = p.Category;
                var c4 = p.ExpirationDate;
                var c5 = o.Count;
                var c6 = p.Price * o.Count;
                s += c6;

                dataGridView.Rows.Add(new object[] { c1, c2, c3, c4, c5, c6 });
            }
            textBox_Total.Text = s.ToString();
        }

        private Product GetProductByBarCode(string barCode)
        {
            foreach (Product p in products)
                if (p.BarCode == barCode)
                    return p;
            return null;
        }

        private void DataGridColumns()
        {
            dataGridView.Columns.Add("BarCode", "BarCode");
            dataGridView.Columns.Add("Product", "Denumire Produs");
            dataGridView.Columns.Add("Category", "Categorie");
            dataGridView.Columns.Add("ExpirationDate", "Data de Expirare");
            dataGridView.Columns.Add("Cantity", "Cantitate");
            dataGridView.Columns.Add("Price", "Pret");
        }

        private void BasketForm_Load(object sender, EventArgs e)
        {
            basket = DataManagement.GetBasket();
            products = DataManagement.GetAllProducts();
            DataGridColumns();
            LoadGridView();
        }
    }
}
