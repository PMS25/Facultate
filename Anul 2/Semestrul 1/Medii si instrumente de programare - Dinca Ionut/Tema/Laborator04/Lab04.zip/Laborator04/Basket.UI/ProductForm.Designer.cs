﻿namespace Basket.UI
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_text_BarCode = new System.Windows.Forms.Label();
            this.label_text_Name = new System.Windows.Forms.Label();
            this.label_text_Category = new System.Windows.Forms.Label();
            this.label_text_Price = new System.Windows.Forms.Label();
            this.label_text_CreateDate = new System.Windows.Forms.Label();
            this.label_text_add = new System.Windows.Forms.Label();
            this.comboBox_Products = new System.Windows.Forms.ComboBox();
            this.textBox_BarCode = new System.Windows.Forms.TextBox();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.textBox_Category = new System.Windows.Forms.TextBox();
            this.textBox_Price = new System.Windows.Forms.TextBox();
            this.label_text_ExpirationDate = new System.Windows.Forms.Label();
            this.button_Add = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.dateTimePicker_CreateDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_ExpirationDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label_text_BarCode
            // 
            this.label_text_BarCode.AutoSize = true;
            this.label_text_BarCode.Location = new System.Drawing.Point(15, 130);
            this.label_text_BarCode.Name = "label_text_BarCode";
            this.label_text_BarCode.Size = new System.Drawing.Size(48, 13);
            this.label_text_BarCode.TabIndex = 0;
            this.label_text_BarCode.Text = "BarCode";
            // 
            // label_text_Name
            // 
            this.label_text_Name.AutoSize = true;
            this.label_text_Name.Location = new System.Drawing.Point(15, 156);
            this.label_text_Name.Name = "label_text_Name";
            this.label_text_Name.Size = new System.Drawing.Size(35, 13);
            this.label_text_Name.TabIndex = 1;
            this.label_text_Name.Text = "Name";
            // 
            // label_text_Category
            // 
            this.label_text_Category.AutoSize = true;
            this.label_text_Category.Location = new System.Drawing.Point(15, 182);
            this.label_text_Category.Name = "label_text_Category";
            this.label_text_Category.Size = new System.Drawing.Size(49, 13);
            this.label_text_Category.TabIndex = 2;
            this.label_text_Category.Text = "Category";
            // 
            // label_text_Price
            // 
            this.label_text_Price.AutoSize = true;
            this.label_text_Price.Location = new System.Drawing.Point(15, 208);
            this.label_text_Price.Name = "label_text_Price";
            this.label_text_Price.Size = new System.Drawing.Size(31, 13);
            this.label_text_Price.TabIndex = 3;
            this.label_text_Price.Text = "Price";
            // 
            // label_text_CreateDate
            // 
            this.label_text_CreateDate.AutoSize = true;
            this.label_text_CreateDate.Location = new System.Drawing.Point(15, 237);
            this.label_text_CreateDate.Name = "label_text_CreateDate";
            this.label_text_CreateDate.Size = new System.Drawing.Size(61, 13);
            this.label_text_CreateDate.TabIndex = 4;
            this.label_text_CreateDate.Text = "CreateDate";
            // 
            // label_text_add
            // 
            this.label_text_add.AutoSize = true;
            this.label_text_add.Location = new System.Drawing.Point(136, 9);
            this.label_text_add.Name = "label_text_add";
            this.label_text_add.Size = new System.Drawing.Size(86, 13);
            this.label_text_add.TabIndex = 5;
            this.label_text_add.Text = "Adauga Produse";
            // 
            // comboBox_Products
            // 
            this.comboBox_Products.FormattingEnabled = true;
            this.comboBox_Products.Location = new System.Drawing.Point(18, 42);
            this.comboBox_Products.Name = "comboBox_Products";
            this.comboBox_Products.Size = new System.Drawing.Size(318, 21);
            this.comboBox_Products.TabIndex = 6;
            this.comboBox_Products.SelectedIndexChanged += new System.EventHandler(this.comboBox_Products_SelectedIndexChanged);
            // 
            // textBox_BarCode
            // 
            this.textBox_BarCode.Location = new System.Drawing.Point(105, 127);
            this.textBox_BarCode.Name = "textBox_BarCode";
            this.textBox_BarCode.Size = new System.Drawing.Size(231, 20);
            this.textBox_BarCode.TabIndex = 7;
            // 
            // textBox_Name
            // 
            this.textBox_Name.Location = new System.Drawing.Point(105, 153);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(231, 20);
            this.textBox_Name.TabIndex = 8;
            // 
            // textBox_Category
            // 
            this.textBox_Category.Location = new System.Drawing.Point(105, 179);
            this.textBox_Category.Name = "textBox_Category";
            this.textBox_Category.Size = new System.Drawing.Size(231, 20);
            this.textBox_Category.TabIndex = 9;
            // 
            // textBox_Price
            // 
            this.textBox_Price.Location = new System.Drawing.Point(105, 205);
            this.textBox_Price.Name = "textBox_Price";
            this.textBox_Price.Size = new System.Drawing.Size(231, 20);
            this.textBox_Price.TabIndex = 10;
            this.textBox_Price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Price_KeyPress);
            // 
            // label_text_ExpirationDate
            // 
            this.label_text_ExpirationDate.AutoSize = true;
            this.label_text_ExpirationDate.Location = new System.Drawing.Point(15, 263);
            this.label_text_ExpirationDate.Name = "label_text_ExpirationDate";
            this.label_text_ExpirationDate.Size = new System.Drawing.Size(76, 13);
            this.label_text_ExpirationDate.TabIndex = 12;
            this.label_text_ExpirationDate.Text = "ExpirationDate";
            // 
            // button_Add
            // 
            this.button_Add.Location = new System.Drawing.Point(105, 301);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(231, 23);
            this.button_Add.TabIndex = 14;
            this.button_Add.Text = "Adauga";
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(18, 69);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(161, 23);
            this.button_Update.TabIndex = 15;
            this.button_Update.Text = "Actualizare";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(185, 69);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(151, 23);
            this.button_Delete.TabIndex = 16;
            this.button_Delete.Text = "Sterge";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // dateTimePicker_CreateDate
            // 
            this.dateTimePicker_CreateDate.CustomFormat = "dd/MM/yyyy - HH:mm";
            this.dateTimePicker_CreateDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_CreateDate.Location = new System.Drawing.Point(105, 231);
            this.dateTimePicker_CreateDate.Name = "dateTimePicker_CreateDate";
            this.dateTimePicker_CreateDate.ShowUpDown = true;
            this.dateTimePicker_CreateDate.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker_CreateDate.TabIndex = 17;
            // 
            // dateTimePicker_ExpirationDate
            // 
            this.dateTimePicker_ExpirationDate.CustomFormat = "dd/MM/yyyy - HH:mm";
            this.dateTimePicker_ExpirationDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_ExpirationDate.Location = new System.Drawing.Point(105, 257);
            this.dateTimePicker_ExpirationDate.Name = "dateTimePicker_ExpirationDate";
            this.dateTimePicker_ExpirationDate.ShowUpDown = true;
            this.dateTimePicker_ExpirationDate.Size = new System.Drawing.Size(231, 20);
            this.dateTimePicker_ExpirationDate.TabIndex = 18;
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 359);
            this.Controls.Add(this.dateTimePicker_ExpirationDate);
            this.Controls.Add(this.dateTimePicker_CreateDate);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Add);
            this.Controls.Add(this.label_text_ExpirationDate);
            this.Controls.Add(this.textBox_Price);
            this.Controls.Add(this.textBox_Category);
            this.Controls.Add(this.textBox_Name);
            this.Controls.Add(this.textBox_BarCode);
            this.Controls.Add(this.comboBox_Products);
            this.Controls.Add(this.label_text_add);
            this.Controls.Add(this.label_text_CreateDate);
            this.Controls.Add(this.label_text_Price);
            this.Controls.Add(this.label_text_Category);
            this.Controls.Add(this.label_text_Name);
            this.Controls.Add(this.label_text_BarCode);
            this.Name = "ProductForm";
            this.Text = "ProductForm";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_text_BarCode;
        private System.Windows.Forms.Label label_text_Name;
        private System.Windows.Forms.Label label_text_Category;
        private System.Windows.Forms.Label label_text_Price;
        private System.Windows.Forms.Label label_text_CreateDate;
        private System.Windows.Forms.Label label_text_add;
        private System.Windows.Forms.ComboBox comboBox_Products;
        private System.Windows.Forms.TextBox textBox_BarCode;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.TextBox textBox_Category;
        private System.Windows.Forms.TextBox textBox_Price;
        private System.Windows.Forms.Label label_text_ExpirationDate;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.DateTimePicker dateTimePicker_CreateDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_ExpirationDate;
    }
}