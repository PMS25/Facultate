﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Student.Models
{
    public class StudentList
    {
        public List<StudentModel> Students { get; set; }
        private static string studentPath = "Students";
        private static string coursePath = "Courses";

        public StudentList()
        {
            Students = new List<StudentModel>();
            CreatePath();
        }

        public void Add(StudentModel stud)
        {
            Students.Add(stud);
        }

        public void ReadStudentFromConsole()
        {
            Console.WriteLine("Citire Date Studenti");
            string input = String.Empty;
            int count = 1;

            do
            {
                Console.WriteLine($"Student #{count++}");
                StudentModel student = new StudentModel();

                Console.Write($"| Id = ");
                student.Id = int.Parse(Console.ReadLine());

                Console.Write($"| Nume = ");
                student.Name = Console.ReadLine().Trim();

                Console.Write($"| Facultate = ");
                student.Faculty = Console.ReadLine().Trim();

                Console.Write($"| Mail = ");
                student.Email = Console.ReadLine().Trim();

                List<CourseModel> courses = ReadCourseFromConsole();
                foreach (CourseModel course in courses)
                    student.Courses.Add(course);

                Console.Write($"| Press 'q' to exit: ");
                input = Console.ReadLine().Trim();

                Add(student);
            } while (input.Trim() != "q");
        }

        private List<CourseModel> ReadCourseFromConsole()
        {
            List<CourseModel> courses = new List<CourseModel>();
            string input = String.Empty;
            int count = 1;

            do
            {
                Console.WriteLine($"| Courses:");
                Console.WriteLine($"| Course #{count++}");
                CourseModel course = new CourseModel();

                Console.Write($"| | Id = ");
                course.Id = int.Parse(Console.ReadLine());

                Console.Write($"| | Name = ");
                course.Name = Console.ReadLine();

                Console.Write($"| | StartDate = ");
                course.StartDate = DateTime.Parse(Console.ReadLine());

                Console.Write($"| | EndDate = ");
                course.EndDate = DateTime.Parse(Console.ReadLine());

                Console.Write($"| | Press 'q' to exit: ");
                input = Console.ReadLine().Trim();
                courses.Add(course);
            } while (input.Trim() != "q");

            return courses;
        }

        public void DisplayInfoToConsole()
        {
            Console.WriteLine("\nAfisare informatii:");
            foreach (StudentModel student in Students)
            {
                Console.WriteLine($"- {ParseStudentToText(student)}");
                Console.WriteLine("{");
                foreach (CourseModel course in student.Courses)
                    Console.WriteLine($"| {ParseCourseToText(course)}");
                Console.WriteLine("}");
            }
        }

        public void SaveOnDisk()
        {
            foreach(StudentModel student in Students)
            {
                SaveStudentOnDisk(student);
                foreach (CourseModel course in student.Courses)
                    SaveCourseOnDisk(course);
            }
        }

        // Static Methods
        public static string ParseStudentToText(StudentModel student)
        {
            string st = string.Empty;
            st += $"{student.Id},";
            st += $"\"{student.Name}\",";
            st += $"\"{student.Faculty}\",";
            st += $"\"{student.Email}\",";
            foreach (CourseModel course in student.Courses)
                st += $"{course.Id},";
            return st.Substring(0, st.Length - 1);
        }

        public static string ParseCourseToText(CourseModel course)
        {
            string course_text = string.Empty;
            course_text += $"\"{course.Id}\",";
            course_text += $"\"{course.Name}\",";
            course_text += $"\"{course.StartDate}\",";
            course_text += $"\"{course.EndDate}\"";
            return course_text;
        }

        private static void CreatePath()
        {
            if (!Directory.Exists(studentPath))
                Directory.CreateDirectory(studentPath);

            if (!Directory.Exists(coursePath))
                Directory.CreateDirectory(coursePath);
        }

        private static void SaveStudentOnDisk(StudentModel student)
        {
            string fileName = $@"{studentPath}\{student.Id}.txt";
            File.Delete(fileName);
            File.WriteAllText(fileName, ParseStudentToText(student));
        }

        private static void SaveCourseOnDisk(CourseModel course)
        {
            string fileName = $@"{coursePath}\{course.Id}.txt";
            File.Delete(fileName);
            File.WriteAllText(fileName, ParseCourseToText(course));
        }

        public void LoadDataFromDisk()
        {
            string[] studentFiles = Directory.GetFiles(studentPath, "*.txt");
            foreach(string filepath in studentFiles)
                Add(ParseFileToStudent(filepath));
        }

        private static StudentModel ParseFileToStudent(string filepath)
        {
            StudentModel student = new StudentModel();
            string[] properties = File.ReadAllText(filepath).Split(',')
                .Select(s => s.Replace('"', ' ')).Select(s => s.Trim()).ToArray();
            student.Id = int.Parse(properties[0]);
            student.Name = properties[1];
            student.Faculty = properties[2];
            student.Email = properties[3];
            for (int i = 4; i < properties.Length; i++)
            {
                string path = $@"{coursePath}\{int.Parse(properties[i])}.txt";
                if (File.Exists(path))
                    student.Courses.Add(ParseFileToCourse(path));
            }
            return student;
        }

        private static CourseModel ParseFileToCourse(string filepath)
        {
            CourseModel course = new CourseModel();
            string[] properties = File.ReadAllText(filepath).Split(',')
                .Select(s => s.Replace('"',' ')).Select(s => s.Trim()).ToArray();
            course.Id = int.Parse(properties[0].Replace('"',' '));
            course.Name = properties[1];
            course.StartDate = (properties[2].Length <= 2 ? DateTime.MinValue : DateTime.Parse(properties[2]));
            course.EndDate = (properties[3].Length <= 2 ? DateTime.MinValue : DateTime.Parse(properties[3]));
            return course;
        }
    }
}
