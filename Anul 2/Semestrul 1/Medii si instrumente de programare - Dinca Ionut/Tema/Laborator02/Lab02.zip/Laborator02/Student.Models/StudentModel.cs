﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.Models
{
    public class StudentModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int Id { get; set; }
        public string Faculty { get; set; }
        public List<CourseModel> Courses { get; set; }
        public StudentModel()
        {
            Courses = new List<CourseModel>();
        }
    }
}
