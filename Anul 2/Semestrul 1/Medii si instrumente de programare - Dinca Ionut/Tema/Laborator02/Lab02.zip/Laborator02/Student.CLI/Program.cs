﻿using Student.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.CLI
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentList list = new StudentList();

            string input = String.Empty;
            do
            {
                Console.WriteLine("Meniu");
                Console.WriteLine("=====");
                Console.WriteLine("Apasati (a) pentru a adauga studenti.");
                Console.WriteLine("Apasati (b) pentru a incarca date salvate.");
                Console.WriteLine("Apasati (c) pentru a salva modificarile pe disk");
                Console.WriteLine("Apasati (d) pentru a afisa datele");
                Console.WriteLine("Apasati (q) pentru a iesi");
                Console.Write("Selectati optiunea: ");
                input = Console.ReadLine().Trim();

                if (input == "a")
                    list.ReadStudentFromConsole();
                if (input == "b")
                    list.LoadDataFromDisk();
                if (input == "c")
                    list.SaveOnDisk();
                if (input == "d")
                    list.DisplayInfoToConsole();
                Console.WriteLine();

            } while (input != "q");

            Console.ReadKey();
        }
    }
}
