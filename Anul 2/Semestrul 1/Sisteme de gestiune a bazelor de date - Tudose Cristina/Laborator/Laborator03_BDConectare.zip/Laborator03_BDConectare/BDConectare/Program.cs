﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDConectare
{
    class DB
    {
        //Exemplu pentru o baza de date in Access
        static string stringConectare = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\gabi\Documents\Database5.accdb";
        //Pentru o baza de date in SQLServer: 
        //static string stringConectare =@"Data Source=NumeServer; Initial Catalog=NumeBazaDeDate; Integrated Security=SSPI"; 
        //Exemplu concret:
        //static string stringConectare =@"Data Source=FUJITSU_AMILO; Initial Catalog=dbFacturare; Integrated Security=SSPI"; 

        //in cele de urmeaza, daca va conectati la o baza de date creata in SQLServer, modificati prefixul OleDb in Sql (peste tot in cod)

        //Baza de date folosita in acest program, contine tabelul tClienti (codClient, numeClient, localitate). Toate coloanele contin ca valori siruri  de caractere 
        public OleDbConnection con;

        public DB()
        {
            try
            {
                con = new OleDbConnection(stringConectare);
                con.Open();
                con.Close();
            }
            catch { Console.WriteLine("Esec la conectare"); }
        }

        public void ListareClienti()
        {
            try {
                string strSelect = "select *  from tclienti where localitate='pitesti'";
                OleDbCommand com = new OleDbCommand(strSelect, con);

                try
                {
                    con.Open();
                    OleDbDataReader dr = com.ExecuteReader(); //executa o interogare
                    Console.WriteLine("Lista clientilor din pitesti este: ");
                    while (dr.Read())
                    {
                        Console.WriteLine("{0,-10},{1,-50},{2,-25}", dr["codclient"], dr["numeclient"], dr["localitate"]);
                    }
                    dr.Close();
                }
                catch { Console.WriteLine("esec"); }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            con.Close();

       }

        public void InserareClient(string CodClient, string numeClient, string localitate)
        {
            string strInsert =
            "insert into tClienti(CodClient,NumeClient,Localitate) values ('" + CodClient + "', '" + numeClient + "', '" + localitate +"')";
            try
            {
                OleDbCommand cmd = new OleDbCommand(strInsert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                Console.WriteLine("Err: Inserare esuata\n" + strInsert);
            }
            
        }
        public void StergereClient(string codClient)
        {
            string strDelete = "delete from tClienti where codClient='" + codClient+"'";
            int n;
            try
            {
                OleDbCommand cmd = new OleDbCommand(strDelete, con);
                con.Open();
                n = cmd.ExecuteNonQuery();
                con.Close();
                if (n == 0) throw new Exception("Cod negasit");
            }
            catch (Exception e)
            {
                Console.WriteLine("Err: Stergere esuata\n" + strDelete + "\n" + e.ToString());
            };
        }
        public void ModificareNumeClient(string codClient, string numeClient)
        {
            string strUpdate = "update tClienti set NumeClient= '" + numeClient + "' where codClient='" + codClient + "'";
            try
            {
                OleDbCommand cmd = new OleDbCommand(strUpdate, con);
                con.Open();
                int n = cmd.ExecuteNonQuery(); //nr randuri afectate
                if (n == 0) throw new Exception("CodClient inexistent");
            }
            catch (Exception e)
            {
                Console.WriteLine("Err: Modificare esuata\n" + strUpdate + "\n" + e.ToString());
            }
            con.Close();
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            DB ob = new DB();
            ob.ListareClienti();
            ob.InserareClient("C010", "patrascu cristina", "pitesti");
            Console.WriteLine("Dupa inserare");
            ob.ListareClienti();
            ob.ModificareNumeClient("C010", "vasilescu cristina");
            Console.WriteLine("Dupa modificare");
            ob.ListareClienti();
            ob.StergereClient("C010");
            Console.WriteLine("Dupa stergere");
            ob.ListareClienti();
            Console.ReadKey();
        }
    }
}
