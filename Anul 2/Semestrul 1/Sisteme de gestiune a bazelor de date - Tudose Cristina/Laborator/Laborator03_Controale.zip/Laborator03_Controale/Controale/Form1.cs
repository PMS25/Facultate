﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Controale
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            cbStareCivila.Items.Add("Necasatorit");
            cbStareCivila.Items.AddRange(new string[3] { "Casatorit", "Divortat", "Vaduv" });
            cbStareCivila.SelectedIndex = 0;

            progresMedie.Minimum = 0;
            progresMedie.Maximum = 100;

            foreach (object t in this.Controls)
                if (t.GetType() == typeof(TextBox))
                    ((TextBox)t).BackColor = Color.Aquamarine;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bCalculeaza_Click(object sender, EventArgs e)
        {
            decimal medie;
            medie = (decimal.Parse(tbNotaEx.Text) + decimal.Parse(tbNotaL.Text)) / 2;
            tbNotaF.Text = medie.ToString();
            progresMedie.Value = (int)(progresMedie.Maximum * medie / 10);
        }

        private void bColecteaza_Click(object sender, EventArgs e)
        {
            lbComentariu.Text = "Student: " + tbNumeStd.Text + "\n";
            lbComentariu.Text += "Nota Examen: " + tbNotaEx.Text + "\n";
            lbComentariu.Text += "Nota Laborator: " + tbNotaL.Text + "\n";
            if (rbFeminin.Checked)
                lbComentariu.Text += "Feminin" + "\n";
            else
                if(rbMasculin.Checked)
                lbComentariu.Text += "Masculin" + "\n";
            else
                lbComentariu.Text += "Sex nespecificat" + "\n";

            if (cbEngleza.Checked) lbComentariu.Text += "Engleza" + "\n";
            if (cbFranceza.Checked) lbComentariu.Text += "Franceza" + "\n";
        }

        private void bUrmatorul_Click(object sender, EventArgs e)
        {
            tbNumeStd.Text = "";
            tbNotaL.Text = "";
            tbNotaEx.Text = "";
            tbNotaL.Text = "";
            lbComentariu.Text = "";
            cbEngleza.Checked = false;
            cbFranceza.Checked = false;
            rbFeminin.Checked = false;
            rbMasculin.Checked = false;
        }
    }
}
