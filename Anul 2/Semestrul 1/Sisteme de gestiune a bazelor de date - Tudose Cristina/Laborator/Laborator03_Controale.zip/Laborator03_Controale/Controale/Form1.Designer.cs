﻿namespace Controale
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbNumeStd = new System.Windows.Forms.Label();
            this.tbNumeStd = new System.Windows.Forms.TextBox();
            this.lbNotaEx = new System.Windows.Forms.Label();
            this.tbNotaEx = new System.Windows.Forms.TextBox();
            this.lbNotaL = new System.Windows.Forms.Label();
            this.lbNotaF = new System.Windows.Forms.Label();
            this.tbNotaL = new System.Windows.Forms.TextBox();
            this.tbNotaF = new System.Windows.Forms.TextBox();
            this.progresMedie = new System.Windows.Forms.ProgressBar();
            this.bCalculeaza = new System.Windows.Forms.Button();
            this.bColecteaza = new System.Windows.Forms.Button();
            this.lbComentariu = new System.Windows.Forms.Label();
            this.gbSex = new System.Windows.Forms.GroupBox();
            this.rbFeminin = new System.Windows.Forms.RadioButton();
            this.rbMasculin = new System.Windows.Forms.RadioButton();
            this.gbLimba = new System.Windows.Forms.GroupBox();
            this.cbFranceza = new System.Windows.Forms.CheckBox();
            this.cbEngleza = new System.Windows.Forms.CheckBox();
            this.bUrmatorul = new System.Windows.Forms.Button();
            this.cbStareCivila = new System.Windows.Forms.ComboBox();
            this.gbSex.SuspendLayout();
            this.gbLimba.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbNumeStd
            // 
            this.lbNumeStd.AutoSize = true;
            this.lbNumeStd.Location = new System.Drawing.Point(22, 32);
            this.lbNumeStd.Name = "lbNumeStd";
            this.lbNumeStd.Size = new System.Drawing.Size(73, 13);
            this.lbNumeStd.TabIndex = 0;
            this.lbNumeStd.Text = "Nume student";
            // 
            // tbNumeStd
            // 
            this.tbNumeStd.Location = new System.Drawing.Point(126, 24);
            this.tbNumeStd.Name = "tbNumeStd";
            this.tbNumeStd.Size = new System.Drawing.Size(100, 20);
            this.tbNumeStd.TabIndex = 1;
            // 
            // lbNotaEx
            // 
            this.lbNotaEx.AutoSize = true;
            this.lbNotaEx.Location = new System.Drawing.Point(24, 68);
            this.lbNotaEx.Name = "lbNotaEx";
            this.lbNotaEx.Size = new System.Drawing.Size(71, 13);
            this.lbNotaEx.TabIndex = 2;
            this.lbNotaEx.Text = "Nota Examen";
            // 
            // tbNotaEx
            // 
            this.tbNotaEx.Location = new System.Drawing.Point(126, 68);
            this.tbNotaEx.Name = "tbNotaEx";
            this.tbNotaEx.Size = new System.Drawing.Size(100, 20);
            this.tbNotaEx.TabIndex = 3;
            // 
            // lbNotaL
            // 
            this.lbNotaL.AutoSize = true;
            this.lbNotaL.Location = new System.Drawing.Point(22, 111);
            this.lbNotaL.Name = "lbNotaL";
            this.lbNotaL.Size = new System.Drawing.Size(78, 13);
            this.lbNotaL.TabIndex = 4;
            this.lbNotaL.Text = "Nota Laborator";
            // 
            // lbNotaF
            // 
            this.lbNotaF.AutoSize = true;
            this.lbNotaF.Location = new System.Drawing.Point(22, 156);
            this.lbNotaF.Name = "lbNotaF";
            this.lbNotaF.Size = new System.Drawing.Size(61, 13);
            this.lbNotaF.TabIndex = 5;
            this.lbNotaF.Text = "Nota Finala";
            // 
            // tbNotaL
            // 
            this.tbNotaL.Location = new System.Drawing.Point(126, 104);
            this.tbNotaL.Name = "tbNotaL";
            this.tbNotaL.Size = new System.Drawing.Size(100, 20);
            this.tbNotaL.TabIndex = 6;
            // 
            // tbNotaF
            // 
            this.tbNotaF.Location = new System.Drawing.Point(126, 149);
            this.tbNotaF.Name = "tbNotaF";
            this.tbNotaF.Size = new System.Drawing.Size(100, 20);
            this.tbNotaF.TabIndex = 7;
            // 
            // progresMedie
            // 
            this.progresMedie.Location = new System.Drawing.Point(126, 187);
            this.progresMedie.Name = "progresMedie";
            this.progresMedie.Size = new System.Drawing.Size(100, 12);
            this.progresMedie.TabIndex = 8;
            // 
            // bCalculeaza
            // 
            this.bCalculeaza.Location = new System.Drawing.Point(126, 215);
            this.bCalculeaza.Name = "bCalculeaza";
            this.bCalculeaza.Size = new System.Drawing.Size(100, 23);
            this.bCalculeaza.TabIndex = 9;
            this.bCalculeaza.Text = "Calculeaza";
            this.bCalculeaza.UseVisualStyleBackColor = true;
            this.bCalculeaza.Click += new System.EventHandler(this.bCalculeaza_Click);
            // 
            // bColecteaza
            // 
            this.bColecteaza.Location = new System.Drawing.Point(20, 322);
            this.bColecteaza.Name = "bColecteaza";
            this.bColecteaza.Size = new System.Drawing.Size(75, 23);
            this.bColecteaza.TabIndex = 10;
            this.bColecteaza.Text = "Colecteaza";
            this.bColecteaza.UseVisualStyleBackColor = true;
            this.bColecteaza.Click += new System.EventHandler(this.bColecteaza_Click);
            // 
            // lbComentariu
            // 
            this.lbComentariu.AutoSize = true;
            this.lbComentariu.Location = new System.Drawing.Point(17, 375);
            this.lbComentariu.Name = "lbComentariu";
            this.lbComentariu.Size = new System.Drawing.Size(0, 13);
            this.lbComentariu.TabIndex = 11;
            // 
            // gbSex
            // 
            this.gbSex.Controls.Add(this.rbFeminin);
            this.gbSex.Controls.Add(this.rbMasculin);
            this.gbSex.Location = new System.Drawing.Point(349, 24);
            this.gbSex.Name = "gbSex";
            this.gbSex.Size = new System.Drawing.Size(171, 100);
            this.gbSex.TabIndex = 12;
            this.gbSex.TabStop = false;
            this.gbSex.Text = "Sex";
            // 
            // rbFeminin
            // 
            this.rbFeminin.AutoSize = true;
            this.rbFeminin.Location = new System.Drawing.Point(22, 55);
            this.rbFeminin.Name = "rbFeminin";
            this.rbFeminin.Size = new System.Drawing.Size(61, 17);
            this.rbFeminin.TabIndex = 1;
            this.rbFeminin.TabStop = true;
            this.rbFeminin.Text = "Feminin";
            this.rbFeminin.UseVisualStyleBackColor = true;
            // 
            // rbMasculin
            // 
            this.rbMasculin.AutoSize = true;
            this.rbMasculin.Location = new System.Drawing.Point(24, 18);
            this.rbMasculin.Name = "rbMasculin";
            this.rbMasculin.Size = new System.Drawing.Size(67, 17);
            this.rbMasculin.TabIndex = 0;
            this.rbMasculin.TabStop = true;
            this.rbMasculin.Text = "Masculin";
            this.rbMasculin.UseVisualStyleBackColor = true;
            // 
            // gbLimba
            // 
            this.gbLimba.Controls.Add(this.cbFranceza);
            this.gbLimba.Controls.Add(this.cbEngleza);
            this.gbLimba.Location = new System.Drawing.Point(271, 215);
            this.gbLimba.Name = "gbLimba";
            this.gbLimba.Size = new System.Drawing.Size(200, 100);
            this.gbLimba.TabIndex = 13;
            this.gbLimba.TabStop = false;
            this.gbLimba.Text = "Limba straina cunoscuta";
            // 
            // cbFranceza
            // 
            this.cbFranceza.AutoSize = true;
            this.cbFranceza.Location = new System.Drawing.Point(20, 69);
            this.cbFranceza.Name = "cbFranceza";
            this.cbFranceza.Size = new System.Drawing.Size(70, 17);
            this.cbFranceza.TabIndex = 1;
            this.cbFranceza.Text = "Franceza";
            this.cbFranceza.UseVisualStyleBackColor = true;
            // 
            // cbEngleza
            // 
            this.cbEngleza.AutoSize = true;
            this.cbEngleza.Location = new System.Drawing.Point(20, 29);
            this.cbEngleza.Name = "cbEngleza";
            this.cbEngleza.Size = new System.Drawing.Size(64, 17);
            this.cbEngleza.TabIndex = 0;
            this.cbEngleza.Text = "Engleza";
            this.cbEngleza.UseVisualStyleBackColor = true;
            // 
            // bUrmatorul
            // 
            this.bUrmatorul.Location = new System.Drawing.Point(609, 34);
            this.bUrmatorul.Name = "bUrmatorul";
            this.bUrmatorul.Size = new System.Drawing.Size(121, 23);
            this.bUrmatorul.TabIndex = 14;
            this.bUrmatorul.Text = "Urmatorul";
            this.bUrmatorul.UseVisualStyleBackColor = true;
            this.bUrmatorul.Click += new System.EventHandler(this.bUrmatorul_Click);
            // 
            // cbStareCivila
            // 
            this.cbStareCivila.FormattingEnabled = true;
            this.cbStareCivila.Location = new System.Drawing.Point(609, 148);
            this.cbStareCivila.Name = "cbStareCivila";
            this.cbStareCivila.Size = new System.Drawing.Size(121, 21);
            this.cbStareCivila.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 482);
            this.Controls.Add(this.cbStareCivila);
            this.Controls.Add(this.bUrmatorul);
            this.Controls.Add(this.gbLimba);
            this.Controls.Add(this.gbSex);
            this.Controls.Add(this.lbComentariu);
            this.Controls.Add(this.bColecteaza);
            this.Controls.Add(this.bCalculeaza);
            this.Controls.Add(this.progresMedie);
            this.Controls.Add(this.tbNotaF);
            this.Controls.Add(this.tbNotaL);
            this.Controls.Add(this.lbNotaF);
            this.Controls.Add(this.lbNotaL);
            this.Controls.Add(this.tbNotaEx);
            this.Controls.Add(this.lbNotaEx);
            this.Controls.Add(this.tbNumeStd);
            this.Controls.Add(this.lbNumeStd);
            this.Name = "Form1";
            this.Text = "Formular";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbSex.ResumeLayout(false);
            this.gbSex.PerformLayout();
            this.gbLimba.ResumeLayout(false);
            this.gbLimba.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNumeStd;
        private System.Windows.Forms.TextBox tbNumeStd;
        private System.Windows.Forms.Label lbNotaEx;
        private System.Windows.Forms.TextBox tbNotaEx;
        private System.Windows.Forms.Label lbNotaL;
        private System.Windows.Forms.Label lbNotaF;
        private System.Windows.Forms.TextBox tbNotaL;
        private System.Windows.Forms.TextBox tbNotaF;
        private System.Windows.Forms.ProgressBar progresMedie;
        private System.Windows.Forms.Button bCalculeaza;
        private System.Windows.Forms.Button bColecteaza;
        private System.Windows.Forms.Label lbComentariu;
        private System.Windows.Forms.GroupBox gbSex;
        private System.Windows.Forms.RadioButton rbFeminin;
        private System.Windows.Forms.RadioButton rbMasculin;
        private System.Windows.Forms.GroupBox gbLimba;
        private System.Windows.Forms.CheckBox cbFranceza;
        private System.Windows.Forms.CheckBox cbEngleza;
        private System.Windows.Forms.Button bUrmatorul;
        private System.Windows.Forms.ComboBox cbStareCivila;
    }
}

