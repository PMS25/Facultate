﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Multime<T>
    {
        static int dimMax = 100;
        T[] v;
        int length; //numarul de elemente

        // Constructor Implicit
        public Multime() 
        {
            v = new T[dimMax];
            length = 0;
        }

        // Constructor de Copiere
        public Multime(Multime<T> M)
        {
            v = new T[dimMax];
            for (int i = 0; i < M.length; i++)
                v[i] = M.v[i];
            this.length = M.length;
        }

        // Constructor de Initializare
        public Multime(T[] v, int n)
        {
            this.v = new T[dimMax];
            int min = (v.Length < n) ? v.Length : n;
            min = (min < dimMax) ? min : dimMax;
            for (int i = 0; i < min; i++)
                this.v[i] = v[i];
            length = min;
        }

        // Accesori 
        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public static int DimMax
        {
            get { return dimMax; }
            set { dimMax = value; }
        }

        // Iterator
        // Multime M, M[i] -> v[i]
        public T this[int i]
        {
            get { return v[i]; }
            set { v[i] = value; }
        }

        // bool Equals(object o) - metoda mostenita din clasa object
        // Trebuie suprascrisa (override) in clasa T
        public bool Exista(T x)
        {
            for (int i = 0; i < length; i++)
                if (v[i].Equals(x))
                    return true;
            return false;
        }

        public bool Full()
        {
            return length == dimMax;
        }

        public bool Empty()
        {
            return length == 0;
        }

        // v[0], ..., v[length - 1], x
        public void Add(T x)
        {
            if (!Exista(x))
                v[length++] = x;
        }

        //1 2 3 4 5 6 7 8 9, n = 9
        //1 2 9 4 5 6 7 8 9, n = 8
        public void Delete(T x)
        {
            for (int i = 0; i < length; i++)
                if (v[i].Equals(x))
                {
                    v[i] = v[length - 1];
                    length--;
                }
        }

        // {1, 2, 3, 4}
        // String ToString(); mostenita din clasa object
        // Trebuie suprascrisa (override) in clasa T 
        public override string ToString()
        {
            string s = "{";
            for (int i = 0; i < length; i++)
                s += v[i] + ", ";
            s += "\b\b}";
            return s;
        }

        // Supraincarcarea Operatorilor

        // Reuniunea dintre A si B
        public static Multime<T> operator +(Multime<T> A, Multime<T> B)
        {
            Multime<T> C = new Multime<T>(A); // apel constructor de copiere
            for (int i = 0; i < B.length; i++)
                if (!A.Exista(B[i]))   //iterator  B.v[i]=B[i]
                    C.Add(B[i]);
            return C;
        }

        // Diferenta dintre A si B
        public static Multime<T> operator -(Multime<T> A, Multime<T> B)
        {
            Multime<T> C = new Multime<T>();
            bool sem;
            for (int i = 0; i < A.length; i++) {
                sem = true;
                for (int j = 0; j < B.length; j++)
                    if (A[i].Equals(B[j]))
                    {
                        sem = false;
                        break;
                    }
                if (sem)
                    C.Add(A[i]);
            }
            return C;
        }

        // Intersectia dintre A si B
        public static Multime<T> operator *(Multime<T> A, Multime<T> B)
        {
            Multime<T> C = new Multime<T>();
            for (int i = 0; i < A.length; i++)
                for (int j = 0; j < B.length; j++)
                    if (A[i].Equals(B[j]))
                    {
                        C.Add(A[i]);
                        break;
                    }
            return C;
        }
    }

    class NumarComplex
    {
        int re, im;

        // Constructor Implicit
        public NumarComplex()
        {
            re = 0;
            im = 0;
        }

        // Constructor de Copiere
        public NumarComplex(NumarComplex n)
        {
            re = n.Re;
            im = n.Im;
        }

        // Constructor de Initializare
        public NumarComplex(int re, int im)
        {
            this.re = re;
            this.im = im;
        }

        // Accesori 
        public int Re
        {
            get { return re; }
            set { re = value; }
        }

        public int Im
        {
            get { return im; }
            set { im = value; }
        }

        public override string ToString()
        {
            string s = "";
            if (re < 0)
                s += " - " + (re * -1);
            else if (re > 0)
                s += re;

            if (im < 0)
                s += " - " + (im == -1 ? "" : Convert.ToString(im * -1)) + "i";
            else if (im > 0)
                s += (re == 0 ? "" : " + ") + (im == 1 ? "" : Convert.ToString(im)) + "i";
            return s;
        }

        // Supraincarcarea Operatorilor
        public static NumarComplex operator +(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = a.Re + b.Re;
            c.Im = a.Im + b.Im;
            return c;
        }

        public static NumarComplex operator -(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = a.Re - b.Re;
            c.Im = a.Im - b.Im;
            return c;
        }

        public static NumarComplex operator *(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = (a.Re * b.Re - a.Im * b.Im);
            c.Im = (a.Re * b.Im + a.Im * b.Re);
            return c;
        }

        public double Modul()
        {
            double modul = Math.Sqrt(this.re * this.re + this.im * this.im);
            return modul;
        }

        public override bool Equals(Object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            else
            {
                NumarComplex n = (NumarComplex)obj;
                return (n.Re == re) && (n.Im == im);
            }
        }

    }

    class Program
    {

        static void Main(string[] args)
        {
            Multime<NumarComplex> M = CitireNumereComplexe();
            Console.WriteLine(M);

            for(int i = 0; i<M.Length; i++)
            {
                Console.Write("Numar {0} - ", M[i]);
                Console.WriteLine("Re: {0}, Im: {1}, Modul:{2}", M[i].Re, M[i].Im, Math.Round(M[i].Modul(),2));
            }
            if(M.Length >= 2)
            {
                Console.WriteLine("({0}) + ({1}) = {2}", M[0], M[1], M[0] + M[1]);
                Console.WriteLine("({0}) - ({1}) = {2}", M[0], M[1], M[0] - M[1]);
                Console.WriteLine("({0}) - ({1}) = {2}", M[1], M[0], M[1] - M[0]);
                Console.WriteLine("({0}) * ({1}) = {2}", M[0], M[1], M[0] * M[1]);
            }

            Console.ReadKey();
        }


        static string ParseInput(string input)
        {
            input = input.Replace(" ", "");
            string result = ";";
            for (int i = 0; i < input.Length; i++)
            {
                if (Char.IsDigit(input[i]) || input[i] == 'i')
                    result += input[i];
                else if (input[i] == '-' || input[i] == '+')
                    result += ";" + input[i];
                else if (input[i] == ',')
                    result += input[i] + ";";
            }
            return result;
        }

        static int[] ExtractNumar(string number)
        {
            int real = 0, imaginar = 0;

            string[] split = number.Split(';');
            int len = split.Length;

            if (split[len - 2].Length == 0)
                if (split[len - 1].Contains('i'))
                    imaginar = int.Parse(split[len - 1].Replace("i", ""));
                else
                    real = int.Parse(split[len - 1]);
            else
            {
                real = int.Parse(split[len - 2]);

                string aux = split[len - 1];
                int index = aux.LastIndexOf('i');
                if (aux[index - 1] == '+' || aux[index - 1] == '-')
                    imaginar = int.Parse(split[len - 1].Replace("i","1"));
                else
                    imaginar = int.Parse(split[len - 1].Replace("i", ""));
            }

            int[] result = { real, imaginar };
            return result;
        }

        static Multime<NumarComplex> CitireNumereComplexe()
        {
            Multime<NumarComplex> M = new Multime<NumarComplex>();

            Console.Write("Dati n = ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Forma Acceptata: +/- a, +/- bi, +/- a +/- bi (separate prin ,)");

            while (M.Length < n)
            {
                Console.Write("Lista: ");
                string input = ParseInput(Console.ReadLine());

                foreach (string number in input.Split(','))
                {
                    if (number.Length == 0)
                        continue;
                    int[] result = ExtractNumar(number);

                    M.Add(new NumarComplex(result[0], result[1]));
                    if (M.Length == n)
                        break;
                }
            }

            return M;
        }
    }
}
