﻿namespace Curs02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_student = new System.Windows.Forms.Label();
            this.textBox_student = new System.Windows.Forms.TextBox();
            this.label_examen = new System.Windows.Forms.Label();
            this.label_laborator = new System.Windows.Forms.Label();
            this.textBox_examen = new System.Windows.Forms.TextBox();
            this.textBox_laborator = new System.Windows.Forms.TextBox();
            this.label_nota_finala = new System.Windows.Forms.Label();
            this.textBox_nota_finala = new System.Windows.Forms.TextBox();
            this.progressBar_medie = new System.Windows.Forms.ProgressBar();
            this.button_calcul = new System.Windows.Forms.Button();
            this.groupBox_sex = new System.Windows.Forms.GroupBox();
            this.radioButton_feminin = new System.Windows.Forms.RadioButton();
            this.radioButton_masculin = new System.Windows.Forms.RadioButton();
            this.groupBox_limba_straina = new System.Windows.Forms.GroupBox();
            this.checkBox_franceza = new System.Windows.Forms.CheckBox();
            this.checkBox_engleza = new System.Windows.Forms.CheckBox();
            this.comboBox_stare_civila = new System.Windows.Forms.ComboBox();
            this.button_urmatorul = new System.Windows.Forms.Button();
            this.button_colecteaza = new System.Windows.Forms.Button();
            this.label_comentariu = new System.Windows.Forms.Label();
            this.groupBox_sex.SuspendLayout();
            this.groupBox_limba_straina.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_student
            // 
            this.label_student.AutoSize = true;
            this.label_student.Location = new System.Drawing.Point(14, 22);
            this.label_student.Name = "label_student";
            this.label_student.Size = new System.Drawing.Size(75, 13);
            this.label_student.TabIndex = 0;
            this.label_student.Text = "Nume Student";
            // 
            // textBox_student
            // 
            this.textBox_student.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_student.Location = new System.Drawing.Point(94, 22);
            this.textBox_student.Name = "textBox_student";
            this.textBox_student.Size = new System.Drawing.Size(100, 20);
            this.textBox_student.TabIndex = 1;
            // 
            // label_examen
            // 
            this.label_examen.AutoSize = true;
            this.label_examen.Location = new System.Drawing.Point(14, 53);
            this.label_examen.Name = "label_examen";
            this.label_examen.Size = new System.Drawing.Size(71, 13);
            this.label_examen.TabIndex = 2;
            this.label_examen.Text = "Nota Examen";
            // 
            // label_laborator
            // 
            this.label_laborator.AutoSize = true;
            this.label_laborator.Location = new System.Drawing.Point(14, 86);
            this.label_laborator.Name = "label_laborator";
            this.label_laborator.Size = new System.Drawing.Size(78, 13);
            this.label_laborator.TabIndex = 3;
            this.label_laborator.Text = "Nota Laborator";
            // 
            // textBox_examen
            // 
            this.textBox_examen.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_examen.Location = new System.Drawing.Point(94, 53);
            this.textBox_examen.Name = "textBox_examen";
            this.textBox_examen.Size = new System.Drawing.Size(100, 20);
            this.textBox_examen.TabIndex = 4;
            this.textBox_examen.Validated += new System.EventHandler(this.textBox_examen_Validated);
            // 
            // textBox_laborator
            // 
            this.textBox_laborator.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_laborator.Location = new System.Drawing.Point(94, 86);
            this.textBox_laborator.Name = "textBox_laborator";
            this.textBox_laborator.Size = new System.Drawing.Size(100, 20);
            this.textBox_laborator.TabIndex = 5;
            this.textBox_laborator.Validated += new System.EventHandler(this.textBox_laborator_Validated);
            // 
            // label_nota_finala
            // 
            this.label_nota_finala.AutoSize = true;
            this.label_nota_finala.Location = new System.Drawing.Point(14, 140);
            this.label_nota_finala.Name = "label_nota_finala";
            this.label_nota_finala.Size = new System.Drawing.Size(61, 13);
            this.label_nota_finala.TabIndex = 6;
            this.label_nota_finala.Text = "Nota Finala";
            // 
            // textBox_nota_finala
            // 
            this.textBox_nota_finala.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_nota_finala.Enabled = false;
            this.textBox_nota_finala.Location = new System.Drawing.Point(81, 140);
            this.textBox_nota_finala.Name = "textBox_nota_finala";
            this.textBox_nota_finala.Size = new System.Drawing.Size(100, 20);
            this.textBox_nota_finala.TabIndex = 7;
            // 
            // progressBar_medie
            // 
            this.progressBar_medie.Location = new System.Drawing.Point(81, 167);
            this.progressBar_medie.Name = "progressBar_medie";
            this.progressBar_medie.Size = new System.Drawing.Size(100, 23);
            this.progressBar_medie.TabIndex = 8;
            // 
            // button_calcul
            // 
            this.button_calcul.Location = new System.Drawing.Point(94, 196);
            this.button_calcul.Name = "button_calcul";
            this.button_calcul.Size = new System.Drawing.Size(75, 23);
            this.button_calcul.TabIndex = 9;
            this.button_calcul.Text = "Calculeaza";
            this.button_calcul.UseVisualStyleBackColor = true;
            this.button_calcul.Click += new System.EventHandler(this.button_calcul_Click);
            // 
            // groupBox_sex
            // 
            this.groupBox_sex.Controls.Add(this.radioButton_feminin);
            this.groupBox_sex.Controls.Add(this.radioButton_masculin);
            this.groupBox_sex.Location = new System.Drawing.Point(241, 22);
            this.groupBox_sex.Name = "groupBox_sex";
            this.groupBox_sex.Size = new System.Drawing.Size(200, 100);
            this.groupBox_sex.TabIndex = 10;
            this.groupBox_sex.TabStop = false;
            this.groupBox_sex.Text = "Sex";
            // 
            // radioButton_feminin
            // 
            this.radioButton_feminin.AutoSize = true;
            this.radioButton_feminin.Location = new System.Drawing.Point(17, 59);
            this.radioButton_feminin.Name = "radioButton_feminin";
            this.radioButton_feminin.Size = new System.Drawing.Size(61, 17);
            this.radioButton_feminin.TabIndex = 1;
            this.radioButton_feminin.TabStop = true;
            this.radioButton_feminin.Text = "Feminin";
            this.radioButton_feminin.UseVisualStyleBackColor = true;
            // 
            // radioButton_masculin
            // 
            this.radioButton_masculin.AutoSize = true;
            this.radioButton_masculin.Location = new System.Drawing.Point(17, 20);
            this.radioButton_masculin.Name = "radioButton_masculin";
            this.radioButton_masculin.Size = new System.Drawing.Size(67, 17);
            this.radioButton_masculin.TabIndex = 0;
            this.radioButton_masculin.TabStop = true;
            this.radioButton_masculin.Text = "Masculin";
            this.radioButton_masculin.UseVisualStyleBackColor = true;
            // 
            // groupBox_limba_straina
            // 
            this.groupBox_limba_straina.Controls.Add(this.checkBox_franceza);
            this.groupBox_limba_straina.Controls.Add(this.checkBox_engleza);
            this.groupBox_limba_straina.Location = new System.Drawing.Point(241, 149);
            this.groupBox_limba_straina.Name = "groupBox_limba_straina";
            this.groupBox_limba_straina.Size = new System.Drawing.Size(200, 100);
            this.groupBox_limba_straina.TabIndex = 11;
            this.groupBox_limba_straina.TabStop = false;
            this.groupBox_limba_straina.Text = "Limba Straina Cunoscuta";
            // 
            // checkBox_franceza
            // 
            this.checkBox_franceza.AutoSize = true;
            this.checkBox_franceza.Location = new System.Drawing.Point(17, 52);
            this.checkBox_franceza.Name = "checkBox_franceza";
            this.checkBox_franceza.Size = new System.Drawing.Size(70, 17);
            this.checkBox_franceza.TabIndex = 1;
            this.checkBox_franceza.Text = "Franceza";
            this.checkBox_franceza.UseVisualStyleBackColor = true;
            // 
            // checkBox_engleza
            // 
            this.checkBox_engleza.AutoSize = true;
            this.checkBox_engleza.Location = new System.Drawing.Point(17, 23);
            this.checkBox_engleza.Name = "checkBox_engleza";
            this.checkBox_engleza.Size = new System.Drawing.Size(64, 17);
            this.checkBox_engleza.TabIndex = 0;
            this.checkBox_engleza.Text = "Engleza";
            this.checkBox_engleza.UseVisualStyleBackColor = true;
            // 
            // comboBox_stare_civila
            // 
            this.comboBox_stare_civila.FormattingEnabled = true;
            this.comboBox_stare_civila.Location = new System.Drawing.Point(524, 86);
            this.comboBox_stare_civila.Name = "comboBox_stare_civila";
            this.comboBox_stare_civila.Size = new System.Drawing.Size(121, 21);
            this.comboBox_stare_civila.TabIndex = 12;
            // 
            // button_urmatorul
            // 
            this.button_urmatorul.Location = new System.Drawing.Point(542, 42);
            this.button_urmatorul.Name = "button_urmatorul";
            this.button_urmatorul.Size = new System.Drawing.Size(75, 23);
            this.button_urmatorul.TabIndex = 13;
            this.button_urmatorul.Text = "Urmatorul";
            this.button_urmatorul.UseVisualStyleBackColor = true;
            this.button_urmatorul.Click += new System.EventHandler(this.button_urmatorul_Click);
            // 
            // button_colecteaza
            // 
            this.button_colecteaza.Location = new System.Drawing.Point(94, 306);
            this.button_colecteaza.Name = "button_colecteaza";
            this.button_colecteaza.Size = new System.Drawing.Size(75, 23);
            this.button_colecteaza.TabIndex = 14;
            this.button_colecteaza.Text = "Colecteaza";
            this.button_colecteaza.UseVisualStyleBackColor = true;
            this.button_colecteaza.Click += new System.EventHandler(this.button_colecteaza_Click);
            // 
            // label_comentariu
            // 
            this.label_comentariu.AutoSize = true;
            this.label_comentariu.Location = new System.Drawing.Point(113, 343);
            this.label_comentariu.Name = "label_comentariu";
            this.label_comentariu.Size = new System.Drawing.Size(0, 13);
            this.label_comentariu.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 450);
            this.Controls.Add(this.label_comentariu);
            this.Controls.Add(this.button_colecteaza);
            this.Controls.Add(this.button_urmatorul);
            this.Controls.Add(this.comboBox_stare_civila);
            this.Controls.Add(this.groupBox_limba_straina);
            this.Controls.Add(this.groupBox_sex);
            this.Controls.Add(this.button_calcul);
            this.Controls.Add(this.progressBar_medie);
            this.Controls.Add(this.textBox_nota_finala);
            this.Controls.Add(this.label_nota_finala);
            this.Controls.Add(this.textBox_laborator);
            this.Controls.Add(this.textBox_examen);
            this.Controls.Add(this.label_laborator);
            this.Controls.Add(this.label_examen);
            this.Controls.Add(this.textBox_student);
            this.Controls.Add(this.label_student);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_sex.ResumeLayout(false);
            this.groupBox_sex.PerformLayout();
            this.groupBox_limba_straina.ResumeLayout(false);
            this.groupBox_limba_straina.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_student;
        private System.Windows.Forms.TextBox textBox_student;
        private System.Windows.Forms.Label label_examen;
        private System.Windows.Forms.Label label_laborator;
        private System.Windows.Forms.TextBox textBox_examen;
        private System.Windows.Forms.TextBox textBox_laborator;
        private System.Windows.Forms.Label label_nota_finala;
        private System.Windows.Forms.TextBox textBox_nota_finala;
        private System.Windows.Forms.ProgressBar progressBar_medie;
        private System.Windows.Forms.Button button_calcul;
        private System.Windows.Forms.GroupBox groupBox_sex;
        private System.Windows.Forms.RadioButton radioButton_feminin;
        private System.Windows.Forms.RadioButton radioButton_masculin;
        private System.Windows.Forms.GroupBox groupBox_limba_straina;
        private System.Windows.Forms.CheckBox checkBox_franceza;
        private System.Windows.Forms.CheckBox checkBox_engleza;
        private System.Windows.Forms.ComboBox comboBox_stare_civila;
        private System.Windows.Forms.Button button_urmatorul;
        private System.Windows.Forms.Button button_colecteaza;
        private System.Windows.Forms.Label label_comentariu;
    }
}

