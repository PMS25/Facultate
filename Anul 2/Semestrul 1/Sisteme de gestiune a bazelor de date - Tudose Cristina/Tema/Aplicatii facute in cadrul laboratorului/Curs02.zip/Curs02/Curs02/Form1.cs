﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Curs02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            comboBox_stare_civila.Items.Add("Necasatorit");
            comboBox_stare_civila.Items.AddRange(new string[3] { "Casatorit", "Divortat", "Vaduv" });
            comboBox_stare_civila.SelectedIndex = 0;

            progressBar_medie.Minimum = 0;
            progressBar_medie.Maximum = 100;

            foreach (object t in this.Controls)
                if (t.GetType() == typeof(TextBox))
                    ((TextBox)t).BackColor = Color.Aquamarine;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private bool NotaValida(Object sender)
        {
            TextBox t = (TextBox)sender;
            try
            {
                decimal n = decimal.Parse(t.Text);
                if (n < 5 || n > 10)
                    throw new Exception("Nota Eronata");
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Eroare: " + ex.Message);
                return false;
            }
        }

        private void button_calcul_Click(object sender, EventArgs e)
        {
            decimal medie;
            medie = (decimal.Parse(textBox_examen.Text) + decimal.Parse(textBox_laborator.Text)) / 2;
            textBox_nota_finala.Text = medie.ToString();
            progressBar_medie.Value = (int)(progressBar_medie.Maximum * medie / 10);
        }

        private void textBox_examen_Validated(object sender, EventArgs e)
        {
            if (!NotaValida((TextBox)sender))
                ((TextBox)sender).Focus();
        }

        private void textBox_laborator_Validated(object sender, EventArgs e)
        {
            if (!NotaValida((TextBox)sender))
                ((TextBox)sender).Focus();
        }

        private void button_colecteaza_Click(object sender, EventArgs e)
        {
            label_comentariu.Text = "Student: " + textBox_student.Text + "\n";
            label_comentariu.Text += "Nota Examen: " + textBox_examen.Text + "\n";
            label_comentariu.Text += "Nota Laborator: " + textBox_laborator.Text + "\n";
            if (radioButton_feminin.Checked)
                label_comentariu.Text += "Sex: " + "Feminin" + "\n";
            else if (radioButton_masculin.Checked)
                label_comentariu.Text += "Sex: " + "Masculin" + "\n";
            else
                label_comentariu.Text += "Sex: " + "Nespecificat" + "\n";
            if (checkBox_engleza.Checked)
                label_comentariu.Text += "Limba Straina: " + "Engleza" + "\n";
            if (checkBox_franceza.Checked)
                label_comentariu.Text += "Limba Straina: " + "Franceza" + "\n";

            label_comentariu.Text += "Stare Civila: " + comboBox_stare_civila.Text + "\n";
        }

        private void button_urmatorul_Click(object sender, EventArgs e)
        {
            textBox_student.Text = "";
            textBox_examen.Text = "";
            textBox_laborator.Text = "";
            textBox_nota_finala.Text = "";
            label_comentariu.Text = "";
            checkBox_engleza.Checked = false;
            checkBox_franceza.Checked = false;
            radioButton_feminin.Checked = false;
            radioButton_masculin.Checked = false;

            comboBox_stare_civila.SelectedIndex = 0;
        }
    }
}
