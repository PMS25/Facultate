﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class Multime
    {
        static int dimMax = 100;
        int[] v;
        int length; // numarul de elemente

        // Constructor Implicit 
        public Multime()
        {
            v = new int[dimMax];
            length = 0;
        }

        // Constructor de Copiere
        public Multime(Multime M)
        {
            v = new int[dimMax];
            for (int i = 0; i < M.length; i++)
                v[i] = M.v[i];
            this.length = M.length;
        }

        // Constructor de Initializare
        public Multime(int[] v, int n)
        {
            this.v = new int[dimMax];
            int min;
            min = (v.Length < n) ? v.Length : n;
            min = (min < dimMax) ? min : dimMax;
            length = min;
            for (int i = 0; i < min; i++)
                this.v[i] = v[i];
        }

        // Accesori 
        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public static int DimMax
        {
            get { return dimMax; }
            set { dimMax = value; }
        }

        // Iterator
        // Multime M, M[i] -> v[i]
        public int this[int i]
        {
            get { return v[i]; }
            set { v[i] = value; }
        }

        public bool Exista(int x)
        {
            for (int i = 0; i < length; i++)
                if (v[i] == x)
                    return true;
            return false;
        }

        public bool Full()
        {
            return length == dimMax;
        }

        public bool Empty()
        {
            return length == 0;
        }

        // v[0], ..., v[length-1], x
        public void Add(int x)
        {
            if (!Exista(x) && !Full())
                v[length++] = x;
        }

        // 1 2 3 4 5 6 7 8 9 ; length = 9
        // 1 2 9 4 5 6 7 8 9 ; length = 8
        public void Delete(int x)
        {
            for (int i = 0; i < length; i++)
                if (v[i] == x)
                {
                    v[i] = v[length - 1];
                    length--;
                }
        }

        // {1, 2, 3, 4}
        public override string ToString()
        {
            string s = "{";
            for (int i = 0; i < length; i++)
                s += v[i] + ", ";
            s += "\b\b}";
            return s;
        }

        // Supraincarcarea Operatorilor

        // reuniunea dintre A si B
        public static Multime operator +(Multime A, Multime B)
        {
            Multime C = new Multime(A);
            for (int i = 0; i < B.length; i++)
                if (!A.Exista(B[i]))
                    C.Add(B[i]);
            return C;
        }

        // diferenta dintre A si B
        public static Multime operator -(Multime A, Multime B)
        {
            Multime C = new Multime();
            bool sem;
            for (int i = 0; i < A.length; i++)
            {
                sem = true;
                for (int j = 0; j < B.length; j++)
                    if (B.Exista(A[i]))
                        sem = false;
                if (sem == true)
                    C.Add(A[i]);
            }
            return C;
        }

        // intersectia dintre A si B
        public static Multime operator *(Multime A, Multime B)
        {
            Multime C = new Multime();
            for (int i = 0; i < A.length; i++)
                for (int j = 0; j < B.length; j++)
                    if (B.Exista(A[i]))
                        C.Add(A[i]);
            return C;
        }
    }

    class NumarComplex
    {
        int re, im;

        // Constructor Implicit
        public NumarComplex()
        {
            re = 0;
            im = 0;
        }

        // Constructor de Copiere
        public NumarComplex(NumarComplex n)
        {
            re = n.Re;
            im = n.Im;
        }

        // Constructor de Initializare
        public NumarComplex(int re, int im)
        {
            this.re = re;
            this.im = im;
        }

        // Accesori 
        public int Re
        {
            get { return re; }
            set { re = value; }
        }

        public int Im
        {
            get { return im; }
            set { im = value; }
        }

        public override string ToString()
        {
            string s = "";
            if (re < 0)
                s += " - " + (re * -1);
            else if (re > 0)
                s += re;

            if (im < 0)
                s += " - " + (im == -1 ? "" : Convert.ToString(im * -1)) + "i";
            else if (im > 0)
                s += (re == 0 ? "" : " + ") + (im == 1 ? "" : Convert.ToString(im)) + "i";
            return s;
        }

        // Supraincarcarea Operatorilor
        public static NumarComplex operator +(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = a.Re + b.Re;
            c.Im = a.Im + b.Im;
            return c;
        }

        public static NumarComplex operator -(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = a.Re - b.Re;
            c.Im = a.Im - b.Im;
            return c;
        }

        public static NumarComplex operator *(NumarComplex a, NumarComplex b)
        {
            NumarComplex c = new NumarComplex();
            c.Re = (a.Re * b.Re - a.Im * b.Im);
            c.Im = (a.Re * b.Im + a.Im * b.Re);
            return c;
        }

        public double Modul()
        {
            double modul = Math.Sqrt(this.re * this.re + this.im * this.im);
            return modul;
        }

    }

    class Program
    {
        public static Multime CitireMultime(string name)
        {
            Multime M = new Multime();

            Console.Write("{0}: n = ", name);
            int n = int.Parse(Console.ReadLine());

            while (M.Length < n)
            {
                Console.Write("{0}: Lista: ", name);
                string[] numbers = Console.ReadLine().Split();

                foreach (string number in numbers)
                    if (int.TryParse(number, out int aux))
                    {
                        M.Add(aux);
                        if (M.Length == n)
                            break;
                    }
            }
            return M;
        }

        static void OperatiiMultime()
        {
            Multime A = CitireMultime("A");
            Multime B = CitireMultime("B");
            Multime C;

            Console.WriteLine("A: {0}", A);
            Console.WriteLine("B: {0}", B);

            C = A + B;
            Console.WriteLine("Reuniune: {0}", C);

            C = A - B;
            Console.WriteLine("Diferenta A/B: {0}", C);

            C = B - A;
            Console.WriteLine("Diferenta B/A: {0}", C);

            C = A * B;
            Console.WriteLine("Intersectie: {0}", C);

            Console.Write("Dati un numar: ");
            int n = int.Parse(Console.ReadLine());

            A.Add(n);
            Console.WriteLine("Adauga in A pe {0}: {1}", n, A);
            B.Delete(n);
            Console.WriteLine("Elimina in B pe {0}: {1}", n, B);
            Console.WriteLine("Exista {0} in C: {1}", n, C.Exista(n));

            Console.WriteLine("C: " + C.ToString());
        }

        // Constructor Implicit
        public static NumarComplex CitireNumarComplexC1(string name)
        {
            NumarComplex c = new NumarComplex();
            Console.Write("{0}: Parte Reala (int): ", name);
            int re = int.Parse(Console.ReadLine());
            Console.Write("{0}: Parte Imaginara (int): ", name);
            int im = int.Parse(Console.ReadLine());
            c.Re = re;
            c.Im = im;
            return c;
        }

        // Constructor de Initializare
        public static NumarComplex CitireNumarComplexC2(string name)
        {
            Console.Write("{0}: Parte Reala (int): ", name);
            int re = int.Parse(Console.ReadLine());
            Console.Write("{0}: Parte Imaginara (int): ", name);
            int im = int.Parse(Console.ReadLine());
            NumarComplex c = new NumarComplex(re, im);
            return c;
        }

        static void OperatiiNumereComplexe()
        {
            NumarComplex a = CitireNumarComplexC1("a");
            NumarComplex b = CitireNumarComplexC2("b");
            Console.WriteLine("a: {0}", a);
            Console.WriteLine("b: {0}", b);
            Console.WriteLine("Modul a: {0}", Math.Round(a.Modul(), 2));
            Console.WriteLine("Modul b: {0}", Math.Round(b.Modul(), 2));
            Console.WriteLine("a + b = {0}", a + b);
            Console.WriteLine("a - b = {0}", a - b);
            Console.WriteLine("a * b = {0}", a * b);
            NumarComplex c = new NumarComplex(b);
            Console.WriteLine("c copia lui b: {0}", c);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Operatii Multimi: \n");
            OperatiiMultime();

            Console.WriteLine("\nOperatii Numere Complexe: \n");
            OperatiiNumereComplexe();

            Console.ReadKey();
        }
    }
}
