<?php
    session_start();
    $_SESSION["login"] = FALSE;
    header("Location: http://localhost:8088/lab10/public/index.html");
    exit();
?>
