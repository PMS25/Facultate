<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugare Quiz</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="../public/index.html">Home</a>
            <div class="navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="./quiz_list.php">List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="./quiz_add.php">Add</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./admin_exit.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <form method="post">

        <div class="container">
            <?php
            //verificare login
            session_start();
            if($_SESSION["login"] != TRUE){
                header("Location: http://localhost:8088/lab10/public/index.html");
                exit();
            }

            // conectarea la MySql
            $con = mysqli_connect("localhost", "root", "");
            if (!$con) {
                echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo 'Eroare de conexiune la server MySql </div>';
                exit();
            }

            // crearea bazei de date
            $db = mysqli_select_db($con, "proiect_botanica");
            if (!$db) {
                echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo "Eroare la selectarea bazei de date!</div>";
                exit();
            }

            $question = $_POST["question"];
            $answerA = $_POST["answerA"];
            $answerB = $_POST["answerB"];
            $answerC = $_POST["answerC"];
            $answerD = $_POST["answerD"];
            $check = $_POST["check"];

            //insert the question
            if (isset($question) && isset($answerA) && isset($answerB) && isset($answerC) && isset($answerD) && isset($check)) {
                $comanda = "INSERT INTO tQuiz (question, answers_A, answers_B, answers_C, answers_D, answer)  VALUES ('$question', '$answerA', '$answerB', '$answerC', '$answerD', '$check')";
                $rez = $con->query($comanda);
                if (!$rez) {
                    echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo "Eroare la inserarea datelor!</div>";
                    exit();
                } else {
                    echo '<div class="mt-3 alert alert-dismissible alert-primary">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo 'Întrebarea a fost salvată.</div>';
                }
            }
            ?>

            <h3 class="mt-3 mb-3">Adaugă o întrebare.</h3>

            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="question">
                <label for="question">Intrebare</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerA">
                <label for="answerA">Raspuns A</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerB">
                <label for="answerB">Raspuns B</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerC">
                <label for="answerC">Raspuns C</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerD">
                <label for="answerD">Raspuns D</label>
            </div>
            <div class="btn-group mb-3" role="group" aria-label="Basic radio toggle button group">
                <input type="radio" class="btn-check" name="check" id="checkA" value="A">
                <label class="btn btn-outline-primary" for="checkA">A</label>
                <input type="radio" class="btn-check" name="check" id="checkB" value="B">
                <label class="btn btn-outline-primary" for="checkB">B</label>
                <input type="radio" class="btn-check" name="check" id="checkC" value="C">
                <label class="btn btn-outline-primary" for="checkC">C</label>
                <input type="radio" class="btn-check" name="check" id="checkD" value="D">
                <label class="btn btn-outline-primary" for="checkD">D</label>
            </div>
            <br>
            <input class="btn btn-lg btn-primary" type="submit" value="Salvează" name="Save">
        </div>
    </form>

</body>

</html>