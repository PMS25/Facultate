<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        .back {
            background: #e2e2e2;
            width: 100%;
            position: absolute;
            top: 0;
            bottom: 0;
        }

        .div-center {
            width: 300px;
            height: 280px;
            background-color: #fff;
            position: absolute;
            margin: 0;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            margin: auto;
            max-width: 100%;
            max-height: 100%;
            overflow: auto;
            padding: 1em 2em;
            border-bottom: 2px solid #ccc;
            display: table;
        }
    </style>
</head>

<body>

    <?php
        session_start();
        $user = $_POST["user"];
        $password = $_POST["password"];

        if($user == "admin" && $password == "admin"){
            // session_start();
            $_SESSION["login"] = TRUE;
        }

        if($_SESSION["login"] == TRUE){
            header("Location: http://localhost:8088/lab10/admin/quiz_list.php");
            exit();
        }
    ?>

    <div class="back">
        <div class="div-center">
            <div class="content">
                <h3>Login</h3>
                <form method="post">
                    <div class="form-group mt-2">
                        <label for="user">User</label>
                        <input type="text" class="form-control" name="user" placeholder="User">
                    </div>
                    <div class="form-group mt-2">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <button type="submit" class="btn btn-primary mt-2">Login</button>
                </form>
            </div>
        </div>
    </div>

</body>


</html>