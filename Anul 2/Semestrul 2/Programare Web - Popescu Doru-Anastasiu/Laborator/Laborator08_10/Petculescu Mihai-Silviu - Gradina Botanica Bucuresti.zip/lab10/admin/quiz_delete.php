<?php
    //verificare login
    session_start();
    if($_SESSION["login"] != TRUE){
        header("Location: http://localhost:8088/lab10/public/index.html");
        exit();
    }

    // conectarea la MySql
    $con = mysqli_connect("localhost", "root", "");
    if (!$con) {
        exit();
    }

    // crearea bazei de date
    $db = mysqli_select_db($con, "proiect_botanica");
    if (!$db) {
        exit();
    }

    $id = $_GET["id"];

    if(isset($id)){
        $comanda = "DELETE FROM tQuiz WHERE id = '$id'";
        $rez = $con->query($comanda);
    }

    header("Location: http://localhost:8088/lab10/admin/quiz_list.php");
    exit();
?>