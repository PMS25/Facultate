<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifică Quiz</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="../public/index.html">Home</a>
            <div class="navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="./quiz_list.php">List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./quiz_add.php">Add</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./admin_exit.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <form method="post">

        <div class="container">
            <?php
            //verificare login
            session_start();
            if($_SESSION["login"] != TRUE){
                header("Location: http://localhost:8088/lab10/public/index.html");
                exit();
            }

            // conectarea la MySql
            $con = mysqli_connect("localhost", "root", "");
            if (!$con) {
                echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo 'Eroare de conexiune la server MySql </div>';
                exit();
            }

            // crearea bazei de date
            $db = mysqli_select_db($con, "proiect_botanica");
            if (!$db) {
                echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo "Eroare la selectarea bazei de date!</div>";
                exit();
            }

            // update
            $id = $_GET["id"];
            $question = $_POST["question"];
            $answerA = $_POST["answerA"];
            $answerB = $_POST["answerB"];
            $answerC = $_POST["answerC"];
            $answerD = $_POST["answerD"];
            $check = $_POST["check"];

            //insert the question
            if (isset($question) && isset($answerA) && isset($answerB) && isset($answerC) && isset($answerD) && isset($check)) {
                $comanda = "UPDATE tQuiz SET question = '$question', answers_A = '$answerA', answers_B = '$answerB', answers_C = '$answerC', answers_D = '$answerD', answer = '$check' WHERE id = '$id'";
                $rez = $con->query($comanda);
                if (!$rez) {
                    echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo "Eroare la actualizarea datelor!</div>";
                    exit();
                } else {
                    echo '<div class="mt-3 alert alert-dismissible alert-primary">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo 'Întrebarea a fost actualizată.</div>';
                }
            }

            $q = array();

            if(isset($id)){
                $comanda = "SELECT * FROM tQuiz where id = '$id'";
                $rez = $con->query($comanda);
                $q = mysqli_fetch_array($rez);
            }else{
                exit();
            }
            ?>

            <h3 class="mt-3 mb-3">Actualizează întrebarea.</h3>

            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="question" value="<?php echo $q[1] ?>">
                <label for="question">Intrebare</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerA" value="<?php echo $q[2] ?>">
                <label for="answerA">Raspuns A</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerB" value="<?php echo $q[3] ?>">
                <label for="answerB">Raspuns B</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerC" value="<?php echo $q[4] ?>">
                <label for="answerC">Raspuns C</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="answerD" value="<?php echo $q[5] ?>">
                <label for="answerD">Raspuns D</label>
            </div>
            <div class="btn-group mb-3" role="group" aria-label="Basic radio toggle button group">
                <input type="radio" class="btn-check" name="check" id="checkA" value="A" <?php if($q[6] == "A") echo "checked"; ?> >
                <label class="btn btn-outline-primary" for="checkA">A</label>
                <input type="radio" class="btn-check" name="check" id="checkB" value="B" <?php if($q[6] == "B") echo "checked"; ?> >
                <label class="btn btn-outline-primary" for="checkB">B</label>
                <input type="radio" class="btn-check" name="check" id="checkC" value="C" <?php if($q[6] == "C") echo "checked"; ?> >
                <label class="btn btn-outline-primary" for="checkC">C</label>
                <input type="radio" class="btn-check" name="check" id="checkD" value="D" <?php if($q[6] == "D") echo "checked"; ?> >
                <label class="btn btn-outline-primary" for="checkD">D</label>
            </div>
            <br>
            <input class="btn btn-lg btn-primary" type="submit" value="Salvează" name="Save">
        </div>
    </form>

</body>

</html>