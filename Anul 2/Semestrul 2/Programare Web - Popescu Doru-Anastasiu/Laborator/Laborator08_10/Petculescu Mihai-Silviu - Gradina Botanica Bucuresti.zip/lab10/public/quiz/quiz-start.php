<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <title>Quiz</title>
    <style>
        body {
            /* Background */
            background: url("./img/quiz-shadow.png") no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
        }
    </style>
</head>

<body>

    <form action="http://localhost:8088/lab10/public/quiz/quiz-final.php" method="post">

        <div class="container">

            <?php
                // conectarea la MySql
                $con = mysqli_connect("localhost", "root", "");
                if (!$con) {
                    echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo 'Eroare de conexiune la server MySql </div>';
                    exit();
                }

                // crearea bazei de date
                $db = mysqli_select_db($con, "proiect_botanica");
                if (!$db) {
                    echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo "Eroare la selectarea bazei de date!</div>";
                    exit();
                }

                $comanda = "SELECT * FROM tQuiz";
                $rez = $con->query($comanda);
                if (!$rez) {
                    echo '<div class="mt-3 alert alert-dismissible alert-danger">';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                    echo "Eroare la extragerea datelor!</div>";
                    exit();
                }

                $all_questions = array();
                while($x = mysqli_fetch_array($rez)){
                    $temp = array();
                    for($i = 1; $i < 7; $i++)
                        $temp[] = $x[$i];
                    $temp[] = $x[0];
                    $all_questions[] = $temp;
                }

                // random
                shuffle($all_questions);
                $questions = array_slice($all_questions, 0, 5);

                session_start();
                $_SESSION["questions"] = $questions;
                $index_i = 1;
            ?>

            <div class="card mt-5 text-center text-white bg-primary" style="max-width: 30rem; margin-left: auto; margin-right: auto;">
                <div class="card-header">
                    <h5>Să inceapă testul!</h5>
                </div>
            </div>

            <?php foreach ($questions as $q) { ?>
                <div class="card mt-3">
                    <div class="card-body">
                        <h5 class="card-title">Intrebarea <?php echo $index_i ?></h5>
                        <p class="card-text"> <?php echo $q[0] ?> </p>

                        <ul class="list-group">
                            <li class="list-group-item">
                                <input type="radio" class="btn-check" name="question-<?php echo $index_i ?>-answers" id="question-<?php echo $index_i ?>-answers-A" value="A">
                                <label class="btn btn-outline-primary" for="question-<?php echo $index_i ?>-answers-A">A) <?php echo $q[1] ?></label>
                            </li>
                            <li class="list-group-item">
                                <input type="radio" class="btn-check" name="question-<?php echo $index_i ?>-answers" id="question-<?php echo $index_i ?>-answers-B" value="B">
                                <label class="btn btn-outline-primary" for="question-<?php echo $index_i ?>-answers-B">B) <?php echo $q[2] ?></label>
                            </li>
                            <li class="list-group-item">
                                <input type="radio" class="btn-check" name="question-<?php echo $index_i ?>-answers" id="question-<?php echo $index_i ?>-answers-C" value="C">
                                <label class="btn btn-outline-primary" for="question-<?php echo $index_i ?>-answers-C">C) <?php echo $q[3] ?></label>
                            </li>
                            <li class="list-group-item">
                                <input type="radio" class="btn-check" name="question-<?php echo $index_i ?>-answers" id="question-<?php echo $index_i ?>-answers-D" value="D">
                                <label class="btn btn-outline-primary" for="question-<?php echo $index_i ?>-answers-D">D) <?php echo $q[4] ?></label>
                            </li>
                        </ul>

                        <?php $index_i++; ?>
                    </div>
                </div>

            <?php } ?>

            <div class="card mt-3 text-center mb-3" style="max-width: 30rem; margin-left: auto; margin-right: auto; margin-bottom: 1rem;">
                <div class="card-header">
                    Ai ajuns la final!
                </div>
                <div class="card-body">
                    <input type="submit" class="btn btn-primary" value="Trimite raspunsurile">
                </div>
            </div>

        </div>
    </form>
</body>

</html>