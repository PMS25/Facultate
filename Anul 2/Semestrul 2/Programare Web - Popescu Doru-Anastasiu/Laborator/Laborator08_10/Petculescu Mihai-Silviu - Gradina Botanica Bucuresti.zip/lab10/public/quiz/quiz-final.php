<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <title>Quiz - Rezultat</title>
    <style>
        body {
            /* Background */
            background: url("./img/quiz-shadow.png") no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
        }
    </style>
</head>

<body>

    <?php
        session_start();
        $questions = $_SESSION["questions"];
        $total_count = 0;

        for ($i = 1; $i <= count($questions); $i++) {
            $answer = $_POST["question-$i-answers"];
            if ($answer == $questions[$i - 1][5])
                $total_count++;
        }
    ?>

    <div class="container">

        <div class="card text-white bg-success mb-3 text-center mt-5" style="max-width: 30rem; margin-left: auto; margin-right: auto;">
            <div class="card-header">Rezultat</div>
            <div class="card-body">
                <h4 class="card-title">Felicitari</h4>
                <p class="card-text">Ai raspuns corect la <?php echo $total_count ?> întrebari din <?php echo count($questions)?></p>
                <a href="../index.html" class="btn btn-primary">Apasă pentru a te întoarce la pagina principală.</a>
            </div>
        </div>

    </div>

</body>

</html>