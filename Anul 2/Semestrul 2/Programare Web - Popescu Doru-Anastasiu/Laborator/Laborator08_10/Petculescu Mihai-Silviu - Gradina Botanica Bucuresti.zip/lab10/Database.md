# Grădina Botanică Bucureşti

## Petculescu Mihai-Silviu

[TOC]

### Baza de Date

```sql
SHOW DATABASES;

CREATE DATABASE proiect_botanica;

use proiect_botanica;

CREATE TABLE tQuiz (
  id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question VARCHAR(150) NOT NULL,
  answers_A VARCHAR(150) NOT NULL,
  answers_B VARCHAR(150) NOT NULL,
  answers_C VARCHAR(150) NOT NULL,
  answers_D VARCHAR(150) NOT NULL,
  answer VARCHAR(3) NOT NULL 
)
```

