import java.lang.Math;

public class Calculator {

    CalculatorServices services;

    public Calculator(CalculatorServices services) {

        this.services = services;
    }

    public double arithmeticMean(double nr1, double nr2) {

        return (services.add(nr1, nr2)) / 2.0;
    }

    public double geometricMean(double nr1, double nr2) {

        return Math.sqrt(services.multiply(nr1, nr2));
    }

    public boolean isEvenNr(double nr) {

        return nr % 2 == 0;
    }

    public boolean isOddNr(double nr) {

        return nr % 2 != 0;
    }

}

