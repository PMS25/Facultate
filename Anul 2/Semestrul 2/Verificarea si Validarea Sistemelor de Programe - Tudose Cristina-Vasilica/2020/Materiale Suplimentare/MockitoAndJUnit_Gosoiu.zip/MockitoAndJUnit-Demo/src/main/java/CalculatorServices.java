/* CalculatorServices -> suppose we have an interface connected to a Cloud Service */

public interface CalculatorServices {

    int add(double nr1, double nr2);

    int multiply(double nr1, double nr2);

}

