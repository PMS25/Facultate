import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CalculatorTest {

    CalculatorServices services;
    Calculator calc;

    @BeforeAll
    void initAll() {

        services = mock(CalculatorServices.class); // Mockito - initializes with a fake / mock data
        calc = new Calculator(services);
    }

    @DisplayName("Test - Calculates the arithmetic mean")
    @Test
    void arithmeticMean() {

        when(services.add(3, 3)).thenReturn(6); // Mockito - hard coded data for testing (without using cloud services for example)
        assertEquals(3, calc.arithmeticMean(3, 3)); // tests the arithmeticMean method from our Calculator.class
        verify(services).add(3, 3); // Mockito - verify if the method was used
    }

    @DisplayName("Test - Calculates the geometric mean")
    @Test
    void geometricMean() {

        when(services.multiply(3, 3)).thenReturn(9);
        assertEquals(3, calc.geometricMean(3, 3));
        verify(services).multiply(3, 3);
    }

    @DisplayName("Test - Checks if a number is even")
    @ParameterizedTest(name = "for number: {0}")
    @ValueSource(doubles = {14, 20, 30})
    void isEvenNr(double nr) {

        assertTrue(calc.isEvenNr(nr));
    }

    @DisplayName("Test - Checks if a number is odd")
    @ParameterizedTest(name = "for number: {0}")
    @ValueSource(doubles = {13, 19, 33})
    void isOddNr(double nr) {

        assertTrue(calc.isOddNr(nr));
    }

    @AfterAll
    void tearDown() {

        calc = null;
        services = null;
    }

}

/*
    _____________________
   | JUnit 4 vs. JUnit 5 |
    ---------------------
    * The minimum JDK for JUnit 4 was JDK 5, while JUnit 5 requires at least JDK 8;

    * The @Before, @BeforeClass, @After, and @AfterClass annotations are now the more
      readable as the @BeforeEach, @BeforeAll, @AfterEach, and @AfterAll annotations;

    * @Ignore is now @Disable;

    * @Category is now @Tag.

 */

