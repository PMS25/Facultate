﻿namespace ShapeApplication
{
    public class Point2D
    {
        int X { get; set; }
        int Y { get; set; }
    }
}
