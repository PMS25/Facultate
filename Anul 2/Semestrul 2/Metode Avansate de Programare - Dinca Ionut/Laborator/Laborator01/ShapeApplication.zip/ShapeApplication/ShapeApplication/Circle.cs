﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeApplication
{
    public class Circle : Shape
    {
        //atribute specifice si alte metode
        public override void Draw()
        {
            throw new NotImplementedException();
        }

        public override void MoveTo(Point2D newOrigin)
        {
            throw new NotImplementedException();
        }

        public override void Resize(double factor)
        {
            throw new NotImplementedException();
        }
    }
}
