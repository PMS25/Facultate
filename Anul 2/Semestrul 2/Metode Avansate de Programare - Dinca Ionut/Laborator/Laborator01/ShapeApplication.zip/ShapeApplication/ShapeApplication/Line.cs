﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeApplication
{
    public class Line : Shape
    {
        //atribute si alte metode utile
        public override void Draw()
        {
            throw new NotImplementedException();
        }

        public override void MoveTo(Point2D newOrigin)
        {
            throw new NotImplementedException();
        }

        public override void Resize(double factor)
        {
            throw new NotImplementedException();
        }
    }
}
