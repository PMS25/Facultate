﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeApplication
{
    //container (colectie) de obiecte grafice (primitive sau picture)
    //aceasta clasa va fi utilizata intr-o interfata grafica cu utilizatorul (UI): proiect separat de tip WindowForms
    public class GraphicTool
    {
        public List<Shape> Shapes { get; private set; }
        
        //a se initializa din clasele de interfata (proiectul de UI)
        public Graphics GraphicContext { get; set; }
        //adaugare, eliminare, salvare pe disk, incarcare de pe disk, deseneaza



        public void DrawAll()
        {
            foreach(var shape in Shapes)
            {
                shape.Draw();
            }
        }

        public void GroupShapes(List<string> shapes)
        {
            //1) se grupeaza figurile cu numele din lista shapes astfel:
            //2) sunt cautate in lista 'Shapes' figurile cu numele din parametrul 'shapes'
            //3) se creaza un nou obiect 'Picture' (cu un nume unic)
            //4) toate figurile gasite la pasul 2 sunt adaugate la Picture si eliminate din lista 'Shapes'
        }

        public void UngroupShapes(string pictureGroupName)
        {
            //se cauta in 'Shapes' obiectul (de tip Picture) cu numele pictureGroupName
            //daca exista, va fi eliminat din lista, iar figurile care il compun vor fi adaugate separat in 'Shapes'
        }

        public void SaveOnDisk()
        {
            //in format json, colectia Shapes este salvata pe disk
        }

        public void LoadFromDisk()
        {

        }

        public void Add(Shape s)
        {

        }

        public void Remove(Shape s)
        {

        }
    }
}
