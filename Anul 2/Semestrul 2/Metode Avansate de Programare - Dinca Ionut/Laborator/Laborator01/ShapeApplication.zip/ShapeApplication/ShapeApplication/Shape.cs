﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeApplication
{
    public abstract class Shape
    {
        public Graphics GraphicContext { get; set; } 
        public string Name { get; set; }
        public Point2D Origin { get; set; }
        //metode abstracte comune (comportamentele comune ierarhiei de clase)
        public abstract void Draw();
        public abstract void Resize(double factor);
        public abstract void MoveTo(Point2D newOrigin);
    }
}
