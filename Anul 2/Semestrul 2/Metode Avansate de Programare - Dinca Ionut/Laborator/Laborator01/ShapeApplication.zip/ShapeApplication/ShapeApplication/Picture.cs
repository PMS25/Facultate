﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeApplication
{
    public class Picture : Shape
    {
        public List<Shape> Components { get; private set; }

        public Picture()
        {
            Components = new List<Shape>();
        }

        public override void Draw()
        {
            foreach (var shape in Components)
            {
                shape.Draw(); //apel polimorfic
            }
        }

        public override void MoveTo(Point2D newOrigin)
        {
            throw new NotImplementedException();
        }

        public override void Resize(double factor)
        {
            throw new NotImplementedException();
        }

        public void Add(Shape s)
        {
            Components.Add(s);
        }

        public void Remove(Shape s)
        {
            Components.Remove(s);
        }
    }
}
