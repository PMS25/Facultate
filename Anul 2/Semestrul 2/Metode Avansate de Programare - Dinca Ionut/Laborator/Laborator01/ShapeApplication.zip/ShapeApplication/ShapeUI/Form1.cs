﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShapeUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var g = this.panel1.CreateGraphics();
            g.DrawLine(new Pen(new SolidBrush(Color.Red)) { Width = 5, Color = Color.Red }, 10, 202, 10, 150);
        }
    }
}
