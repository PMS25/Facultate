﻿using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionApp
{
    class Program
    {
       
        //dorim sa utilizam un IoC container (Inversion of Control)
        //NInject

        //Pasul 1
        //crearea unui modul in care configuram (specificam) cum sunt instantiate interfetele!

        //Pasul 2 crearea obiectului kernel (Standard Kernel)
        static void Main(string[] args)
        {
            var cm = Kernel.Instance.Get<ContactManagement>();
            cm.Delete(25);

            var logger = Kernel.Instance.Get<ILog>();
            logger.Log("console logger test");

            var repository = Kernel.Instance.Get<IRepository<ContactModel>>();

            Console.ReadKey();
        }
    }
}
