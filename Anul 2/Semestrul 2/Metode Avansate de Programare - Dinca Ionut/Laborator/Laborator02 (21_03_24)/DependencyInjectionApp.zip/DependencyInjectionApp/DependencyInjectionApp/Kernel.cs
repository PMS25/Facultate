﻿using Ninject;

namespace DependencyInjectionApp
{
    public class Kernel
    {
        private static IKernel _kernel;

        public static IKernel Instance
        {
            get 
            { 
                if (_kernel == null)
                {
                    _kernel = new StandardKernel(new NInjectCustomModule());
                }

                return _kernel;
            }
        }
    }
}
