﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionApp.Internal
{
    class JsonFilesContactRepository : IRepository<ContactModel>
    {
        public int Create(ContactModel model)
        {
            return 1;
        }

        public void Delete(int id)
        {
            Console.WriteLine("s-a sters contactul cu id-ul {0}", id);
        }

        public List<ContactModel> GetAll()
        {
            return new List<ContactModel>();
        }

        public ContactModel GetById(int id)
        {
            return new ContactModel();
        }

        public void Update(ContactModel model)
        {
            Console.WriteLine("update contact");
        }
    }
}
