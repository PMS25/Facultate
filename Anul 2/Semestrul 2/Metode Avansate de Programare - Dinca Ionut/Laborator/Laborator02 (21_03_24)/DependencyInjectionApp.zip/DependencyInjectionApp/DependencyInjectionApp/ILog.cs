﻿namespace DependencyInjectionApp
{
    public interface ILog
    {
        void Log(string message);
    }
}