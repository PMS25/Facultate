﻿using DependencyInjectionApp.Internal;
using Ninject.Modules;

namespace DependencyInjectionApp
{
    //configuram cu ce clase vor lucra in aplicatie daca utilizam acest modul!
    class NInjectCustomModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IRepository<ContactModel>>().To<JsonFilesContactRepository>();
            Bind<ILog>().To<ConsoleLogger>();
            Bind<ContactManagement>().To<ContactManagement>();
        }
    }
}
