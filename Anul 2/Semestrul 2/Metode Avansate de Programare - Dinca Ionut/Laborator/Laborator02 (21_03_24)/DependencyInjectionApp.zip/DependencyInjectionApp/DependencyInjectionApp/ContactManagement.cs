﻿using System;
using System.Collections.Generic;

namespace DependencyInjectionApp
{
    //(1)deoarece dorim sa mentimem clasa ContactManagement independenta
    //de mediul de stocare a datelor (contactelor), vom abstractiza 
    //notiunea de repository printr-o interfata IRepository
    
    //(2)mai mult, daca doresc sa adaug logging la metode, independent de modul de logare (fisier, consola...)
    public class ContactManagement
    {
        IRepository<ContactModel> _repository; //extension point
        ILog _logger;

        //dependency injection (injectare prin constructor)
        public ContactManagement(IRepository<ContactModel> repository, ILog logger)
        {
            _repository = repository;
            _logger = logger;
        }
        
        //get contact by id
        public ContactModel GetById(int contactId)
        {
            return _repository.GetById(contactId);
        }
        //get all contacts
        public List<ContactModel> GetAll()
        {
            return _repository.GetAll();
        }

        //create a new contact
        public int Create(ContactModel contact)
        {
            return _repository.Create(contact);
        }
    
        //update contact
        public void Update(ContactModel contact)
        {
            try
            {
                _repository.Update(contact);
            }
            catch(Exception ex)
            {
                _logger.Log(ex.ToString());
            }
        }

        //delete contact
        public void Delete(int id)
        {
            _repository.Delete(id);
        }
    }
}
