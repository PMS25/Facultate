﻿using AbstractFactorySkeleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientApp
{
    class Program
    {
        static AbstractFactory CurrentFactory { get; set; }
        
        static void CreateComponents()
        {
            var button = CurrentFactory.CreateButton();
            var window = CurrentFactory.CreateWindow();
            button.Paint();
            window.Paint();
        }

        static void Main(string[] args)
        {
            CurrentFactory = SingletonFactory.WinInstance;
            CreateComponents();
            CurrentFactory = SingletonFactory.MacInstance; //change factory
            CreateComponents();
            Console.ReadKey();
        }
    }
}
