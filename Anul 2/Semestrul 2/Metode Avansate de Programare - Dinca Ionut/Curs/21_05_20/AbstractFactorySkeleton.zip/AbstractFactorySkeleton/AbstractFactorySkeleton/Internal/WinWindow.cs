﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactorySkeleton
{
    internal class WinWindow : Window
    {
        public override void Paint()
        {
            Console.WriteLine("Paint WIN Window;");
        }
    }
}
