﻿using AbstractFactorySkeleton.Internal;
using System;

namespace AbstractFactorySkeleton
{
    public class SingletonFactory
    {
        private static Lazy<AbstractFactory> _winFactory = new Lazy<AbstractFactory>(() => new WinFactory());
        private static Lazy<AbstractFactory> _macFactory = new Lazy<AbstractFactory>(() => new MacFactory());

        public static AbstractFactory WinInstance => _winFactory.Value;
        public static AbstractFactory MacInstance => _macFactory.Value;
    }
}
