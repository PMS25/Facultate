﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactorySkeleton
{
    public abstract class AbstractFactory
    {
        public abstract Button CreateButton();
        public abstract Window CreateWindow();
        //public abstract TextBox CreateTextBox();
    }
}
