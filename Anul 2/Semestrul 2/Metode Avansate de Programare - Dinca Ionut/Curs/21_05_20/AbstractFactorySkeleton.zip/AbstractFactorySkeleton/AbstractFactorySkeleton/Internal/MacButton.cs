﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactorySkeleton
{
    internal class MacButton : Button
    {
        public override void Paint()
        {
            Console.WriteLine("Paint Mac Button;");
        }
    }
}
