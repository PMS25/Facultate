﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod
{
    public abstract class Document
    {
        public List<Page> Pages { get; private set; }

        public Document()
        {
            Pages = new List<Page>();
            CreatePages();
        }

        public void AddPage(Page page)
        {
            Pages.Add(page);
        }

        public void Print()
        {
            Pages.ForEach(p => p.Print());
        }

        protected abstract void CreatePages();            
    }
}
