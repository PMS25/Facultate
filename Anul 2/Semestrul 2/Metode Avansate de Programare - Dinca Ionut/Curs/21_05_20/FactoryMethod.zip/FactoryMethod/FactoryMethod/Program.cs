﻿using System;
using System.Collections.Generic;

namespace FactoryMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            var documents = new List<Document>()
            {
                new ReportDocument(),
                new ResumeDocument()
            };

            documents.ForEach(x => x.Print());

            Console.ReadKey();
        }
    }
}
