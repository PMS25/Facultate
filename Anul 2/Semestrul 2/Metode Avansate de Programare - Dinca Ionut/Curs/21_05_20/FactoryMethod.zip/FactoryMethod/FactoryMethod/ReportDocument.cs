﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod
{
    class ReportDocument : Document
    {
        protected override void CreatePages()
        {
            AddPage(new ContentPage());
            AddPage(new IntroductionPage());
            AddPage(new TextPage());
            AddPage(new BibliographyPage());
        }
    }
}
