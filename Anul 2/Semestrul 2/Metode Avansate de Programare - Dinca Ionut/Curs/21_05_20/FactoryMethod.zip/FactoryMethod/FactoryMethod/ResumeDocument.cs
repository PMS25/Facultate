﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod
{
    class ResumeDocument : Document
    {
        protected override void CreatePages()
        {
            AddPage(new IntroductionPage());
            AddPage(new EducationPage());
            AddPage(new ResultsPage());
        }
    }
}
