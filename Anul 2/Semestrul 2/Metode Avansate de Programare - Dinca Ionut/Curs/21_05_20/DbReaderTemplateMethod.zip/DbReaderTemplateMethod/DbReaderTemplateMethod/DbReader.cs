﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbReaderTemplateMethod
{
    //pentru instructiuni de tip select din baza de date
    public abstract class DbReader<T>
    {
        public string ConnectionString { get; set; }

        //metoda template
        public List<T> Get()
        {
            var result = new List<T>();

            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(SqlText, connection))
                    {
                        command.Parameters.AddRange(GetParameters());
                        var reader = command.ExecuteReader(); //rezultatul
                        //maparea unui reader la un obiect de tip T
                        result = MapAll(reader);
                    }
                }

                return result;
            }
            catch(Exception e)
            {
                //logare exceptie e
                return result;
            }
        }

        protected virtual SqlParameter[] GetParameters()
        {
            return new SqlParameter[] { };
        }

        //metoda template
        private List<T> MapAll(IDataReader reader)
        {
            var result = new List<T>();

            while(reader.Read())
            {
                result.Add(Map(reader)); //mapez linia curenta!
            }

            return result;
        }

        protected abstract T Map(IDataReader reader);

        public abstract string SqlText { get; }

    }
}
