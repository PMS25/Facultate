﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbReaderTemplateMethod
{
    internal class UserDbReader : DbReader<User>
    {
        public override string SqlText => "SELECT Username, Password FROM User";

        protected override User Map(IDataReader reader)
        {
            return new User()
            {
                Username = (string)reader["Username"],
                Password = (string)reader["Password"]
            };
        }

        protected override SqlParameter[] GetParameters()
        {
            return base.GetParameters(); //aici returnez eventuala lista de parametrii (ce pot fi utilizati prin nume in select)
        }
    }
}
