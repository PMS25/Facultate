﻿using System;

namespace CommandPatternSkeleton
{
    class ConcreteCommand2 : Command
    {
        public Receiver Receiver { get; private set; }

        public ConcreteCommand2(string name, Receiver receiver)
        {
            Receiver = receiver;
            Name = name;
        }

        public override void Execute()
        {
            Console.WriteLine($"Command {Name} is executing...");
            Receiver.Action();
        }
    }
}
