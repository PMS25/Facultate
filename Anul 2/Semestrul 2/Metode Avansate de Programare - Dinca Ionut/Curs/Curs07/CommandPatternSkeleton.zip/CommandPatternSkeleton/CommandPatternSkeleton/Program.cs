﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternSkeleton
{
    class Program
    {
        static void Main(string[] args)
        {
            Invoker i = new Invoker();
            Receiver r = new Receiver();

            i.AddRange(new List<Command>() 
            { 
                new ConcreteCommand1("c1", r),
                new ConcreteCommand2("c2", r),
                new ConcreteCommand1("c3", r),
            });

            i.Invoke();

            Console.ReadKey();
        }
    }
}
