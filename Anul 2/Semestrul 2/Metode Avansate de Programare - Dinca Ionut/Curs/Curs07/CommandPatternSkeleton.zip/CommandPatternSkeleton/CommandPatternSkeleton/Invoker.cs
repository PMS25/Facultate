﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternSkeleton
{
    //invoker-ul este decuplat (nu stie nimic despre) de Receiver si comenzi concrete
    public class Invoker
    {
        public List<Command> Commands { get; private set; }

        public Invoker()
        {
            Commands = new List<Command>();
        }

        public void Add(Command c)
        {
            Commands.Add(c);
        }

        public void AddRange(List<Command> commands)
        {
            Commands.AddRange(commands);
        }

        public void Invoke()
        {
            foreach(var command in Commands)
            {
                command.Execute();
            }
        }
    }
}
