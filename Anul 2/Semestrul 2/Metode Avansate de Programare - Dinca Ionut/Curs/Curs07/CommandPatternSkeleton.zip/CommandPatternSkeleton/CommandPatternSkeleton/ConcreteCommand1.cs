﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternSkeleton
{
    class ConcreteCommand1 : Command
    {
        public Receiver Receiver { get; private set; }

        public ConcreteCommand1(string name, Receiver receiver)
        {
            Receiver = receiver;
            Name = name;
        }

        public override void Execute()
        {
            Console.WriteLine($"Command {Name} is executing...");
            Receiver.Action();
        }
    }
}
