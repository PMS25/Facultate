﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositeExpression
{
    class Program
    {
        static void Main(string[] args)
        {
            //4+5*(x-y)
            var e = new Sum(new Constant(4), new Mult(new Constant(5), new Dif(new Variable("x", 2), new Variable("y", 3), "-"), "*"), "+");
            Console.WriteLine(e.Inord());
            Console.WriteLine(e.Preord());
            Console.WriteLine(e.Postord());
            Console.WriteLine("e(2,3)={0}", e.Evaluate());
            Console.ReadKey();
        }
    }
}
