﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositeExpression
{
    public class Sum : Binary
    {
        public Sum(Expression left, Expression right, string op): base(left, right, op)
        {           
        }

        public override int Evaluate()
        {
            return Left.Evaluate() + Right.Evaluate();
        }
    }

    public class Mult : Binary
    {
        public Mult(Expression left, Expression right, string op) : base(left, right, op)
        {
        }

        public override int Evaluate()
        {
            return Left.Evaluate() * Right.Evaluate();
        }
    }

    public class Dif : Binary
    {
        public Dif(Expression left, Expression right, string op) : base(left, right, op)
        {
        }

        public override int Evaluate()
        {
            return Left.Evaluate() - Right.Evaluate();
        }
    }
}
