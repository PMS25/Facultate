﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    namespace CompositeExpression
    {
        public class Variable : Expression
        {
            public string Name { get; private set; }
            public int Value { get; set; }

            public Variable(string name, int value)
            {
                Name = name;
                Value = value;
            }

            public override int Evaluate()
            {
                return Value;
            }

            public override string Inord()
            {
                return $"{Name}[{Value}]";
            }

            public override string Postord()
            {
                return $"{Name}[{Value}]";
            }

            public override string Preord()
            {
                return $"{Name}[{Value}]";
            }
        }
    }
