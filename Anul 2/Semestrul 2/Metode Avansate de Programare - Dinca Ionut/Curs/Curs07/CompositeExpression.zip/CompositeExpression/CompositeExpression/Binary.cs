﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositeExpression
{
    public abstract class Binary : Expression
    {
        public Expression Left { get; private set; }
        public Expression Right { get; private set; }
        public string OpSymbol { get; }

        public Binary(Expression left, Expression right, string op)
        {
            Left = left;
            Right = right;
            OpSymbol = op;
        }

        public override string Inord()
        {
            return $"{Left.Inord()}{OpSymbol}{Right.Inord()}";
        }

        public override string Postord()
        {
            return $"{Left.Inord()}{Right.Inord()}{OpSymbol}";
        }

        public override string Preord()
        {
            return $"{OpSymbol}{Left.Inord()}{Right.Inord()}";
        }
    }
}
