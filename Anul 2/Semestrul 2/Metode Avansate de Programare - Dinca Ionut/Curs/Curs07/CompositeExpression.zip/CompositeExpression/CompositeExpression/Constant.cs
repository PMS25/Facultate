﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositeExpression
{
    public class Constant : Expression
    {
        public int Value { get; private set; }

        public Constant(int value)
        {
            Value = value;
        }

        public override int Evaluate()
        {
            return Value;
        }

        public override string Inord()
        {
            return Value.ToString();
        }

        public override string Postord()
        {
            return Value.ToString();
        }

        public override string Preord()
        {
            return Value.ToString();
        }
    }
}
