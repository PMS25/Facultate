﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositeExpression
{
    public abstract class Expression
    {
        public abstract string Inord();
        public abstract string Preord();
        public abstract string Postord();
        public abstract int Evaluate();
    }
}
