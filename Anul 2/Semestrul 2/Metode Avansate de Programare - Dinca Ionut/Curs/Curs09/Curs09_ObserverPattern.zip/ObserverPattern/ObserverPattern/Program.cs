﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            ObservableList<int> list = new ObservableList<int>();

            //atasam observatorii
            list.AddObserver(new ConsoleObserver());
            list.AddObserver(new FileObserver());

            list.Add(23);
            list.Add(2);
            list.Add(25);
            list.Add(21);
            list.Remove(23);


            Console.ReadKey();
        }
    }
}
