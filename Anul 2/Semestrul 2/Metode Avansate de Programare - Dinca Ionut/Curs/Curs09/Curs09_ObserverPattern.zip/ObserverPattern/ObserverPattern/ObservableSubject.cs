﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class ObservableSubject
    {
        private List<IObserver> _observers;

        public ObservableSubject()
        {
            _observers = new List<IObserver>();
        }

        public void AddObserver(IObserver observer)
        {
            _observers.Add(observer);
        }

        public void RemoveObserver(IObserver observer)
        {
            _observers.Remove(observer);
        }


        //se apeleaza de fiecare data cand se schimba starea subiectului observat!
        protected void NotifyObservers(object changedValue)
        {
            foreach(var observer in _observers)
            {
                observer.Update(this, changedValue);
            }
        }
    }
}
