﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    class FileObserver : IObserver
    {
        readonly string fileName = "changes.txt"; 
        
        public void Update(object subject, object changedValue)
        {
            File.AppendAllText(fileName, $"{DateTime.Now}: { changedValue } \n");
        }
    }
}
