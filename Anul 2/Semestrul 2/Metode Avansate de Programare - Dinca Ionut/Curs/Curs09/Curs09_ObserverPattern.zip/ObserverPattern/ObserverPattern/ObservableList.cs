﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public enum ActionType
    {
        Add = 1,
        Remove = 2
    }

    public class ChangedValue<T>
    {
        public int Action { get; set; }
        public T Value { get; set; }

        public override string ToString()
        {
            return $"{ (ActionType)Action }: {Value}";
        }
    }
    
    public class ObservableList<T> : ObservableSubject
    {
        public List<T> _elements;

        public ObservableList():base()
        {
            _elements = new List<T>();
        }


        //dupa fiecare modificare a starii, sunt notificati observatorii
        public void Add(T elem)
        {
            _elements.Add(elem);
            NotifyObservers(new ChangedValue<T>() { Action = (int)ActionType.Add, Value = elem });
        }

        public void Remove(T elem)
        {
            _elements.Remove(elem);
            NotifyObservers(new ChangedValue<T>() { Action = (int)ActionType.Remove, Value = elem });
        }
    }
}
