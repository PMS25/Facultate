﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObserverPattern
{
    class ConsoleObserver<T> : IObserver
    {
        ObservableList<T> subject;

        public void Update(object subject, object changedValue)
        {
            if (subject is ObservableList<T>)
            {
                this.subject = subject as ObservableList<T>;
                var chValue = changedValue as ChangedValue<T>;
                //....
            }
            
            Console.WriteLine(changedValue.ToString());
        }

        public Dictionary<string, long> GetSizes()
        {
            //pentru fiecare tip de extensie gasit, se actualizeaza
            //valoare cheii din dictionar 
        }
    }


    class StorageExplorer : ObservableSubject
    {
        public string RootPath { get; set; }

        //....
        public List<string> GetAllFiles()
        {

        }

        public Dictionary<string, long> GetFileSizes()
        {
            //pentru fiecare tip de extensie gasit, se actualizeaza
            //valoare cheii din dictionar 
        }

        public Dictionary<string, long> GetFileSizes()
        {
            //pentru fiecare tip de extensie gasit, se actualizeaza
            //valoare cheii din dictionar 
        }
    }

    class PieChart : IObserver
    {
        Panel _panel;

        public void Update(object subject, object changedValue)
        {
            //desenare diagrama pe _panel!!
            //_subject as StorageExplorer

            //la fiecare apel de Update de catre subject, se va redesena diagrama 
            //pa panou!!
        }
    }
}
