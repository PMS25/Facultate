﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public interface IObserver
    {
        //aceasta metoda update este utilizata pentru actualizarea
        //unui observer! (este apelata automat de catre subiect)
        void Update(object subject, object changedValue); //obj este subiectul observat!!
    }
}
